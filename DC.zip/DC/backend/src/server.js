import app from "./app.js";
import { env } from "./config/env.js";
import { logger } from "./config/logger.js";
import { connectDB, disconnectDB } from "./config/db.js";

let server = null;

/**
 * Start Express HTTP server after database initialization.
 */
const startServer = async () => {
  try {
    // Attempt database connection
    await connectDB();

    server = app.listen(env.PORT, () => {
      logger.info(
        `Jolly Home Needs API Server listening on port ${env.PORT} in [${env.NODE_ENV}] mode`
      );
      logger.info(`Health check available at: http://localhost:${env.PORT}${env.API_PREFIX}/health`);
    });
  } catch (error) {
    logger.error(`Critical Server Startup Failure: ${error.message}`);
    process.exit(1);
  }
};

/**
 * Graceful termination handler.
 * @param {string} signal - Signal received (SIGINT, SIGTERM)
 */
const handleGracefulShutdown = async (signal) => {
  logger.info(`Received ${signal}. Initiating graceful shutdown...`);

  if (server) {
    server.close(async () => {
      logger.info("HTTP Server closed. No longer accepting new connections.");
      await disconnectDB();
      logger.info("Graceful shutdown completed successfully. Exiting process.");
      process.exit(0);
    });

    // Force exit after 10 seconds if graceful shutdown hangs
    setTimeout(() => {
      logger.error("Forcefully terminating after timeout period (10s).");
      process.exit(1);
    }, 10000).unref();
  } else {
    await disconnectDB();
    process.exit(0);
  }
};

process.on("SIGINT", () => handleGracefulShutdown("SIGINT"));
process.on("SIGTERM", () => handleGracefulShutdown("SIGTERM"));

process.on("unhandledRejection", (reason, promise) => {
  logger.error("Unhandled Promise Rejection at:", { promise, reason });
  // In production, initiate graceful shutdown
  if (env.isProduction) {
    handleGracefulShutdown("unhandledRejection");
  }
});

process.on("uncaughtException", (error) => {
  logger.error(`Uncaught Exception thrown: ${error.message}`, { stack: error.stack });
  // Uncaught exceptions leave the process in an indeterminate state; exit required
  process.exit(1);
});

startServer();

/**
 * @file server.js
 * @description HTTP server entry point initializing the database and listening on PORT.
 */
import app from "./app.js";
import { env } from "./config/env.js";
import { connectDB, disconnectDB } from "./config/db.js";

let server = null;

/** Connects to MongoDB and starts the HTTP listener. */
const startServer = async () => {
  await connectDB();
  server = app.listen(env.PORT, () => {
    process.stdout.write(`DC API listening on port ${env.PORT}\n`);
  });
};

/** Closes the HTTP server and MongoDB connections. */
const shutdown = async () => {
  if (server) {
    server.close(async () => {
      await disconnectDB();
      process.exit(0);
    });
    return;
  }
  await disconnectDB();
  process.exit(0);
};

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

/** Reports startup failures before exiting so configuration and database issues are actionable. */
startServer().catch((error) => {
  process.stderr.write(`DC API failed to start: ${error?.stack || error}\n`);
  process.exit(1);
});

/**
 * @file server.js
 * @description HTTP server entry point initializing database and listening on configured port.
 */
import app from "./app.js";
import { env } from "./config/env.js";
import { connectDB, disconnectDB } from "./config/db.js";

let server = null;

/**
 * Initializes database connection and starts HTTP server listener.
 */
const startServer = async () => {
  try {
    await connectDB();
    server = app.listen(env.PORT, () => {
      // Server listening on configured port
    });
  } catch (_error) {
    process.exit(1);
  }
};

/**
 * Gracefully shuts down HTTP server and terminates database connections.
 */
const shutdown = async () => {
  if (server) {
    server.close(async () => {
      await disconnectDB();
      process.exit(0);
    });
  } else {
    await disconnectDB();
    process.exit(0);
  }
};

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

startServer();

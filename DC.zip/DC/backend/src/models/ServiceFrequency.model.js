/**
 * @file ServiceFrequency.model.js
 * @description Recurring visit interval master.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const serviceFrequencySchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  intervalDays: { type: Number, required: true, min: 1 },
  isActive: { type: Boolean, default: true, index: true },
});

serviceFrequencySchema.plugin(basePlugin);

export const ServiceFrequency = mongoose.model("ServiceFrequency", serviceFrequencySchema);

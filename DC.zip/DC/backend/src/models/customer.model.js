import mongoose from "mongoose";

const customerSchema = new mongoose.Schema(
  {
    customerId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    name: {
      type: String,
      required: [true, "Customer name is required"],
      trim: true,
      index: true,
    },
    mobile: {
      type: String,
      required: [true, "Customer mobile number is required"],
      trim: true,
      index: true,
    },
    whatsapp: {
      type: String,
      trim: true,
      default: "",
    },
    email: {
      type: String,
      trim: true,
      lowercase: true,
      default: "",
    },
    status: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ActiveStatus",
      required: true,
      index: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

customerSchema.virtual("properties", {
  ref: "CustomerAddress",
  localField: "_id",
  foreignField: "customer",
});

customerSchema.virtual("orders", {
  ref: "Order",
  localField: "_id",
  foreignField: "customer",
});

customerSchema.virtual("subscriptions", {
  ref: "Subscription",
  localField: "_id",
  foreignField: "customer",
});

export const Customer = mongoose.model("Customer", customerSchema);

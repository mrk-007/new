import mongoose from "mongoose";

const areaSchema = new mongoose.Schema(
  {
    areaCode: {
      type: String,
      unique: true,
      sparse: true,
      trim: true,
      uppercase: true,
    },
    name: {
      type: String,
      required: [true, "Area name is required"],
      unique: true,
      trim: true,
      index: true,
    },
    city: {
      type: String,
      default: "Chennai",
      trim: true,
    },
    state: {
      type: String,
      default: "Tamil Nadu",
      trim: true,
    },
    pincode: {
      type: String,
      trim: true,
      default: "",
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const Area = mongoose.model("Area", areaSchema);

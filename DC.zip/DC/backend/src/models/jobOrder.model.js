import mongoose from "mongoose";

const jobOrderSchema = new mongoose.Schema(
  {
    jobId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      required: true,
      index: true,
    },
    subscription: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Subscription",
      default: null,
      index: true,
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
      index: true,
    },
    property: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "CustomerAddress",
      required: true,
      index: true,
    },
    title: {
      type: String,
      required: true,
      trim: true,
    },
    serviceType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ServiceType",
      default: null,
      index: true,
    },
    typeName: {
      type: String,
      required: true,
      trim: true,
      index: true, // "Installation", "Bathroom Cleaning", "Deep Cleaning"
    },
    plannedDate: {
      type: String, // YYYY-MM-DD
      required: true,
      index: true,
    },
    startTime: {
      type: String, // HH:MM
      required: true,
    },
    endTime: {
      type: String, // HH:MM
      required: true,
    },
    durationMinutes: {
      type: Number,
      required: true,
    },
    technician: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Technician",
      required: true,
      index: true,
    },
    status: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "JobStatus",
      default: null,
      index: true,
    },
    statusLabel: {
      type: String,
      required: true,
      default: "Assigned",
      trim: true,
      index: true,
    },
    arrivalTime: {
      type: String,
      default: "",
      trim: true,
    },
    workStartedTime: {
      type: String,
      default: "",
      trim: true,
    },
    workCompletedTime: {
      type: String,
      default: "",
      trim: true,
    },
    completionResult: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "CompletionResult",
      default: null,
    },
    completionResultLabel: {
      type: String,
      default: "",
      trim: true,
    },
    followUpStatus: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FollowUpStatus",
      default: null,
    },
    customerFollowup: {
      type: String,
      default: "",
      trim: true,
    },
    notes: {
      type: String,
      default: "",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

jobOrderSchema.virtual("isLate").get(function () {
  if (!this.arrivalTime || !this.startTime) return false;
  return this.arrivalTime > this.startTime;
});

export const JobOrder = mongoose.model("JobOrder", jobOrderSchema);

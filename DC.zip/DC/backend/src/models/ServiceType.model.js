/**
 * @file ServiceType.model.js
 * @description ORDER vs SUBSCRIPTION service type master.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { SERVICE_TYPE_CODE } from "../constants/index.js";

const serviceTypeSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, enum: Object.values(SERVICE_TYPE_CODE) },
  name: { type: String, required: true, trim: true },
  isActive: { type: Boolean, default: true, index: true },
});

serviceTypeSchema.plugin(basePlugin);

export const ServiceType = mongoose.model("ServiceType", serviceTypeSchema);

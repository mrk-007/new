import mongoose from "mongoose";

const paymentStatusSchema = new mongoose.Schema(
  {
    statusCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    statusLabel: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    badgeClass: {
      type: String,
      default: "green",
      trim: true,
    },
    badgeColorHex: {
      type: String,
      default: "#148457",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const PaymentStatus = mongoose.model("PaymentStatus", paymentStatusSchema);

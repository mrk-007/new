/**
 * @file TechnicianSkill.model.js
 * @description True/false skill matrix per technician.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const technicianSkillSchema = new mongoose.Schema({
  technician: { type: mongoose.Schema.Types.ObjectId, ref: "Technician", required: true },
  skill: { type: mongoose.Schema.Types.ObjectId, ref: "Skill", required: true },
  isSkilled: { type: Boolean, default: false },
});

technicianSkillSchema.index({ technician: 1, skill: 1 }, { unique: true });
technicianSkillSchema.plugin(basePlugin);

export const TechnicianSkill = mongoose.model("TechnicianSkill", technicianSkillSchema);

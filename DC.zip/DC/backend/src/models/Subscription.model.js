/**
 * @file Subscription.model.js
 * @description Recurring subscription booking with price snapshot.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { VISIT_STATUS } from "../constants/index.js";

const priceSnapshot = {
  unitPrice: { type: Number, default: 0 },
  cgstRate: { type: Number, default: 0 },
  sgstRate: { type: Number, default: 0 },
  cgstAmount: { type: Number, default: 0 },
  sgstAmount: { type: Number, default: 0 },
  totalAmount: { type: Number, default: 0 },
};

const subscriptionSchema = new mongoose.Schema({
  subscriptionNumber: { type: String, required: true, unique: true },
  customer: { type: mongoose.Schema.Types.ObjectId, ref: "Customer", required: true },
  address: { type: mongoose.Schema.Types.ObjectId, ref: "Address", required: true },
  subscriptionPlan: { type: mongoose.Schema.Types.ObjectId, ref: "SubscriptionPlan", required: true },
  subscriptionTerm: { type: mongoose.Schema.Types.ObjectId, ref: "SubscriptionTerm", required: true },
  serviceFrequency: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceFrequency", required: true },
  bathroomCount: { type: mongoose.Schema.Types.ObjectId, ref: "BathroomCount", default: null },
  propertySize: { type: mongoose.Schema.Types.ObjectId, ref: "PropertySize", default: null },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  preferredStartTime: { type: String, required: true },
  ...priceSnapshot,
  status: { type: String, enum: Object.values(VISIT_STATUS), default: VISIT_STATUS.PENDING, index: true },
  isCompleted: { type: Boolean, default: false },
});

subscriptionSchema.plugin(basePlugin);

export const Subscription = mongoose.model("Subscription", subscriptionSchema);

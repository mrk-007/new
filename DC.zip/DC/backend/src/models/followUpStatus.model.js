import mongoose from "mongoose";

const followUpStatusSchema = new mongoose.Schema(
  {
    statusCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    statusLabel: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    badgeClass: {
      type: String,
      default: "amber",
      trim: true,
    },
    badgeColorHex: {
      type: String,
      default: "#ad6500",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const FollowUpStatus = mongoose.model("FollowUpStatus", followUpStatusSchema);

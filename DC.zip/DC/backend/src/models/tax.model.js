import mongoose from "mongoose";

const taxSchema = new mongoose.Schema(
  {
    taxCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    taxName: {
      type: String,
      required: [true, "Tax name is required"],
      trim: true,
    },
    ratePercent: {
      type: Number,
      required: [true, "Tax rate percentage is required"],
      min: 0,
      max: 100,
    },
    taxType: {
      type: String,
      default: "GST",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const Tax = mongoose.model("Tax", taxSchema);

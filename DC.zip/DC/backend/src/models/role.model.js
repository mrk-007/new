import mongoose from "mongoose";

const roleSchema = new mongoose.Schema(
  {
    roleKey: {
      type: String,
      required: [true, "Role key is required"],
      unique: true,
      trim: true,
      lowercase: true,
      index: true,
    },
    roleName: {
      type: String,
      required: [true, "Role name is required"],
      trim: true,
    },
    description: {
      type: String,
      default: "",
      trim: true,
    },
    isSystemRole: {
      type: Boolean,
      default: false,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const Role = mongoose.model("Role", roleSchema);

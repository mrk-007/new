/**
 * @file Technician.model.js
 * @description Field technician profile and availability.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { ALLOCATION_STATUS } from "../constants/index.js";
import { overlaps, addMinutes } from "../utils/time.js";

const technicianSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
  name: { type: String, required: true, trim: true },
  mobile: { type: String, required: true, unique: true, trim: true },
  email: { type: String, lowercase: true, trim: true },
  isAvailable: { type: Boolean, default: true },
  isActive: { type: Boolean, default: true, index: true },
});

technicianSchema.plugin(basePlugin);

/** Returns true when the technician is on duty and has no overlapping assigned visit. */
technicianSchema.methods.isFreeFor = async function isFreeFor(start, end, bufferMinutes = 0) {
  if (!this.isActive || !this.isAvailable) return false;
  const { TechnicianAllocation } = await import("./TechnicianAllocation.model.js");
  const { Visit } = await import("./Visit.model.js");
  const allocations = await TechnicianAllocation.find({
    technician: this._id,
    status: ALLOCATION_STATUS.ASSIGNED,
  }).lean();
  const visitIds = allocations.map((row) => row.visit);
  const visits = await Visit.find({ _id: { $in: visitIds }, status: { $ne: "CANCELLED" } }).lean();
  return !visits.some((visit) =>
    overlaps(
      addMinutes(visit.scheduledStart, -bufferMinutes),
      addMinutes(visit.scheduledEnd, bufferMinutes),
      start,
      end
    )
  );
};

export const Technician = mongoose.model("Technician", technicianSchema);

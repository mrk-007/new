/**
 * @file AuditLog.model.js
 * @description Append-only create/update/delete audit trail.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { AUDIT_ACTION } from "../constants/index.js";

const auditLogSchema = new mongoose.Schema({
  entity: { type: String, required: true },
  entityId: { type: mongoose.Schema.Types.ObjectId, required: true },
  action: { type: String, required: true, enum: Object.values(AUDIT_ACTION) },
  before: { type: mongoose.Schema.Types.Mixed, default: null },
  after: { type: mongoose.Schema.Types.Mixed, default: null },
  performedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  ip: { type: String },
  userAgent: { type: String },
});

auditLogSchema.index({ entity: 1, entityId: 1 });
auditLogSchema.index({ createdAt: 1 });
auditLogSchema.plugin(basePlugin);

export const AuditLog = mongoose.model("AuditLog", auditLogSchema);

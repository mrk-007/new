import mongoose from "mongoose";

const subscriptionSchema = new mongoose.Schema(
  {
    subscriptionId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      required: true,
      index: true,
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
      index: true,
    },
    property: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "CustomerAddress",
      required: true,
      index: true,
    },
    serviceType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ServiceType",
      default: null,
      index: true,
    },
    typeName: {
      type: String,
      required: true,
      trim: true,
    },
    configuration: {
      type: String,
      required: true,
      trim: true,
    },
    plan: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "SubscriptionPlan",
      default: null,
    },
    frequency: {
      type: String,
      required: true,
      trim: true,
    },
    slot: {
      type: String,
      required: true,
      trim: true,
    },
    totalVisits: {
      type: Number,
      required: true,
      min: 1,
    },
    completedVisits: {
      type: Number,
      default: 0,
    },
    nextVisitDate: {
      type: String,
      default: "",
      trim: true,
    },
    invoice: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Invoice",
      default: null,
    },
    invoiceNumber: {
      type: String,
      default: "",
      trim: true,
    },
    status: {
      type: String,
      default: "Active",
      trim: true,
      index: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

subscriptionSchema.virtual("visitsDisplay").get(function () {
  return `${this.completedVisits} / ${this.totalVisits}`;
});

subscriptionSchema.virtual("visits", {
  ref: "SubscriptionVisit",
  localField: "_id",
  foreignField: "subscription",
});

export const Subscription = mongoose.model("Subscription", subscriptionSchema);

import mongoose from "mongoose";

const orderSchema = new mongoose.Schema(
  {
    orderId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: [true, "Customer reference is required"],
      index: true,
    },
    property: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "CustomerAddress",
      required: [true, "Property reference is required"],
      index: true,
    },
    serviceType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ServiceType",
      default: null,
      index: true,
    },
    orderType: {
      type: String,
      required: true,
      trim: true,
      index: true, // "Product Installation", "Bathroom Cleaning", "Deep Cleaning"
    },
    serviceName: {
      type: String,
      required: true,
      trim: true,
    },
    configuration: {
      type: String,
      default: "",
      trim: true,
    },
    plan: {
      type: String,
      default: "",
      trim: true,
    },
    serviceDate: {
      type: String, // YYYY-MM-DD
      required: true,
      index: true,
    },
    startTime: {
      type: String, // HH:MM
      required: true,
    },
    endTime: {
      type: String, // HH:MM
      required: true,
    },
    durationMinutes: {
      type: Number,
      required: true,
      default: 120,
    },
    assignedTech: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Technician",
      required: true,
      index: true,
    },
    travelBufferMinutes: {
      type: Number,
      default: 30,
    },
    charges: {
      type: Number,
      required: true,
      default: 0,
      min: 0,
    },
    discount: {
      type: Number,
      default: 0,
      min: 0,
    },
    cgst: {
      type: Number,
      default: 0,
      min: 0,
    },
    sgst: {
      type: Number,
      default: 0,
      min: 0,
    },
    totalAmount: {
      type: Number,
      required: true,
      min: 0,
    },
    paymentMethod: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "PaymentMethod",
      default: null,
    },
    paymentModeName: {
      type: String,
      default: "UPI",
      trim: true,
    },
    transactionRef: {
      type: String,
      default: "",
      trim: true,
    },
    invoice: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Invoice",
      default: null,
      index: true,
    },
    invoiceNumber: {
      type: String,
      default: "",
      trim: true,
    },
    status: {
      type: String,
      default: "Active", // "Active", "Installation Scheduled", "Completed"
      trim: true,
      index: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

orderSchema.virtual("items", {
  ref: "OrderItem",
  localField: "_id",
  foreignField: "order",
});

orderSchema.virtual("jobs", {
  ref: "JobOrder",
  localField: "_id",
  foreignField: "order",
});

export const Order = mongoose.model("Order", orderSchema);

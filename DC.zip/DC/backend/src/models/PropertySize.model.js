/**
 * @file PropertySize.model.js
 * @description Property size master used by deep-cleaning pricing.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const propertySizeSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  bedrooms: { type: Number, required: true, min: 1 },
  isActive: { type: Boolean, default: true, index: true },
});

propertySizeSchema.plugin(basePlugin);

export const PropertySize = mongoose.model("PropertySize", propertySizeSchema);

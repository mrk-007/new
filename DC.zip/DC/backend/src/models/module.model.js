import mongoose from "mongoose";

const moduleSchema = new mongoose.Schema(
  {
    moduleKey: {
      type: String,
      required: [true, "Module key is required"],
      unique: true,
      trim: true,
      lowercase: true,
      index: true,
    },
    moduleName: {
      type: String,
      required: [true, "Module name is required"],
      trim: true,
    },
    routePath: {
      type: String,
      required: [true, "Route path is required"],
      trim: true,
    },
    category: {
      type: String,
      default: "Operations",
      trim: true,
      index: true,
    },
    displayOrder: {
      type: Number,
      default: 0,
    },
    icon: {
      type: String,
      default: "",
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const Module = mongoose.model("Module", moduleSchema);

/**
 * @file SubscriptionPlan.model.js
 * @description Recurring subscription plan master.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { PRICING_BASIS } from "../constants/index.js";

const subscriptionPlanSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, trim: true, uppercase: true },
  name: { type: String, required: true, trim: true },
  serviceType: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceType", required: true },
  pricingBasis: { type: String, required: true, enum: Object.values(PRICING_BASIS) },
  requiresSiteVisit: { type: Boolean, default: false },
  siteVisitMinutes: { type: Number, default: 30 },
  isActive: { type: Boolean, default: true, index: true },
});

subscriptionPlanSchema.plugin(basePlugin);

export const SubscriptionPlan = mongoose.model("SubscriptionPlan", subscriptionPlanSchema);

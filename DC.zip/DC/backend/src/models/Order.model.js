/**
 * @file Order.model.js
 * @description One-time product order with status history and price snapshot.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { ORDER_STATUS } from "../constants/index.js";

const statusHistorySchema = new mongoose.Schema(
  {
    status: { type: String, required: true },
    changedAt: { type: Date, default: Date.now },
    changedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    note: { type: String, trim: true },
  },
  { _id: false }
);

const orderSchema = new mongoose.Schema({
  orderNumber: { type: String, required: true, unique: true },
  customer: { type: mongoose.Schema.Types.ObjectId, ref: "Customer", required: true },
  address: { type: mongoose.Schema.Types.ObjectId, ref: "Address", required: true },
  product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
  quantity: { type: Number, required: true, min: 1, default: 1 },
  unitPrice: { type: Number, default: 0 },
  cgstRate: { type: Number, default: 0 },
  sgstRate: { type: Number, default: 0 },
  cgstAmount: { type: Number, default: 0 },
  sgstAmount: { type: Number, default: 0 },
  totalAmount: { type: Number, default: 0 },
  quotedAmount: { type: Number, default: null },
  status: { type: String, enum: Object.values(ORDER_STATUS), default: ORDER_STATUS.PENDING, index: true },
  statusHistory: { type: [statusHistorySchema], default: [] },
  deliveredAt: { type: Date, default: null },
  cancelReason: { type: String, trim: true },
});

orderSchema.plugin(basePlugin);

export const Order = mongoose.model("Order", orderSchema);

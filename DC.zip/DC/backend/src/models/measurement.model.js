import mongoose from "mongoose";

const measurementSchema = new mongoose.Schema(
  {
    measurementCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    label: {
      type: String,
      required: [true, "Measurement label is required"],
      trim: true,
    },
    description: {
      type: String,
      default: "",
      trim: true,
    },
    unit: {
      type: String,
      default: "Unit",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const Measurement = mongoose.model("Measurement", measurementSchema);

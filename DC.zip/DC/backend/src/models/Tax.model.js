/**
 * @file Tax.model.js
 * @description Location-based CGST/SGST rates.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const taxSchema = new mongoose.Schema({
  state: { type: String, required: true, trim: true },
  city: { type: String, trim: true, default: null },
  cgstRate: { type: Number, required: true, min: 0 },
  sgstRate: { type: Number, required: true, min: 0 },
  isActive: { type: Boolean, default: true, index: true },
});

taxSchema.plugin(basePlugin);

export const Tax = mongoose.model("Tax", taxSchema);

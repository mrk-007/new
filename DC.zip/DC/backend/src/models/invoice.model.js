import mongoose from "mongoose";

const invoiceSchema = new mongoose.Schema(
  {
    invoiceId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      required: true,
      index: true,
    },
    orderNumber: {
      type: String,
      required: true,
      trim: true,
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
      index: true,
    },
    category: {
      type: String,
      required: true,
      trim: true,
    },
    subTotal: {
      type: Number,
      required: true,
      min: 0,
    },
    cgst: {
      type: Number,
      default: 0,
      min: 0,
    },
    sgst: {
      type: Number,
      default: 0,
      min: 0,
    },
    totalAmount: {
      type: Number,
      required: true,
      min: 0,
    },
    status: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "PaymentStatus",
      default: null,
      index: true,
    },
    statusLabel: {
      type: String,
      default: "Paid",
      trim: true,
      index: true,
    },
    paymentMode: {
      type: String,
      default: "UPI",
      trim: true,
    },
    transactionRef: {
      type: String,
      default: "",
      trim: true,
    },
    paidAt: {
      type: Date,
      default: Date.now,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

invoiceSchema.virtual("items", {
  ref: "InvoiceItem",
  localField: "_id",
  foreignField: "invoice",
});

export const Invoice = mongoose.model("Invoice", invoiceSchema);

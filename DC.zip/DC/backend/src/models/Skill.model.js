/**
 * @file Skill.model.js
 * @description Skill master linked to a product or subscription plan.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { AppError } from "../utils/appError.js";

const skillSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, trim: true, uppercase: true },
  name: { type: String, required: true, trim: true },
  product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", default: null },
  subscriptionPlan: { type: mongoose.Schema.Types.ObjectId, ref: "SubscriptionPlan", default: null },
  isActive: { type: Boolean, default: true, index: true },
});

/** Requires exactly one of product or subscriptionPlan. */
skillSchema.pre("validate", function ensureSingleTarget(next) {
  const hasProduct = Boolean(this.product);
  const hasPlan = Boolean(this.subscriptionPlan);
  if (hasProduct === hasPlan) {
    return next(new AppError(422, "Skill must target exactly one of product or subscriptionPlan."));
  }
  next();
});

skillSchema.plugin(basePlugin);

export const Skill = mongoose.model("Skill", skillSchema);

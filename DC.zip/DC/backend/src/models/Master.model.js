/**
 * @file Master.model.js
 * @description Master lookup schema for lifecycles, arrival, work and follow-up statuses.
 */
import mongoose from "mongoose";

const masterSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    code: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    label: {
      type: String,
      required: true,
      trim: true,
    },
    tone: {
      type: String,
      enum: ["default", "info", "success", "warning", "error"],
      default: "default",
    },
    order: {
      type: Number,
      default: 0,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  },
  {
    timestamps: true,
  }
);

masterSchema.index({ type: 1, code: 1 }, { unique: true });

export const Master = mongoose.model("Master", masterSchema);
export default Master;

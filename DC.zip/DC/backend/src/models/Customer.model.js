/**
 * @file Customer.model.js
 * @description Customer profile used by orders and subscriptions.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const customerSchema = new mongoose.Schema({
  fullName: { type: String, required: true, trim: true },
  mobile: { type: String, required: true, unique: true, trim: true },
  alternateMobile: { type: String, trim: true },
  email: { type: String, lowercase: true, trim: true },
  notes: { type: String, trim: true },
  isActive: { type: Boolean, default: true, index: true },
});

customerSchema.plugin(basePlugin);

export const Customer = mongoose.model("Customer", customerSchema);

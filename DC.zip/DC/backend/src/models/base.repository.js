import { parseQueryParams, calculatePagination } from "../utils/queryHelper.js";

/**
 * Base Repository providing normalized CRUD and querying abstractions for Mongoose models.
 */
export class BaseRepository {
  /**
   * @param {import("mongoose").Model} model
   */
  constructor(model) {
    this.model = model;
  }

  /**
   * Find documents with optional projection and population.
   */
  async find(filter = {}, options = {}) {
    const { sort = { createdAt: -1 }, limit, skip, populate, select } = options;
    const query = this.model.find({ isActive: true, ...filter });

    if (select) query.select(select);
    if (sort) query.sort(sort);
    if (skip) query.skip(skip);
    if (limit) query.limit(limit);
    if (populate) query.populate(populate);

    return query.lean().exec();
  }

  /**
   * Find paginated documents matching search and query parameters.
   */
  async findPaginated(queryParams = {}, searchFields = [], populateOptions = null) {
    const { filter, sort, skip, limit, page } = parseQueryParams(queryParams, searchFields);

    const query = this.model.find(filter).sort(sort).skip(skip).limit(limit);
    if (populateOptions) {
      query.populate(populateOptions);
    }

    const [items, total] = await Promise.all([
      query.lean().exec(),
      this.model.countDocuments(filter).exec(),
    ]);

    const pagination = calculatePagination(total, page, limit);
    return { items, pagination };
  }

  /**
   * Find single document by its MongoDB ObjectId.
   */
  async findById(id, populateOptions = null) {
    const query = this.model.findOne({ _id: id, isActive: true });
    if (populateOptions) query.populate(populateOptions);
    return query.exec();
  }

  /**
   * Find single document matching arbitrary criteria.
   */
  async findOne(filter = {}, populateOptions = null) {
    const query = this.model.findOne({ isActive: true, ...filter });
    if (populateOptions) query.populate(populateOptions);
    return query.exec();
  }

  /**
   * Create and persist a new document.
   */
  async create(data) {
    const document = new this.model(data);
    return document.save();
  }

  /**
   * Create multiple documents in bulk.
   */
  async insertMany(items) {
    return this.model.insertMany(items);
  }

  /**
   * Update single document by its ID.
   */
  async updateById(id, updateData, options = {}) {
    return this.model
      .findOneAndUpdate({ _id: id, isActive: true }, { $set: updateData }, {
        new: true,
        runValidators: true,
        ...options,
      })
      .exec();
  }

  /**
   * Soft-delete (or hard-delete if specified) by ID.
   */
  async deleteById(id, softDelete = true, userId = null) {
    if (softDelete) {
      return this.model
        .findOneAndUpdate(
          { _id: id, isActive: true },
          { $set: { isActive: false, updatedBy: userId } },
          { new: true }
        )
        .exec();
    }
    return this.model.findByIdAndDelete(id).exec();
  }

  /**
   * Count documents matching filter.
   */
  async count(filter = {}) {
    return this.model.countDocuments({ isActive: true, ...filter }).exec();
  }

  /**
   * Check if at least one document matches filter.
   */
  async exists(filter = {}) {
    return this.model.exists({ isActive: true, ...filter });
  }
}

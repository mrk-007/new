import mongoose from "mongoose";

const jobStatusSchema = new mongoose.Schema(
  {
    statusCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    statusLabel: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    rank: {
      type: Number,
      required: true,
      default: 0,
      index: true,
    },
    badgeClass: {
      type: String,
      default: "purple",
      trim: true,
    },
    badgeColorHex: {
      type: String,
      default: "#5b47dc",
      trim: true,
    },
    isTerminalState: {
      type: Boolean,
      default: false,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const JobStatus = mongoose.model("JobStatus", jobStatusSchema);

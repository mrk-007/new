/**
 * @file Role.model.js
 * @description Role master with read/write/delete flags.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const roleSchema = new mongoose.Schema({
  roleName: { type: String, required: true, unique: true, trim: true },
  isRead: { type: Boolean, default: false },
  isWrite: { type: Boolean, default: false },
  isDelete: { type: Boolean, default: false },
  isActive: { type: Boolean, default: true, index: true },
});

roleSchema.plugin(basePlugin);

export const Role = mongoose.model("Role", roleSchema);

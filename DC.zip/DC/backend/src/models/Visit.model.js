/**
 * @file Visit.model.js
 * @description Scheduled site visit or service visit for an order or subscription.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { VISIT_STATUS, VISIT_TYPE } from "../constants/index.js";
import { AppError } from "../utils/appError.js";

const siteReportSchema = new mongoose.Schema(
  {
    notes: { type: String, trim: true },
    width: { type: Number },
    height: { type: Number },
    unit: { type: String, trim: true },
    quotedAmount: { type: Number, min: 0 },
  },
  { _id: false }
);

const visitSchema = new mongoose.Schema({
  subscription: { type: mongoose.Schema.Types.ObjectId, ref: "Subscription", default: null },
  order: { type: mongoose.Schema.Types.ObjectId, ref: "Order", default: null },
  customer: { type: mongoose.Schema.Types.ObjectId, ref: "Customer", required: true },
  address: { type: mongoose.Schema.Types.ObjectId, ref: "Address", required: true },
  visitType: { type: String, required: true, enum: Object.values(VISIT_TYPE) },
  sequenceNo: { type: Number, required: true, default: 1 },
  scheduledStart: { type: Date, required: true, index: true },
  scheduledEnd: { type: Date, required: true },
  durationMinutes: { type: Number, required: true, min: 1 },
  status: { type: String, enum: Object.values(VISIT_STATUS), default: VISIT_STATUS.PENDING, index: true },
  isCompleted: { type: Boolean, default: false },
  startedAt: { type: Date, default: null },
  completedAt: { type: Date, default: null },
  cancelReason: { type: String, trim: true },
  siteReport: { type: siteReportSchema, default: undefined },
});

/** Requires exactly one parent booking. */
visitSchema.pre("validate", function ensureParent(next) {
  const hasSub = Boolean(this.subscription);
  const hasOrder = Boolean(this.order);
  if (hasSub === hasOrder) {
    return next(new AppError(422, "Visit must belong to exactly one of subscription or order."));
  }
  next();
});

visitSchema.plugin(basePlugin);

export const Visit = mongoose.model("Visit", visitSchema);

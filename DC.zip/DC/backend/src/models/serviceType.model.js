import mongoose from "mongoose";

const serviceTypeSchema = new mongoose.Schema(
  {
    typeCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    typeName: {
      type: String,
      required: [true, "Service type name is required"],
      unique: true,
      trim: true,
      index: true,
    },
    category: {
      type: String,
      default: "Product Installation", // or Subscription
      trim: true,
    },
    defaultDurationMinutes: {
      type: Number,
      default: 90,
    },
    isRecurringSubscription: {
      type: Boolean,
      default: false,
    },
    calendarColorHex: {
      type: String,
      default: "#5b47dc",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const ServiceType = mongoose.model("ServiceType", serviceTypeSchema);

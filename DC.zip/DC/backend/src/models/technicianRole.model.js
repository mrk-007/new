import mongoose from "mongoose";

const technicianRoleSchema = new mongoose.Schema(
  {
    roleCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    roleTitle: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    defaultCapacity: {
      type: Number,
      required: true,
      default: 5,
      min: 1,
    },
    description: {
      type: String,
      default: "",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const TechnicianRole = mongoose.model("TechnicianRole", technicianRoleSchema);

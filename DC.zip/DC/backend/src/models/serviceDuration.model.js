import mongoose from "mongoose";

const serviceDurationSchema = new mongoose.Schema(
  {
    serviceType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ServiceType",
      required: true,
      index: true,
    },
    bathroomCount: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "BathroomCount",
      default: null,
      index: true,
    },
    propertySize: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "PropertySize",
      default: null,
      index: true,
    },
    customConfigKey: {
      type: String,
      default: "",
      trim: true,
    },
    durationMinutes: {
      type: Number,
      required: true,
      min: 15,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const ServiceDuration = mongoose.model("ServiceDuration", serviceDurationSchema);

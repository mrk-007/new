import mongoose from "mongoose";

const skillSchema = new mongoose.Schema(
  {
    skillCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    skillName: {
      type: String,
      required: [true, "Skill name is required"],
      unique: true,
      trim: true,
      index: true,
    },
    category: {
      type: String,
      default: "Installation", // Installation or Cleaning
      trim: true,
      index: true,
    },
    description: {
      type: String,
      default: "",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const Skill = mongoose.model("Skill", skillSchema);

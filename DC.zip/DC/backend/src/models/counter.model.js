import mongoose from "mongoose";

const counterSchema = new mongoose.Schema(
  {
    entityKey: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    prefix: {
      type: String,
      required: true,
      default: "JHN",
      trim: true,
    },
    seq: {
      type: Number,
      required: true,
      default: 0,
    },
    padding: {
      type: Number,
      default: 6,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

/**
 * Atomic helper to get next sequential formatted code.
 * E.g., JHN-ORD-000101 or CUS-000001
 */
counterSchema.statics.getNextSequence = async function (entityKey, customPrefix = null, customPadding = null) {
  const filter = { entityKey };
  const update = { $inc: { seq: 1 } };
  const options = { new: true, upsert: true, setDefaultsOnInsert: true };

  const counter = await this.findOneAndUpdate(filter, update, options);
  const prefix = customPrefix || counter.prefix;
  const padding = customPadding || counter.padding;
  const paddedNumber = String(counter.seq).padStart(padding, "0");

  return `${prefix}-${paddedNumber}`;
};

export const Counter = mongoose.model("Counter", counterSchema);

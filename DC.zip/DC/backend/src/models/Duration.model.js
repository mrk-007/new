/**
 * @file Duration.model.js
 * @description Job duration in minutes for exactly one of bathroom, property, or product.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { AppError } from "../utils/appError.js";

const durationSchema = new mongoose.Schema({
  bathroomCount: { type: mongoose.Schema.Types.ObjectId, ref: "BathroomCount", default: null },
  propertySize: { type: mongoose.Schema.Types.ObjectId, ref: "PropertySize", default: null },
  product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", default: null },
  minutes: { type: Number, required: true, min: 1 },
  isActive: { type: Boolean, default: true, index: true },
});

/** Counts how many duration targets are set. */
const targetCount = (doc) =>
  [doc.bathroomCount, doc.propertySize, doc.product].filter(Boolean).length;

/** Rejects zero or multiple duration targets. */
durationSchema.pre("validate", function ensureSingleTarget(next) {
  if (targetCount(this) !== 1) {
    return next(new AppError(422, "Duration must target exactly one of bathroomCount, propertySize, or product."));
  }
  next();
});

durationSchema.index({ bathroomCount: 1 }, { unique: true, partialFilterExpression: { bathroomCount: { $type: "objectId" } } });
durationSchema.index({ propertySize: 1 }, { unique: true, partialFilterExpression: { propertySize: { $type: "objectId" } } });
durationSchema.index({ product: 1 }, { unique: true, partialFilterExpression: { product: { $type: "objectId" } } });

durationSchema.plugin(basePlugin);

export const Duration = mongoose.model("Duration", durationSchema);

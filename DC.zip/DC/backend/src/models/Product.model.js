/**
 * @file Product.model.js
 * @description One-time product catalog used by orders.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const productSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, trim: true, uppercase: true },
  name: { type: String, required: true, trim: true },
  serviceType: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceType", required: true },
  requiresSiteVisit: { type: Boolean, default: false },
  siteVisitMinutes: { type: Number, default: 30 },
  description: { type: String, trim: true },
  isActive: { type: Boolean, default: true, index: true },
});

productSchema.plugin(basePlugin);

export const Product = mongoose.model("Product", productSchema);

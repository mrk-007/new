/**
 * @file JobOrder.model.js
 * @description Service execution job order schema for field technician dispatch and status tracking.
 */
import mongoose from "mongoose";

const jobOrderSchema = new mongoose.Schema(
  {
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      required: true,
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
    },
    work: {
      type: String,
      required: true,
      trim: true,
    },
    technician: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Technician",
      required: true,
    },
    serviceDate: {
      type: Date,
      required: true,
    },
    timeSlot: {
      type: String,
      required: true,
      trim: true,
    },
    arrivalStatus: {
      type: String,
      required: true,
      default: "ON_TIME",
      trim: true,
    },
    arrivalDelayMinutes: {
      type: Number,
      default: 0,
    },
    workStatus: {
      type: String,
      required: true,
      default: "ASSIGNED",
      trim: true,
    },
    followUpStatus: {
      type: String,
      required: true,
      default: "NONE",
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

export const JobOrder = mongoose.model("JobOrder", jobOrderSchema);
export default JobOrder;

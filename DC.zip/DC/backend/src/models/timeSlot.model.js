import mongoose from "mongoose";

const timeSlotSchema = new mongoose.Schema(
  {
    slotCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    label: {
      type: String,
      required: true, // "09:00 - 10:30"
      trim: true,
    },
    startTime: {
      type: String,
      required: true, // "09:00"
      trim: true,
    },
    endTime: {
      type: String,
      required: true, // "10:30"
      trim: true,
    },
    displayOrder: {
      type: Number,
      default: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const TimeSlot = mongoose.model("TimeSlot", timeSlotSchema);

import mongoose from "mongoose";

const subscriptionPlanSchema = new mongoose.Schema(
  {
    planCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    planName: {
      type: String,
      required: true,
      trim: true,
    },
    serviceType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "ServiceType",
      required: true,
      index: true,
    },
    frequency: {
      type: String,
      required: true, // "Once Every Week" or "Once in 2 Weeks"
      trim: true,
    },
    totalVisits: {
      type: Number,
      required: true,
      min: 1,
    },
    intervalDays: {
      type: Number,
      required: true,
      default: 7, // 7 for weekly, 14 for bi-weekly
    },
    displayOrder: {
      type: Number,
      default: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const SubscriptionPlan = mongoose.model("SubscriptionPlan", subscriptionPlanSchema);

/**
 * @file User.model.js
 * @description Authentication user with bcrypt password hashing.
 */
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import { basePlugin } from "./plugins/base.plugin.js";

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, select: false },
  role: { type: mongoose.Schema.Types.ObjectId, ref: "Role", required: true },
  isActive: { type: Boolean, default: true, index: true },
  lastLoginAt: { type: Date },
});

userSchema.plugin(basePlugin);

/** Hashes the password when it has been modified. */
userSchema.pre("save", async function hashPassword(next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

/** Compares a candidate password with the stored hash. */
userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password);
};

/** Strips password from JSON output. */
userSchema.methods.toJSON = function toJSON() {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

export const User = mongoose.model("User", userSchema);

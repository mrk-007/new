/**
 * @file TechnicianAllocation.model.js
 * @description Assignment of a technician to a visit.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { ALLOCATION_STATUS } from "../constants/index.js";

const technicianAllocationSchema = new mongoose.Schema({
  technician: { type: mongoose.Schema.Types.ObjectId, ref: "Technician", required: true, index: true },
  visit: { type: mongoose.Schema.Types.ObjectId, ref: "Visit", required: true },
  subscription: { type: mongoose.Schema.Types.ObjectId, ref: "Subscription", default: null },
  order: { type: mongoose.Schema.Types.ObjectId, ref: "Order", default: null },
  allocatedAt: { type: Date, default: Date.now },
  status: { type: String, enum: Object.values(ALLOCATION_STATUS), default: ALLOCATION_STATUS.ASSIGNED, index: true },
  releaseReason: { type: String, trim: true },
});

technicianAllocationSchema.index(
  { visit: 1 },
  { unique: true, partialFilterExpression: { status: ALLOCATION_STATUS.ASSIGNED } }
);

technicianAllocationSchema.plugin(basePlugin);

export const TechnicianAllocation = mongoose.model("TechnicianAllocation", technicianAllocationSchema);

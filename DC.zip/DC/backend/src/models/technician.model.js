import mongoose from "mongoose";

const technicianSchema = new mongoose.Schema(
  {
    techId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
      index: true,
    },
    name: {
      type: String,
      required: [true, "Technician name is required"],
      trim: true,
      index: true,
    },
    mobile: {
      type: String,
      required: [true, "Technician mobile is required"],
      trim: true,
    },
    role: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "TechnicianRole",
      required: true,
      index: true,
    },
    roleTitle: {
      type: String,
      required: true,
      trim: true,
    },
    area: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Area",
      default: null,
      index: true,
    },
    baseArea: {
      type: String,
      required: true,
      trim: true,
      index: true,
    },
    dailyCapacity: {
      type: Number,
      required: true,
      default: 5,
      min: 1,
    },
    skills: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Skill",
      },
    ],
    skillNames: [
      {
        type: String,
        trim: true,
      },
    ],
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

technicianSchema.virtual("assignedJobs", {
  ref: "JobOrder",
  localField: "_id",
  foreignField: "technician",
});

export const Technician = mongoose.model("Technician", technicianSchema);

/**
 * @file SubscriptionTerm.model.js
 * @description Subscription duration in months.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const subscriptionTermSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  months: { type: Number, required: true, min: 1 },
  isActive: { type: Boolean, default: true, index: true },
});

subscriptionTermSchema.plugin(basePlugin);

export const SubscriptionTerm = mongoose.model("SubscriptionTerm", subscriptionTermSchema);

import mongoose from "mongoose";

const propertySizeSchema = new mongoose.Schema(
  {
    sizeCode: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
      index: true,
    },
    label: {
      type: String,
      required: true,
      trim: true,
    },
    defaultDurationMinutes: {
      type: Number,
      required: true,
      default: 240,
    },
    displayOrder: {
      type: Number,
      default: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const PropertySize = mongoose.model("PropertySize", propertySizeSchema);

import mongoose from "mongoose";

const followUpSchema = new mongoose.Schema(
  {
    jobOrder: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "JobOrder",
      required: true,
      index: true,
    },
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
      index: true,
    },
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order",
      required: true,
      index: true,
    },
    status: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "FollowUpStatus",
      default: null,
      index: true,
    },
    statusLabel: {
      type: String,
      default: "Pending",
      trim: true,
    },
    remarks: {
      type: String,
      default: "",
      trim: true,
    },
    followUpDate: {
      type: Date,
      default: Date.now,
    },
    resolvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const FollowUp = mongoose.model("FollowUp", followUpSchema);

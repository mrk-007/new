/**
 * @file Apartment.model.js
 * @description Apartment community master.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const apartmentSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true, trim: true },
  landmark: { type: String, trim: true },
  isActive: { type: Boolean, default: true, index: true },
});

apartmentSchema.plugin(basePlugin);

export const Apartment = mongoose.model("Apartment", apartmentSchema);

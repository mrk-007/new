import mongoose from "mongoose";

const bathroomCountSchema = new mongoose.Schema(
  {
    countValue: {
      type: Number,
      required: true,
      unique: true,
      min: 1,
      max: 10,
      index: true,
    },
    label: {
      type: String,
      required: true,
      trim: true,
    },
    defaultDurationMinutes: {
      type: Number,
      required: true,
      default: 90,
    },
    displayOrder: {
      type: Number,
      default: 0,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const BathroomCount = mongoose.model("BathroomCount", bathroomCountSchema);

/**
 * @file Address.model.js
 * @description Customer service address.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { ADDRESS_LABELS } from "../constants/index.js";

const addressSchema = new mongoose.Schema({
  customer: { type: mongoose.Schema.Types.ObjectId, ref: "Customer", required: true, index: true },
  label: { type: String, enum: ADDRESS_LABELS, default: "Home" },
  apartment: { type: mongoose.Schema.Types.ObjectId, ref: "Apartment", default: null },
  doorNo: { type: String, trim: true },
  street: { type: String, trim: true },
  area: { type: String, trim: true },
  city: { type: String, required: true, trim: true },
  state: { type: String, required: true, trim: true },
  pincode: { type: String, trim: true },
  isDefault: { type: Boolean, default: false },
  isActive: { type: Boolean, default: true, index: true },
});

addressSchema.plugin(basePlugin);

export const Address = mongoose.model("Address", addressSchema);

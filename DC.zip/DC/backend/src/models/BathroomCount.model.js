/**
 * @file BathroomCount.model.js
 * @description Bathroom count master used by bathroom-cleaning pricing.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const bathroomCountSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  count: { type: Number, required: true, min: 1, max: 4 },
  isActive: { type: Boolean, default: true, index: true },
});

bathroomCountSchema.plugin(basePlugin);

export const BathroomCount = mongoose.model("BathroomCount", bathroomCountSchema);

import mongoose from "mongoose";

const schedulingRuleSchema = new mongoose.Schema(
  {
    ruleKey: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },
    ruleName: {
      type: String,
      required: true,
      trim: true,
    },
    ruleValue: {
      type: mongoose.Schema.Types.Mixed,
      required: true,
    },
    unit: {
      type: String,
      default: "minutes",
      trim: true,
    },
    description: {
      type: String,
      default: "",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const SchedulingRule = mongoose.model("SchedulingRule", schedulingRuleSchema);

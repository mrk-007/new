/**
 * @file Pricing.model.js
 * @description Manually entered price rows for order products and subscription combinations.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";
import { AppError } from "../utils/appError.js";
import { PRICING_BASIS, SERVICE_TYPE_CODE } from "../constants/index.js";
import { ServiceType } from "./ServiceType.model.js";
import { SubscriptionPlan } from "./SubscriptionPlan.model.js";

const pricingSchema = new mongoose.Schema({
  serviceType: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceType", required: true },
  product: { type: mongoose.Schema.Types.ObjectId, ref: "Product", default: null },
  subscriptionPlan: { type: mongoose.Schema.Types.ObjectId, ref: "SubscriptionPlan", default: null },
  serviceFrequency: { type: mongoose.Schema.Types.ObjectId, ref: "ServiceFrequency", default: null },
  subscriptionTerm: { type: mongoose.Schema.Types.ObjectId, ref: "SubscriptionTerm", default: null },
  bathroomCount: { type: mongoose.Schema.Types.ObjectId, ref: "BathroomCount", default: null },
  propertySize: { type: mongoose.Schema.Types.ObjectId, ref: "PropertySize", default: null },
  price: { type: Number, required: true, min: 0 },
  isActive: { type: Boolean, default: true, index: true },
});

/** Enforces ORDER vs SUBSCRIPTION field combinations. */
pricingSchema.pre("validate", async function enforceCombination(next) {
  try {
    const serviceType = await ServiceType.findById(this.serviceType);
    if (!serviceType) {
      return next(new AppError(422, "Service type not found."));
    }

    if (serviceType.code === SERVICE_TYPE_CODE.ORDER) {
      if (!this.product) return next(new AppError(422, "Product is required for ORDER pricing."));
      this.subscriptionPlan = null;
      this.serviceFrequency = null;
      this.subscriptionTerm = null;
      this.bathroomCount = null;
      this.propertySize = null;
      return next();
    }

    if (serviceType.code === SERVICE_TYPE_CODE.SUBSCRIPTION) {
      if (!this.subscriptionPlan || !this.serviceFrequency || !this.subscriptionTerm) {
        return next(new AppError(422, "Plan, frequency and term are required for SUBSCRIPTION pricing."));
      }
      const plan = await SubscriptionPlan.findById(this.subscriptionPlan);
      if (!plan) return next(new AppError(422, "Subscription plan not found."));
      this.product = null;
      if (plan.pricingBasis === PRICING_BASIS.BATHROOM_COUNT) {
        if (!this.bathroomCount) return next(new AppError(422, "Bathroom count is required for this plan."));
        this.propertySize = null;
      } else {
        if (!this.propertySize) return next(new AppError(422, "Property size is required for this plan."));
        this.bathroomCount = null;
      }
      return next();
    }

    return next(new AppError(422, "Unknown service type for pricing."));
  } catch (err) {
    next(err);
  }
});

pricingSchema.index(
  {
    serviceType: 1,
    product: 1,
    subscriptionPlan: 1,
    serviceFrequency: 1,
    subscriptionTerm: 1,
    bathroomCount: 1,
    propertySize: 1,
  },
  { unique: true }
);

pricingSchema.plugin(basePlugin);

export const Pricing = mongoose.model("Pricing", pricingSchema);

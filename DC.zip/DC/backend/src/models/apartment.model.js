import mongoose from "mongoose";

const apartmentSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Apartment or Community name is required"],
      unique: true,
      trim: true,
      index: true,
    },
    area: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Area",
      required: [true, "Area reference is required"],
      index: true,
    },
    address: {
      type: String,
      default: "",
      trim: true,
    },
    landmark: {
      type: String,
      default: "",
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

export const Apartment = mongoose.model("Apartment", apartmentSchema);

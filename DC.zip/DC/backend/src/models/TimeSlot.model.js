/**
 * @file TimeSlot.model.js
 * @description Working-window configuration used to generate bookable slots.
 */
import mongoose from "mongoose";
import { basePlugin } from "./plugins/base.plugin.js";

const timeSlotSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  startTime: { type: String, required: true },
  endTime: { type: String, required: true },
  bufferMinutes: { type: Number, default: 0, min: 0 },
  isActive: { type: Boolean, default: true, index: true },
});

timeSlotSchema.plugin(basePlugin);

export const TimeSlot = mongoose.model("TimeSlot", timeSlotSchema);

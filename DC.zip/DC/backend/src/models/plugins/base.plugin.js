/**
 * @file base.plugin.js
 * @description Adds createdBy, updatedBy, and Mongoose timestamps to every schema.
 */
import mongoose from "mongoose";

const { Schema } = mongoose;

/** Attaches audit actor refs and createdAt/updatedAt timestamps. */
export const basePlugin = (schema) => {
  schema.add({
    createdBy: { type: Schema.Types.ObjectId, ref: "User" },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User" },
  });
  schema.set("timestamps", true);
};

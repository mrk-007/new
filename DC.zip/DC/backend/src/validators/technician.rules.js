/**
 * @file technician.rules.js
 * @description Body rules for technicians and skill matrix updates.
 */
import { required, isString, isEmail, isMobile, isBoolean, isObjectId } from "./rules.js";

export const createTechnicianRules = {
  name: [required, isString],
  mobile: [required, isMobile],
  email: [isEmail],
  user: [isObjectId],
  isAvailable: [isBoolean],
};

export const updateTechnicianRules = {
  name: [isString],
  mobile: [isMobile],
  email: [isEmail],
  user: [isObjectId],
  isAvailable: [isBoolean],
};

export const availabilityRules = {
  isAvailable: [required, isBoolean],
};

/**
 * @file rules.js
 * @description Tiny hand-written field validators used by validateBody schemas.
 */
import { isValidObjectId } from "../utils/objectId.js";

/** Fails when the value is missing. */
export const required = (value) =>
  value === undefined || value === null || value === "" ? "is required" : null;

/** Fails when the value is present and not a string. */
export const isString = (value) =>
  value === undefined || value === null || typeof value === "string" ? null : "must be a string";

/** Fails when the value is present and not a valid email. */
export const isEmail = (value) => {
  if (value === undefined || value === null || value === "") return null;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? null : "must be a valid email";
};

/** Fails when the value is present and not a 10-digit mobile number. */
export const isMobile = (value) => {
  if (value === undefined || value === null || value === "") return null;
  return /^[6-9]\d{9}$/.test(String(value)) ? null : "must be a valid 10-digit mobile number";
};

/** Builds a numeric range rule. */
export const isNumber = ({ min, max } = {}) => (value) => {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "number" || Number.isNaN(value)) return "must be a number";
  if (min !== undefined && value < min) return `must be at least ${min}`;
  if (max !== undefined && value > max) return `must be at most ${max}`;
  return null;
};

/** Fails when the value is present and not a boolean. */
export const isBoolean = (value) =>
  value === undefined || value === null || typeof value === "boolean" ? null : "must be a boolean";

/** Fails when the value is present and not a 24-hex ObjectId. */
export const isObjectId = (value) => {
  if (value === undefined || value === null || value === "") return null;
  return isValidObjectId(String(value)) ? null : "must be a valid id";
};

/** Builds an allow-list enum rule. */
export const isEnum = (list) => (value) => {
  if (value === undefined || value === null || value === "") return null;
  return list.includes(value) ? null : `must be one of: ${list.join(", ")}`;
};

/** Fails when the value is present and not YYYY-MM-DD. */
export const isDateString = (value) => {
  if (value === undefined || value === null || value === "") return null;
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? null : "must be a date (YYYY-MM-DD)";
};

/** Fails when the value is present and not HH:mm. */
export const isTime = (value) => {
  if (value === undefined || value === null || value === "") return null;
  return /^([01]\d|2[0-3]):[0-5]\d$/.test(value) ? null : "must be a time (HH:mm)";
};

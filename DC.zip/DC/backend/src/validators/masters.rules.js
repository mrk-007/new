/**
 * @file masters.rules.js
 * @description Body rules for master-data create payloads.
 */
import { required, isString, isBoolean, isNumber, isObjectId, isEnum, isTime } from "./rules.js";
import { PRICING_BASIS, SERVICE_TYPE_CODE } from "../constants/index.js";

export const roleRules = {
  roleName: [required, isString],
  isRead: [isBoolean],
  isWrite: [isBoolean],
  isDelete: [isBoolean],
};

export const apartmentRules = {
  name: [required, isString],
  landmark: [isString],
};

export const serviceTypeRules = {
  code: [required, isEnum(Object.values(SERVICE_TYPE_CODE))],
  name: [required, isString],
};

export const productRules = {
  code: [required, isString],
  name: [required, isString],
  serviceType: [required, isObjectId],
  requiresSiteVisit: [isBoolean],
  siteVisitMinutes: [isNumber({ min: 1 })],
  description: [isString],
};

export const subscriptionPlanRules = {
  code: [required, isString],
  name: [required, isString],
  serviceType: [required, isObjectId],
  pricingBasis: [required, isEnum(Object.values(PRICING_BASIS))],
  requiresSiteVisit: [isBoolean],
  siteVisitMinutes: [isNumber({ min: 1 })],
};

export const subscriptionTermRules = {
  name: [required, isString],
  months: [required, isNumber({ min: 1 })],
};

export const serviceFrequencyRules = {
  name: [required, isString],
  intervalDays: [required, isNumber({ min: 1 })],
};

export const bathroomCountRules = {
  name: [required, isString],
  count: [required, isNumber({ min: 1, max: 4 })],
};

export const propertySizeRules = {
  name: [required, isString],
  bedrooms: [required, isNumber({ min: 1 })],
};

export const durationRules = {
  bathroomCount: [isObjectId],
  propertySize: [isObjectId],
  product: [isObjectId],
  minutes: [required, isNumber({ min: 1 })],
};

export const pricingRules = {
  serviceType: [required, isObjectId],
  product: [isObjectId],
  subscriptionPlan: [isObjectId],
  serviceFrequency: [isObjectId],
  subscriptionTerm: [isObjectId],
  bathroomCount: [isObjectId],
  propertySize: [isObjectId],
  price: [required, isNumber({ min: 0 })],
};

export const timeSlotRules = {
  name: [required, isString],
  startTime: [required, isTime],
  endTime: [required, isTime],
  bufferMinutes: [isNumber({ min: 0 })],
};

export const taxRules = {
  state: [required, isString],
  city: [isString],
  cgstRate: [required, isNumber({ min: 0 })],
  sgstRate: [required, isNumber({ min: 0 })],
};

export const skillRules = {
  code: [required, isString],
  name: [required, isString],
  product: [isObjectId],
  subscriptionPlan: [isObjectId],
};

import { z } from "zod";

export const calculateQuoteSchema = z.object({
  body: z.object({
    productId: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid product ID"),
    variantId: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid variant ID").optional().nullable(),
    orderMode: z.enum(["Product Installation", "Bathroom Cleaning", "Deep Cleaning"]),
    configValue: z.string().optional(), // bathroom count "60"/"90" or BHK "180"/"240"
    planName: z.string().optional(),
    startTime: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Start time must be in HH:MM format").default("09:00"),
    discount: z.number().min(0).default(0),
  }),
});

export const createOrderSchema = z.object({
  body: z.object({
    customerId: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid customer ID"),
    propertyId: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid property ID"),
    orderMode: z.enum(["Product Installation", "Bathroom Cleaning", "Deep Cleaning"]),
    serviceName: z.string({ required_error: "Service name is required" }).trim().min(2),
    productId: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid product ID").optional().nullable(),
    config: z.string().trim().default(""),
    plan: z.string().trim().default(""),
    serviceDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Service date must be in YYYY-MM-DD format"),
    startTime: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Start time must be in HH:MM format"),
    technicianId: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid technician ID"),
    travelBufferMinutes: z.number().default(30),
    paymentMode: z.enum(["UPI", "Cash", "Bank Transfer"]).default("UPI"),
    transactionRef: z.string().trim().optional().or(z.literal("")),
    discount: z.number().min(0).default(0),
  }),
});

export const updateSubscriptionStatusSchema = z.object({
  body: z.object({
    status: z.enum(["Active", "Paused", "Cancelled", "Completed"]),
  }),
});

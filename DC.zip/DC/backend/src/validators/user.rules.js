/**
 * @file user.rules.js
 * @description Body rules for user updates.
 */
import { isEmail, isString, isObjectId, isBoolean } from "./rules.js";

export const updateUserRules = {
  email: [isEmail],
  password: [isString],
  role: [isObjectId],
  isActive: [isBoolean],
};

import { z } from "zod";

export const createCustomerSchema = z.object({
  body: z.object({
    name: z.string({ required_error: "Customer name is required" }).trim().min(2),
    mobile: z
      .string({ required_error: "Mobile number is required" })
      .trim()
      .regex(/^[0-9]{10}$/, "Mobile must be a valid 10-digit number"),
    whatsapp: z.string().trim().optional().or(z.literal("")),
    email: z.string().email("Invalid email format").optional().or(z.literal("")),
    property: z.object({
      label: z.enum(["Home", "Office", "Other"]).default("Home"),
      propertyName: z.string({ required_error: "Property or apartment name is required" }).trim().min(2),
      door: z.string().trim().optional().or(z.literal("")),
      areaName: z.string({ required_error: "Area is required" }).trim().min(2),
      address: z.string().trim().optional().or(z.literal("")),
    }),
  }),
});

export const updateCustomerSchema = z.object({
  body: z.object({
    name: z.string().trim().min(2).optional(),
    mobile: z.string().trim().regex(/^[0-9]{10}$/, "Mobile must be a valid 10-digit number").optional(),
    whatsapp: z.string().trim().optional().or(z.literal("")),
    email: z.string().email().optional().or(z.literal("")),
    statusId: z.string().regex(/^[0-9a-fA-F]{24}$/).optional(),
    isActive: z.boolean().optional(),
  }),
});

export const addPropertySchema = z.object({
  body: z.object({
    label: z.enum(["Home", "Office", "Other"]).default("Home"),
    propertyName: z.string({ required_error: "Property name is required" }).trim().min(2),
    door: z.string().trim().optional().or(z.literal("")),
    areaName: z.string({ required_error: "Area is required" }).trim().min(2),
    address: z.string().trim().optional().or(z.literal("")),
    isDefault: z.boolean().default(false),
  }),
});

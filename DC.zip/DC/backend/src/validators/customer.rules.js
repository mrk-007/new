/**
 * @file customer.rules.js
 * @description Body rules for customer create and update.
 */
import { required, isString, isEmail, isMobile } from "./rules.js";

export const createCustomerRules = {
  fullName: [required, isString],
  mobile: [required, isMobile],
  alternateMobile: [isMobile],
  email: [isEmail],
  notes: [isString],
};

export const updateCustomerRules = {
  fullName: [isString],
  mobile: [isMobile],
  alternateMobile: [isMobile],
  email: [isEmail],
  notes: [isString],
  isActive: [],
};

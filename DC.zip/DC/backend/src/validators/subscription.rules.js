/**
 * @file subscription.rules.js
 * @description Body rules for subscription create and cancel.
 */
import { required, isObjectId, isDateString, isTime, isString } from "./rules.js";

export const createSubscriptionRules = {
  customer: [required, isObjectId],
  address: [required, isObjectId],
  subscriptionPlan: [required, isObjectId],
  subscriptionTerm: [required, isObjectId],
  serviceFrequency: [required, isObjectId],
  bathroomCount: [isObjectId],
  propertySize: [isObjectId],
  startDate: [required, isDateString],
  preferredStartTime: [required, isTime],
};

export const cancelSubscriptionRules = {
  cancelReason: [isString],
};

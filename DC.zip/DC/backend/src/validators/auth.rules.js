/**
 * @file auth.rules.js
 * @description Body rules for login and user creation.
 */
import { required, isString, isEmail, isObjectId } from "./rules.js";

export const loginRules = {
  email: [required, isString, isEmail],
  password: [required, isString],
};

export const createUserRules = {
  email: [required, isString, isEmail],
  password: [required, isString],
  role: [required, isObjectId],
};

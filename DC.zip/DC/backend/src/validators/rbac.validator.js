import { z } from "zod";

export const createUserSchema = z.object({
  body: z.object({
    username: z.string().trim().min(3).max(30),
    fullName: z.string().trim().min(2),
    email: z.string().email().optional().or(z.literal("")),
    mobile: z.string().trim().min(10).optional().or(z.literal("")),
    password: z.string().min(8, "Password must be at least 8 characters"),
    roleId: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid role ObjectId"),
    technicianId: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid technician ObjectId").optional().nullable(),
  }),
});

export const updateUserSchema = z.object({
  body: z.object({
    fullName: z.string().trim().min(2).optional(),
    email: z.string().email().optional().or(z.literal("")),
    mobile: z.string().trim().min(10).optional().or(z.literal("")),
    roleId: z.string().regex(/^[0-9a-fA-F]{24}$/, "Invalid role ObjectId").optional(),
    isActive: z.boolean().optional(),
    resetLockout: z.boolean().optional(),
  }),
});

export const createRoleSchema = z.object({
  body: z.object({
    roleKey: z.string().trim().min(2).max(40),
    roleName: z.string().trim().min(2).max(50),
    description: z.string().trim().optional(),
  }),
});

export const updateRoleSchema = z.object({
  body: z.object({
    roleName: z.string().trim().min(2).max(50).optional(),
    description: z.string().trim().optional(),
    isActive: z.boolean().optional(),
  }),
});

export const updateRolePermissionsSchema = z.object({
  body: z.object({
    permissions: z.array(
      z.object({
        moduleKey: z.string().trim(),
        isRead: z.boolean().default(false),
        isWrite: z.boolean().default(false),
        isDelete: z.boolean().default(false),
      })
    ),
  }),
});

export const createModuleSchema = z.object({
  body: z.object({
    moduleKey: z.string().trim().min(2),
    moduleName: z.string().trim().min(2),
    routePath: z.string().trim().min(1),
    category: z.string().trim().default("Operations"),
    displayOrder: z.number().default(0),
    icon: z.string().optional(),
  }),
});

export const updateModuleSchema = z.object({
  body: z.object({
    moduleName: z.string().trim().min(2).optional(),
    routePath: z.string().trim().min(1).optional(),
    category: z.string().trim().optional(),
    displayOrder: z.number().optional(),
    icon: z.string().optional(),
    isActive: z.boolean().optional(),
  }),
});

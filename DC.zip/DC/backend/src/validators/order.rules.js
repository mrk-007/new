/**
 * @file order.rules.js
 * @description Body rules for order create, confirm, cancel, and status changes.
 */
import { required, isObjectId, isNumber, isDateString, isTime, isString, isEnum } from "./rules.js";
import { ORDER_STATUS } from "../constants/index.js";

export const createOrderRules = {
  customer: [required, isObjectId],
  address: [required, isObjectId],
  product: [required, isObjectId],
  quantity: [isNumber({ min: 1 })],
  date: [required, isDateString],
  startTime: [required, isTime],
};

export const confirmOrderRules = {
  date: [isDateString],
  startTime: [isTime],
};

export const cancelOrderRules = {
  cancelReason: [isString],
};

export const patchOrderStatusRules = {
  status: [required, isEnum(Object.values(ORDER_STATUS))],
  note: [isString],
};

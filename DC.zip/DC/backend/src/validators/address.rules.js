/**
 * @file address.rules.js
 * @description Body rules for customer addresses.
 */
import { required, isString, isObjectId, isBoolean, isEnum } from "./rules.js";
import { ADDRESS_LABELS } from "../constants/index.js";

export const createAddressRules = {
  label: [isEnum(ADDRESS_LABELS)],
  apartment: [isObjectId],
  doorNo: [isString],
  street: [isString],
  area: [isString],
  city: [required, isString],
  state: [required, isString],
  pincode: [isString],
  isDefault: [isBoolean],
};

export const updateAddressRules = {
  label: [isEnum(ADDRESS_LABELS)],
  apartment: [isObjectId],
  doorNo: [isString],
  street: [isString],
  area: [isString],
  city: [isString],
  state: [isString],
  pincode: [isString],
  isDefault: [isBoolean],
};

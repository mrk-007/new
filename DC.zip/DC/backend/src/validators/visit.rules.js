/**
 * @file visit.rules.js
 * @description Body rules for visit complete, cancel, and reassign.
 */
import { required, isString, isNumber, isObjectId } from "./rules.js";

export const completeVisitRules = {
  notes: [isString],
  width: [isNumber({ min: 0 })],
  height: [isNumber({ min: 0 })],
  unit: [isString],
  quotedAmount: [isNumber({ min: 0 })],
};

export const cancelVisitRules = {
  cancelReason: [isString],
};

export const reassignVisitRules = {
  technicianId: [isObjectId],
};

export const allocateVisitRules = {
  technicianId: [isObjectId],
};

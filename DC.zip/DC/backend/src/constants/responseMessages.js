/**
 * Standard API Response Messages.
 */
export const RESPONSE_MESSAGES = Object.freeze({
  SUCCESS: "Operation completed successfully.",
  CREATED: "Resource created successfully.",
  UPDATED: "Resource updated successfully.",
  DELETED: "Resource deleted successfully.",
  NOT_FOUND: "Requested resource not found.",
  BAD_REQUEST: "Invalid request payload or parameters.",
  UNAUTHORIZED: "Authentication required or invalid token.",
  FORBIDDEN: "You do not have permission to perform this action.",
  CONFLICT: "Resource state conflict detected.",
  SERVER_ERROR: "Internal server error. Please try again later.",
  ROUTE_NOT_FOUND: "The requested API endpoint does not exist.",
  RATE_LIMIT_EXCEEDED: "Too many requests. Please slow down and try again later.",
  HEALTH_OK: "System operational and healthy.",
});

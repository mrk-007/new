/**
 * Application Constants and System Defaults.
 */
export const APP_CONSTANTS = Object.freeze({
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: 10,
  MAX_LIMIT: 100,
  DEFAULT_SORT_FIELD: "createdAt",
  DEFAULT_SORT_ORDER: -1,
  ROLES: {
    SUPER_ADMIN: "super_admin",
    TELECALLER: "telecaller",
    TECHNICIAN: "technician",
  },
  MODULES: {
    DASHBOARD: "dashboard",
    CUSTOMERS: "customers",
    ORDERS: "orders",
    SUBSCRIPTIONS: "subscriptions",
    JOBS: "jobs",
    SCHEDULE: "schedule",
    TECHNICIANS: "technicians",
    CATALOG: "catalog",
    INVOICES: "invoices",
    CONFIGURATION: "configuration",
    TECH_JOBS: "tech_jobs",
    TECH_CALENDAR: "tech_calendar",
    TECH_HISTORY: "tech_history",
    TECH_PROFILE: "tech_profile",
  },
});

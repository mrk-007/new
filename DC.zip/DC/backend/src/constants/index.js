/**
 * @file index.js
 * @description System-wide constants, master types, and status enumerations.
 */
export const MASTER_TYPES = {
  LIFECYCLE_META: "lifecycle_meta",
  LIFECYCLE_STEP: "lifecycle_step",
  ARRIVAL_STATUS: "arrival_status",
  WORK_STATUS: "work_status",
  FOLLOW_UP_STATUS: "follow_up_status",
  ORDER_STATUS: "order_status",
  PAYMENT_STATUS: "payment_status",
  PAYMENT_METHOD: "payment_method",
  TIME_SLOT: "time_slot",
};

export const ORDER_STATUSES = {
  CONFIRMED: "CONFIRMED",
  RESCHEDULED: "RESCHEDULED",
  COMPLETED: "COMPLETED",
  CANCELLED: "CANCELLED",
};

export const PAYMENT_STATUSES = {
  UNPAID: "UNPAID",
  PARTIALLY_PAID: "PARTIALLY_PAID",
  PAID: "PAID",
};

export const ARRIVAL_STATUSES = {
  ON_TIME: "ON_TIME",
  LATE: "LATE",
};

export const WORK_STATUSES = {
  ASSIGNED: "ASSIGNED",
  ON_THE_WAY: "ON_THE_WAY",
  REACHED: "REACHED",
  WORK_STARTED: "WORK_STARTED",
  IN_PROGRESS: "IN_PROGRESS",
  COMPLETED: "COMPLETED",
  CLOSED: "CLOSED",
};

export const FOLLOW_UP_STATUSES = {
  NONE: "NONE",
  PENDING: "PENDING",
  COMPLETED: "COMPLETED",
};

export const SUBSCRIPTION_STATUSES = {
  ACTIVE: "ACTIVE",
  PAUSED: "PAUSED",
  CANCELLED: "CANCELLED",
};

export const USER_ROLES = {
  ADMIN: "admin",
  TECHNICIAN: "technician",
};

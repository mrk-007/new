/**
 * @file index.js
 * @description Shared enums, timezone, lifecycle copy, and catalog display metadata.
 */

export const TIMEZONE = "Asia/Kolkata";
export const TIMEZONE_OFFSET = "+05:30";
export const IST_OFFSET_MINUTES = 330;

export const VISIT_STATUS = {
  PENDING: "PENDING",
  IN_PROGRESS: "IN_PROGRESS",
  COMPLETED: "COMPLETED",
  CANCELLED: "CANCELLED",
};

export const ORDER_STATUS = {
  PENDING: "PENDING",
  SITE_VISIT_PENDING: "SITE_VISIT_PENDING",
  QUOTED: "QUOTED",
  CONFIRMED: "CONFIRMED",
  IN_PROGRESS: "IN_PROGRESS",
  COMPLETED: "COMPLETED",
  CANCELLED: "CANCELLED",
};

export const VISIT_TYPE = {
  SITE_VISIT: "SITE_VISIT",
  SERVICE: "SERVICE",
};

export const AUDIT_ACTION = {
  CREATE: "CREATE",
  UPDATE: "UPDATE",
  DELETE: "DELETE",
};

export const PRICING_BASIS = {
  PROPERTY_SIZE: "PROPERTY_SIZE",
  BATHROOM_COUNT: "BATHROOM_COUNT",
};

export const SERVICE_TYPE_CODE = {
  ORDER: "ORDER",
  SUBSCRIPTION: "SUBSCRIPTION",
};

export const ALLOCATION_STATUS = {
  ASSIGNED: "ASSIGNED",
  RELEASED: "RELEASED",
};

export const ADDRESS_LABELS = ["Home", "Office", "Other"];

export const PERMISSION = {
  READ: "read",
  WRITE: "write",
  DELETE: "delete",
};

export const ROLE_NAME = {
  ADMIN: "Admin",
  MANAGER: "Manager",
  TECHNICIAN: "Technician",
};

export const PRODUCT_CODE = {
  HANGER: "HANGER",
  SHOE_RACK: "SHOE_RACK",
  MOSQUITO_NET: "MOSQUITO_NET",
};

export const PLAN_CODE = {
  DEEP_CLEANING: "DEEP_CLEANING",
  BATHROOM_CLEANING: "BATHROOM_CLEANING",
};

export const LIFECYCLE = {
  title: "Urban-style Job Lifecycle",
  steps: [
    "Booking Confirmed",
    "Professional Assigned",
    "On the Way",
    "Reached",
    "Work Started",
    "Completed",
    "Customer Follow-up",
    "Closed",
  ],
  notice:
    "Installation and cleaning use the same execution controls: date and slot, assignment, reach tracking, work start/completion, customer confirmation and closure.",
};

export const CATALOG_META = {
  HANGER: { iconKey: "handyman", group: "Product" },
  SHOE_RACK: { iconKey: "build", group: "Product" },
  MOSQUITO_NET: { iconKey: "auto_awesome", group: "Product" },
  DEEP_CLEANING: { iconKey: "cleaning_services", group: "Subscription" },
  BATHROOM_CLEANING: { iconKey: "calendar_month", group: "Subscription" },
};

export const ORDER_TRANSITIONS = {
  PENDING: [ORDER_STATUS.CONFIRMED, ORDER_STATUS.CANCELLED],
  SITE_VISIT_PENDING: [ORDER_STATUS.QUOTED, ORDER_STATUS.CANCELLED],
  QUOTED: [ORDER_STATUS.CONFIRMED, ORDER_STATUS.CANCELLED],
  CONFIRMED: [ORDER_STATUS.IN_PROGRESS, ORDER_STATUS.CANCELLED],
  IN_PROGRESS: [ORDER_STATUS.COMPLETED, ORDER_STATUS.CANCELLED],
  COMPLETED: [],
  CANCELLED: [],
};

export const VISIT_TRANSITIONS = {
  PENDING: [VISIT_STATUS.IN_PROGRESS, VISIT_STATUS.CANCELLED],
  IN_PROGRESS: [VISIT_STATUS.COMPLETED, VISIT_STATUS.CANCELLED],
  COMPLETED: [],
  CANCELLED: [],
};

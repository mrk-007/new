import rateLimit from "express-rate-limit";
import { env } from "../config/env.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { RESPONSE_MESSAGES } from "../constants/responseMessages.js";

/**
 * Global API Rate Limiter Middleware.
 */
export const apiRateLimiter = rateLimit({
  windowMs: env.RATE_LIMIT_WINDOW_MS,
  max: env.RATE_LIMIT_MAX_REQUESTS,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: RESPONSE_MESSAGES.RATE_LIMIT_EXCEEDED,
    data: null,
    meta: {
      retryAfterSeconds: Math.ceil(env.RATE_LIMIT_WINDOW_MS / 1000),
    },
  },
  statusCode: HTTP_STATUS.TOO_MANY_REQUESTS,
});

/**
 * Stricter Rate Limiter for Authentication endpoints.
 */
export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // 20 login attempts per IP per 15 minutes
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    message: "Too many authentication attempts. Please try again after 15 minutes.",
    data: null,
    meta: null,
  },
  statusCode: HTTP_STATUS.TOO_MANY_REQUESTS,
});

/**
 * @file validate.middleware.js
 * @description Collects all body-field rule failures into a single 400 error.
 */
import { AppError } from "../utils/appError.js";
import { required } from "../validators/rules.js";

/** Returns middleware that validates req.body against a field-to-rules schema. */
export const validateBody = (schema, { partial = false } = {}) => (req, _res, next) => {
  const errors = [];
  for (const [field, rules] of Object.entries(schema)) {
    const value = req.body?.[field];
    const isRequired = !partial && rules.includes(required);
    if (!isRequired && (value === undefined || value === null || value === "")) continue;
    for (const rule of rules) {
      const message = rule(value, req.body);
      if (message) errors.push({ field, message: `${field} ${message}` });
    }
  }
  if (errors.length) {
    return next(new AppError(400, "Request validation failed.", errors));
  }
  next();
};

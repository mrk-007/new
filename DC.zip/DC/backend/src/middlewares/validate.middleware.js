/**
 * @file validate.middleware.js
 * @description Lightweight manual input validation helper for request payload checking.
 */

/**
 * Validates presence of mandatory fields in request body payload.
 */
export const requireFields = (body, fields = []) => {
  const missing = fields.filter(
    (f) => body[f] === undefined || body[f] === null || body[f] === ""
  );
  if (missing.length > 0) {
    const error = new Error(`Missing required fields: ${missing.join(", ")}`);
    error.statusCode = 400;
    throw error;
  }
};

export default requireFields;

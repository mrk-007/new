/**
 * @file auth.middleware.js
 * @description JWT Bearer authentication that loads the user and role.
 */
import jwt from "jsonwebtoken";
import { env } from "../config/env.js";
import { User } from "../models/User.model.js";
import { AppError } from "../utils/appError.js";
import { asyncHandler } from "../utils/asyncHandler.js";

/** Verifies the access token and attaches an active user with an active role. */
export const authenticate = asyncHandler(async (req, _res, next) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) {
    throw new AppError(401, "Authentication token required.");
  }

  let decoded;
  try {
    decoded = jwt.verify(header.split(" ")[1], env.JWT_SECRET);
  } catch {
    throw new AppError(401, "Invalid or expired token.");
  }

  const user = await User.findById(decoded.id).populate("role");
  if (!user || !user.isActive) {
    throw new AppError(401, "User session is invalid or inactive.");
  }
  if (!user.role || user.role.isActive === false) {
    throw new AppError(401, "User role is inactive.");
  }

  req.user = user;
  next();
});

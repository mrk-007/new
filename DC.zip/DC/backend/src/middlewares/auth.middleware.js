import { verifyAccessToken } from "../utils/tokenHelper.js";
import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { RESPONSE_MESSAGES } from "../constants/responseMessages.js";
import { User, RolePermission, Module } from "../models/index.js";

/**
 * Authentication Middleware: Validates Bearer JWT Token.
 */
export const authenticate = async (req, _res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return next(
        new AppError("Authorization token required (Bearer scheme).", HTTP_STATUS.UNAUTHORIZED)
      );
    }

    const token = authHeader.split(" ")[1];
    const decoded = verifyAccessToken(token);

    const user = await User.findById(decoded.userId)
      .populate("role")
      .populate("technicianProfile");

    if (!user || !user.isActive) {
      return next(
        new AppError("User account no longer active or exists.", HTTP_STATUS.UNAUTHORIZED)
      );
    }

    if (user.isLocked) {
      return next(
        new AppError("User account is temporarily locked due to multiple failed logins.", HTTP_STATUS.FORBIDDEN)
      );
    }

    req.user = user;
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return next(
        new AppError("Access token has expired. Please refresh your session.", HTTP_STATUS.UNAUTHORIZED)
      );
    }
    return next(new AppError("Invalid or corrupted access token.", HTTP_STATUS.UNAUTHORIZED));
  }
};

/**
 * RBAC Authorization Middleware: Enforces module-level Read/Write/Delete permissions.
 *
 * @param {string} moduleKey - Target module key (e.g. "customers", "orders", "configuration")
 * @param {"read"|"write"|"delete"} [action="read"] - Action being performed
 */
export const authorize = (moduleKey, action = "read") => {
  return async (req, _res, next) => {
    try {
      if (!req.user || !req.user.role) {
        return next(new AppError(RESPONSE_MESSAGES.UNAUTHORIZED, HTTP_STATUS.UNAUTHORIZED));
      }

      // Super Admin bypasses all module restrictions
      if (req.user.role.roleKey === "super_admin") {
        return next();
      }

      // Find the module ObjectId
      const targetModule = await Module.findOne({ moduleKey, isActive: true });
      if (!targetModule) {
        return next(
          new AppError(`Module '${moduleKey}' not recognized in system registry.`, HTTP_STATUS.FORBIDDEN)
        );
      }

      // Query role permission from DB
      const permission = await RolePermission.findOne({
        role: req.user.role._id,
        module: targetModule._id,
        isActive: true,
      });

      if (!permission) {
        return next(
          new AppError(`You lack access permissions for '${moduleKey}'.`, HTTP_STATUS.FORBIDDEN)
        );
      }

      const actionMap = {
        read: permission.isRead,
        write: permission.isWrite,
        delete: permission.isDelete,
      };

      const hasPermission = Boolean(actionMap[action]);
      if (!hasPermission) {
        return next(
          new AppError(
            `You do not have '${action}' permission on module '${moduleKey}'.`,
            HTTP_STATUS.FORBIDDEN
          )
        );
      }

      next();
    } catch (error) {
      next(error);
    }
  };
};

import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";

/**
 * Zod request validation middleware.
 * @param {import("zod").ZodSchema} schema
 */
export const validateRequest = (schema) => async (req, _res, next) => {
  try {
    const validated = await schema.parseAsync({
      body: req.body,
      query: req.query,
      params: req.params,
    });

    if (validated.body) req.body = validated.body;
    if (validated.query) req.query = validated.query;
    if (validated.params) req.params = validated.params;

    next();
  } catch (error) {
    if (error.issues) {
      const details = error.issues.map((issue) => ({
        path: issue.path.join("."),
        message: issue.message,
      }));
      return next(new AppError("Validation failed for input data.", HTTP_STATUS.BAD_REQUEST, details));
    }
    return next(error);
  }
};

/**
 * @file role.middleware.js
 * @description Role check middleware restricting routes to specified user roles.
 */

/**
 * Creates middleware ensuring authenticated user possesses the required system role.
 */
export const requireRole = (allowedRole) => {
  return (req, res, next) => {
    if (!req.user || req.user.role !== allowedRole) {
      return res.status(403).json({
        success: false,
        message: "Forbidden: insufficient role privileges.",
      });
    }
    next();
  };
};

export default requireRole;

/**
 * @file errorHandler.middleware.js
 * @description Central error handling and 404 fallback middlewares.
 */

/**
 * Handles requests targeting non-existent endpoints.
 */
export const notFoundHandler = (req, res, _next) => {
  res.status(404).json({
    success: false,
    message: `Resource not found: ${req.method} ${req.originalUrl}`,
  });
};

/**
 * Global application error handler for uncaught exceptions and rejected promises.
 */
export const errorHandler = (err, _req, res, _next) => {
  const statusCode = err.statusCode || 500;
  res.status(statusCode).json({
    success: false,
    message: err.message || "Internal server error occurred.",
  });
};

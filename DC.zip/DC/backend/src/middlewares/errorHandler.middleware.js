/**
 * @file errorHandler.middleware.js
 * @description Central 404 and error mapping including Mongoose errors.
 */
import { AppError } from "../utils/appError.js";

/** Handles unknown routes. */
export const notFoundHandler = (req, res) => {
  res.status(404).json({
    success: false,
    message: `Resource not found: ${req.method} ${req.originalUrl}`,
  });
};

/** Maps a Mongoose duplicate-key error to a 409 AppError. */
const mapDuplicate = (err) => {
  const field = Object.keys(err.keyValue || {})[0];
  return new AppError(409, field ? `${field} already exists.` : "Duplicate key conflict.");
};

/** Maps a Mongoose cast error to a 400 AppError. */
const mapCast = () => new AppError(400, "Invalid identifier.");

/** Maps a Mongoose validation error to a 422 AppError. */
const mapValidation = (err) => {
  const errors = Object.values(err.errors || {}).map((item) => item.message);
  return new AppError(422, "Validation failed.", errors);
};

/** Global error handler returning the standard error envelope. */
export const errorHandler = (err, _req, res, _next) => {
  let error = err;
  if (err.code === 11000) error = mapDuplicate(err);
  else if (err.name === "CastError") error = mapCast();
  else if (err.name === "ValidationError") error = mapValidation(err);

  const statusCode = error.statusCode || 500;
  const payload = {
    success: false,
    message: error.message || "Internal server error occurred.",
  };
  if (error.errors) payload.errors = error.errors;
  res.status(statusCode).json(payload);
};

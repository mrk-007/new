import morgan from "morgan";
import { morganStream } from "../config/logger.js";
import { env } from "../config/env.js";

/**
 * HTTP request logging middleware using Morgan integrated with Winston.
 */
const format = env.isDevelopment
  ? ":method :url :status :response-time ms - :res[content-length]"
  : ':remote-addr - :remote-user [:date[clf]] ":method :url HTTP/:http-version" :status :res[content-length] ":referrer" ":user-agent"';

export const requestLogger = morgan(format, {
  stream: morganStream,
  skip: (req) => {
    // Skip logging health checks in development to avoid clutter
    return req.url === "/api/v1/health";
  },
});

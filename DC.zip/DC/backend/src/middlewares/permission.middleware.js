/**
 * @file permission.middleware.js
 * @description Role flag checks for read, write, and delete actions.
 */
import { AppError } from "../utils/appError.js";
import { PERMISSION } from "../constants/index.js";

const FLAG = {
  [PERMISSION.READ]: "isRead",
  [PERMISSION.WRITE]: "isWrite",
  [PERMISSION.DELETE]: "isDelete",
};

/** Returns middleware that requires the given role action flag. */
export const authorize = (action) => (req, _res, next) => {
  const flag = FLAG[action];
  if (!flag || !req.user?.role?.[flag]) {
    return next(new AppError(403, "You do not have permission to perform this action."));
  }
  next();
};

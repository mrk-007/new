import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { RESPONSE_MESSAGES } from "../constants/responseMessages.js";
import { logger } from "../config/logger.js";
import { env } from "../config/env.js";

/**
 * 404 Not Found Middleware for unhandled routes.
 */
export const notFoundHandler = (req, res, next) => {
  next(
    new AppError(
      `${RESPONSE_MESSAGES.ROUTE_NOT_FOUND} (${req.method} ${req.originalUrl})`,
      HTTP_STATUS.NOT_FOUND
    )
  );
};

/**
 * Global Centralized Error Handling Middleware.
 */
export const globalErrorHandler = (err, req, res, _next) => {
  let error = { ...err };
  error.message = err.message;
  error.name = err.name;
  error.stack = err.stack;
  error.statusCode = err.statusCode || HTTP_STATUS.INTERNAL_SERVER_ERROR;

  // Log Error via Winston
  if (error.statusCode >= 500) {
    logger.error(`[Unhandled Error] ${req.method} ${req.originalUrl} - ${err.message}`, {
      stack: err.stack,
    });
  } else {
    logger.warn(`[Client Error] ${req.method} ${req.originalUrl} - ${error.statusCode}: ${err.message}`);
  }

  // Handle Mongoose Bad ObjectId (CastError)
  if (err.name === "CastError") {
    const message = `Invalid resource identifier: ${err.value}`;
    error = new AppError(message, HTTP_STATUS.BAD_REQUEST);
  }

  // Handle Mongoose Duplicate Key Error (E11000)
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || "field";
    const value = err.keyValue ? err.keyValue[field] : "";
    const message = `Duplicate value '${value}' for ${field}. Please use another value.`;
    error = new AppError(message, HTTP_STATUS.CONFLICT);
  }

  // Handle Mongoose Schema Validation Errors
  if (err.name === "ValidationError") {
    const details = Object.values(err.errors || {}).map((item) => ({
      field: item.path,
      message: item.message,
    }));
    error = new AppError(RESPONSE_MESSAGES.BAD_REQUEST, HTTP_STATUS.BAD_REQUEST, details);
  }

  // Handle JWT Malformed / Signature Errors
  if (err.name === "JsonWebTokenError") {
    error = new AppError("Invalid authentication token. Please log in again.", HTTP_STATUS.UNAUTHORIZED);
  }

  // Handle JWT Expired Error
  if (err.name === "TokenExpiredError") {
    error = new AppError("Authentication token has expired. Please refresh your session.", HTTP_STATUS.UNAUTHORIZED);
  }

  // Handle Zod Validation Errors
  if (err.name === "ZodError" && err.issues) {
    const details = err.issues.map((issue) => ({
      field: issue.path.join("."),
      message: issue.message,
    }));
    error = new AppError("Validation failed for input data.", HTTP_STATUS.BAD_REQUEST, details);
  }

  // Prepare standard response envelope
  const response = {
    success: false,
    message: error.message || RESPONSE_MESSAGES.SERVER_ERROR,
    data: null,
    meta: error.details ? { details: error.details } : null,
  };

  // Include stack trace only in development
  if (env.isDevelopment && error.statusCode >= 500) {
    response.meta = {
      ...response.meta,
      stack: error.stack,
    };
  }

  return res.status(error.statusCode).json(response);
};

import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";

/**
 * Base Service providing common business logic around repository operations.
 */
export class BaseService {
  /**
   * @param {import("../models/base.repository.js").BaseRepository} repository
   * @param {string} resourceName - Name of the managed resource for descriptive errors
   */
  constructor(repository, resourceName = "Resource") {
    this.repository = repository;
    this.resourceName = resourceName;
  }

  /**
   * Get all active records with optional filter.
   */
  async getAll(filter = {}, options = {}) {
    return this.repository.find(filter, options);
  }

  /**
   * Get paginated records.
   */
  async getPaginated(queryParams = {}, searchFields = [], populateOptions = null) {
    return this.repository.findPaginated(queryParams, searchFields, populateOptions);
  }

  /**
   * Get single record by ID or throw 404 AppError.
   */
  async getById(id, populateOptions = null) {
    const item = await this.repository.findById(id, populateOptions);
    if (!item) {
      throw new AppError(`${this.resourceName} not found with ID ${id}`, HTTP_STATUS.NOT_FOUND);
    }
    return item;
  }

  /**
   * Create a new record.
   */
  async create(data) {
    return this.repository.create(data);
  }

  /**
   * Update existing record by ID or throw 404.
   */
  async update(id, updateData) {
    const updated = await this.repository.updateById(id, updateData);
    if (!updated) {
      throw new AppError(`${this.resourceName} not found with ID ${id}`, HTTP_STATUS.NOT_FOUND);
    }
    return updated;
  }

  /**
   * Soft-delete existing record by ID or throw 404.
   */
  async delete(id, userId = null) {
    const deleted = await this.repository.deleteById(id, true, userId);
    if (!deleted) {
      throw new AppError(`${this.resourceName} not found with ID ${id}`, HTTP_STATUS.NOT_FOUND);
    }
    return deleted;
  }
}

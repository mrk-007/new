/**
 * @file order.service.js
 * @description Order create, confirm, cancel, status, and site-visit flow.
 */
import { Order } from "../models/Order.model.js";
import { Product } from "../models/Product.model.js";
import { Customer } from "../models/Customer.model.js";
import { Address } from "../models/Address.model.js";
import { Visit } from "../models/Visit.model.js";
import { AppError } from "../utils/appError.js";
import { AUDIT_ACTION, ORDER_STATUS, ORDER_TRANSITIONS, PRODUCT_CODE, VISIT_TYPE } from "../constants/index.js";
import { addMinutes, formatIstDate, toDateTime } from "../utils/time.js";
import { parsePagination, buildMeta } from "../utils/pagination.js";
import { actorMeta, getById } from "./crud.service.js";
import { log } from "./audit.service.js";
import { resolveOrderPrice } from "./pricing.service.js";
import { applyTax } from "./tax.service.js";
import { resolveDurationMinutes } from "./duration.service.js";
import { createVisit, cancelOpenVisitsFor } from "./visit.service.js";
import { TechnicianAllocation } from "../models/TechnicianAllocation.model.js";

/** Builds an ORD-YYYYMMDD-XXXX number for the IST day. */
const nextOrderNumber = async (when) => {
  const day = formatIstDate(when).replace(/-/g, "");
  const prefix = `ORD-${day}-`;
  const count = await Order.countDocuments({ orderNumber: { $regex: `^${prefix}` } });
  return `${prefix}${String(count + 1).padStart(4, "0")}`;
};

/** Appends a status history row and audits the change. */
export const applyOrderStatus = async (order, status, req, note) => {
  if (!ORDER_TRANSITIONS[order.status]?.includes(status)) {
    throw new AppError(409, `Invalid order transition from ${order.status} to ${status}.`);
  }
  const { actorId, ip, userAgent } = actorMeta(req);
  const before = { status: order.status };
  order.status = status;
  if (status === ORDER_STATUS.COMPLETED) order.deliveredAt = new Date();
  order.statusHistory.push({ status, changedAt: new Date(), changedBy: actorId, note });
  order.updatedBy = actorId;
  await order.save();
  await log({
    entity: "Order",
    entityId: order._id,
    action: AUDIT_ACTION.UPDATE,
    before,
    after: { status },
    performedBy: actorId,
    ip,
    userAgent,
  });
  return order;
};

/** Creates a SERVICE or SITE_VISIT for an order and records unallocated visits. */
const scheduleOrderVisit = async ({ order, product, address, date, startTime, visitType, sequenceNo }, req) => {
  const durationMinutes = await resolveDurationMinutes({ visitType, product });
  const scheduledStart = toDateTime(date, startTime);
  const scheduledEnd = addMinutes(scheduledStart, durationMinutes);
  const { visit, allocated } = await createVisit(
    {
      order: order._id,
      customer: order.customer,
      address: address._id,
      visitType,
      sequenceNo,
      scheduledStart,
      scheduledEnd,
      durationMinutes,
      status: "PENDING",
    },
    req
  );
  return allocated ? [] : [visit];
};

/** Creates an order, snapshots price, and schedules the first visit. */
export const createOrder = async (body, req) => {
  const { actorId, ip, userAgent } = actorMeta(req);
  const customer = await Customer.findById(body.customer);
  if (!customer) throw new AppError(404, "Customer not found.");
  const address = await Address.findById(body.address);
  if (!address || String(address.customer) !== String(customer._id)) {
    throw new AppError(422, "Address does not belong to this customer.");
  }
  const product = await Product.findById(body.product);
  if (!product || !product.isActive) throw new AppError(404, "Product not found.");
  const quantity = body.quantity || 1;

  let snapshot = {
    unitPrice: 0,
    cgstRate: 0,
    sgstRate: 0,
    cgstAmount: 0,
    sgstAmount: 0,
    totalAmount: 0,
  };
  if (product.code !== PRODUCT_CODE.MOSQUITO_NET) {
    const { row } = await resolveOrderPrice(product._id);
    snapshot = await applyTax(row.price * quantity, address);
  }

  const status = product.requiresSiteVisit ? ORDER_STATUS.SITE_VISIT_PENDING : ORDER_STATUS.CONFIRMED;
  const now = new Date();
  const statusHistory = product.requiresSiteVisit
    ? [{ status, changedAt: now, changedBy: actorId, note: "Order created" }]
    : [
        { status: ORDER_STATUS.PENDING, changedAt: now, changedBy: actorId, note: "Order created" },
        { status: ORDER_STATUS.CONFIRMED, changedAt: now, changedBy: actorId, note: "Confirmed on creation" },
      ];

  let order;
  try {
    order = await Order.create({
      orderNumber: await nextOrderNumber(new Date()),
      customer: customer._id,
      address: address._id,
      product: product._id,
      quantity,
      ...snapshot,
      status,
      statusHistory,
      createdBy: actorId,
      updatedBy: actorId,
    });

    await log({
      entity: "Order",
      entityId: order._id,
      action: AUDIT_ACTION.CREATE,
      before: null,
      after: order.toObject(),
      performedBy: actorId,
      ip,
      userAgent,
    });

    const visitType = product.requiresSiteVisit ? VISIT_TYPE.SITE_VISIT : VISIT_TYPE.SERVICE;
    const unallocatedVisits = await scheduleOrderVisit(
      { order, product, address, date: body.date, startTime: body.startTime, visitType, sequenceNo: visitType === VISIT_TYPE.SITE_VISIT ? 0 : 1 },
      req
    );

    return { order, unallocatedVisits };
  } catch (err) {
    await rollbackOrder(order?._id);
    throw err;
  }
};

/** Deletes an order and visits created in a failed request. */
const rollbackOrder = async (orderId) => {
  if (!orderId) return;
  const visits = await Visit.find({ order: orderId }).select("_id");
  const visitIds = visits.map((v) => v._id);
  await TechnicianAllocation.deleteMany({ visit: { $in: visitIds } });
  await Visit.deleteMany({ order: orderId });
  await Order.deleteOne({ _id: orderId });
};

/** Confirms a quoted (or pending) order and creates the SERVICE visit. */
export const confirmOrder = async (id, req) => {
  const order = await getById(Order, id);
  const product = await Product.findById(order.product);
  const address = await Address.findById(order.address);
  if (order.status === ORDER_STATUS.QUOTED) {
    await applyOrderStatus(order, ORDER_STATUS.CONFIRMED, req, "Quote confirmed");
  } else if (order.status === ORDER_STATUS.PENDING) {
    await applyOrderStatus(order, ORDER_STATUS.CONFIRMED, req, "Order confirmed");
  } else {
    throw new AppError(409, `Order cannot be confirmed from ${order.status}.`);
  }

  const existingService = await Visit.findOne({ order: order._id, visitType: VISIT_TYPE.SERVICE });
  if (existingService) return { order, unallocatedVisits: [] };

  const date = req.body?.date;
  const startTime = req.body?.startTime;
  if (!date || !startTime) {
    throw new AppError(400, "date and startTime are required to schedule the service visit.");
  }
  const unallocatedVisits = await scheduleOrderVisit(
    {
      order,
      product,
      address,
      date,
      startTime,
      visitType: VISIT_TYPE.SERVICE,
      sequenceNo: 1,
    },
    req
  );
  return { order, unallocatedVisits };
};

/** Cancels an order, its pending visits, and allocations. */
export const cancelOrder = async (id, req) => {
  const order = await getById(Order, id);
  await applyOrderStatus(order, ORDER_STATUS.CANCELLED, req, req.body?.cancelReason);
  order.cancelReason = req.body?.cancelReason;
  await order.save();
  await cancelOpenVisitsFor({ orderId: order._id }, req, req.body?.cancelReason || "Order cancelled");
  return order;
};

/** Lists orders with pagination and optional search on orderNumber. */
export const listOrders = async (req) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  if (req.query.search) filter.orderNumber = { $regex: req.query.search, $options: "i" };
  const [items, total] = await Promise.all([
    Order.find(filter).populate("customer address product").sort({ createdAt: -1 }).skip(skip).limit(limit),
    Order.countDocuments(filter),
  ]);
  return { items, meta: buildMeta(total, page, limit) };
};

/** Returns an order with statusHistory and visits. */
export const getOrder = async (id) => {
  const order = await getById(Order, id, "customer address product");
  const visits = await Visit.find({ order: order._id }).sort({ sequenceNo: 1 });
  return { order, visits };
};

/** Applies a manual status patch when the transition is valid. */
export const patchStatus = async (id, req) => {
  const order = await getById(Order, id);
  return applyOrderStatus(order, req.body.status, req, req.body.note);
};

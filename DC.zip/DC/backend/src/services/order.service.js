import {
  Order,
  OrderItem,
  Subscription,
  SubscriptionVisit,
  JobOrder,
  Invoice,
  InvoiceItem,
  Payment,
  Customer,
  CustomerAddress,
  Counter,
  Product,
} from "../models/index.js";
import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import {
  endFrom,
  checkAssignmentConflict,
  calculateFinancials,
} from "../utils/businessRules.js";
import { parseQueryParams, calculatePagination } from "../utils/queryHelper.js";
import { recordAuditLog } from "../utils/auditLogger.js";

export class OrderService {
  /**
   * Confirm and create an order with server-authoritative calculations,
   * conflict detection, invoice, initial job order, and subscription schedule.
   */
  static async createOrder(data, userId) {
    // 1. Validate Customer & Property Existence
    const [customer, property] = await Promise.all([
      Customer.findOne({ _id: data.customerId, isActive: true }),
      CustomerAddress.findOne({ _id: data.propertyId, customer: data.customerId, isActive: true }),
    ]);

    if (!customer) {
      throw new AppError("Customer not found or inactive.", HTTP_STATUS.NOT_FOUND);
    }
    if (!property) {
      throw new AppError("Selected property not associated with this customer.", HTTP_STATUS.BAD_REQUEST);
    }

    // 2. Server-side Duration & End Time Auto-Calculation
    let durationMinutes = 120;
    if (data.orderMode === "Bathroom Cleaning") {
      const parsed = parseInt(data.config, 10);
      durationMinutes = !isNaN(parsed) && parsed > 0 ? parsed : 90;
    } else if (data.orderMode === "Deep Cleaning") {
      const parsed = parseInt(data.config, 10);
      durationMinutes = !isNaN(parsed) && parsed > 0 ? parsed : 240;
    } else {
      durationMinutes = 120;
    }

    const endTime = endFrom(data.startTime, durationMinutes);

    // 3. Server-side Conflict Checking (Property & Technician Overlap)
    const conflictResult = await checkAssignmentConflict({
      date: data.serviceDate,
      startTime: data.startTime,
      endTime,
      propertyId: property._id,
      technicianId: data.technicianId,
    });

    if (conflictResult.hasConflict) {
      throw new AppError(conflictResult.reason, HTTP_STATUS.CONFLICT);
    }

    // 4. Server-side Pricing Calculation
    let basePrice = 7500;
    if (data.orderMode === "Bathroom Cleaning") {
      basePrice = 5500;
    } else if (data.orderMode === "Deep Cleaning") {
      basePrice = 13974.58;
    } else if (data.productId) {
      const prod = await Product.findById(data.productId);
      if (prod && prod.basePrice) basePrice = prod.basePrice;
    }

    const financials = calculateFinancials({
      basePrice,
      discount: data.discount || 0,
      cgstRate: 9,
      sgstRate: 9,
    });

    // 5. Generate Atomic Sequential Identifiers
    const orderId = await Counter.getNextSequence("ORDER", "ORD-2026", 4);
    const invoiceId = await Counter.getNextSequence("INVOICE", "INV", 6);
    const jobId = await Counter.getNextSequence("JOB_ORDER", "JOB", 4);

    // 6. Create Invoice
    const invoice = await Invoice.create({
      invoiceId,
      order: null, // Linked immediately below
      orderNumber: orderId,
      customer: customer._id,
      category: data.orderMode,
      subTotal: financials.charges,
      cgst: financials.cgstAmount,
      sgst: financials.sgstAmount,
      totalAmount: financials.total,
      statusLabel: "Paid",
      paymentMode: data.paymentMode || "UPI",
      transactionRef: data.transactionRef || `TXN/${orderId}`,
      paidAt: new Date(),
      createdBy: userId,
    });

    await InvoiceItem.create({
      invoice: invoice._id,
      description: `${data.serviceName} · ${data.config || "Standard"}`,
      quantity: 1,
      unitPrice: financials.charges,
      amount: financials.total,
      createdBy: userId,
    });

    // 7. Create Order
    const orderStatus =
      data.orderMode === "Product Installation" ? "Installation Scheduled" : "Active";

    const order = await Order.create({
      orderId,
      customer: customer._id,
      property: property._id,
      orderType: data.orderMode,
      serviceName: `${data.serviceName} · ${data.config || ""} · ${data.plan || ""}`.replace(
        /\s+·\s+·/g,
        " ·"
      ),
      configuration: data.config || "",
      plan: data.plan || "",
      serviceDate: data.serviceDate,
      startTime: data.startTime,
      endTime,
      durationMinutes,
      assignedTech: data.technicianId,
      travelBufferMinutes: data.travelBufferMinutes || 30,
      charges: financials.charges,
      discount: financials.discount,
      cgst: financials.cgstAmount,
      sgst: financials.sgstAmount,
      totalAmount: financials.total,
      paymentModeName: data.paymentMode || "UPI",
      transactionRef: data.transactionRef || "",
      invoice: invoice._id,
      invoiceNumber: invoiceId,
      status: orderStatus,
      createdBy: userId,
    });

    // Link Invoice to Order
    invoice.order = order._id;
    await invoice.save();

    // 8. Create Order Item
    await OrderItem.create({
      order: order._id,
      itemTitle: order.serviceName,
      quantity: 1,
      unitPrice: financials.charges,
      cgstAmount: financials.cgstAmount,
      sgstAmount: financials.sgstAmount,
      totalAmount: financials.total,
      createdBy: userId,
    });

    // 9. Create First Executable Job Order
    const jobTitle =
      data.orderMode === "Product Installation"
        ? data.serviceName
        : `${data.orderMode} · ${data.config || "Visit 1"}`;

    const job = await JobOrder.create({
      jobId,
      order: order._id,
      customer: customer._id,
      property: property._id,
      title: jobTitle,
      typeName: data.orderMode === "Product Installation" ? "Installation" : data.orderMode,
      plannedDate: data.serviceDate,
      startTime: data.startTime,
      endTime,
      durationMinutes,
      technician: data.technicianId,
      statusLabel: "Assigned",
      createdBy: userId,
    });

    // 10. If Subscription, Create Subscription and Generate Full Visit Schedule
    let subscription = null;
    if (data.orderMode !== "Product Installation") {
      const subscriptionId = await Counter.getNextSequence("SUBSCRIPTION", "SUB", 6);
      const isBiWeekly = (data.plan || "").includes("2 Weeks");
      const frequency = isBiWeekly ? "Once in 2 Weeks" : "Once Every Week";
      const totalVisits = (data.plan || "").includes("8")
        ? 8
        : (data.plan || "").includes("6")
          ? 6
          : 4;

      subscription = await Subscription.create({
        subscriptionId,
        order: order._id,
        customer: customer._id,
        property: property._id,
        typeName: data.orderMode,
        configuration: `${data.config || ""} · ${durationMinutes} mins`,
        frequency,
        slot: `${data.startTime}-${endTime}`,
        totalVisits,
        completedVisits: 0,
        nextVisitDate: data.serviceDate,
        invoice: invoice._id,
        invoiceNumber: invoiceId,
        status: "Active",
        createdBy: userId,
      });

      // Link First Job to Subscription
      job.subscription = subscription._id;
      await job.save();

      // Generate all planned visit records across recurrence intervals
      const visitIntervalDays = isBiWeekly ? 14 : 7;
      const visitDate = new Date(data.serviceDate);

      for (let i = 1; i <= totalVisits; i++) {
        const dateStr = visitDate.toISOString().slice(0, 10);
        await SubscriptionVisit.create({
          subscription: subscription._id,
          visitNumber: i,
          plannedDate: dateStr,
          startTime: data.startTime,
          endTime,
          jobOrder: i === 1 ? job._id : null,
          status: i === 1 ? "Assigned" : "Scheduled",
          createdBy: userId,
        });

        // Advance date by recurrence interval
        visitDate.setDate(visitDate.getDate() + visitIntervalDays);
      }
    }

    // 11. Create Payment Record
    const paymentId = await Counter.getNextSequence("PAYMENT", "PAY", 6);
    await Payment.create({
      paymentId,
      invoice: invoice._id,
      customer: customer._id,
      amount: financials.total,
      methodName: data.paymentMode || "UPI",
      transactionRef: data.transactionRef || `TXN/${orderId}`,
      statusLabel: "Paid",
      paidAt: new Date(),
      createdBy: userId,
    });

    await recordAuditLog({
      action: "CONFIRM_ORDER",
      module: "orders",
      recordId: order._id,
      performedBy: userId,
      newState: { orderId, amount: financials.total, customer: customer.name },
    });

    return {
      order,
      invoice,
      job,
      subscription,
    };
  }

  /**
   * Get paginated orders matching filters.
   */
  static async getOrders(queryParams) {
    const searchFields = ["orderId", "serviceName"];
    const { filter, sort, skip, limit, page } = parseQueryParams(queryParams, searchFields);

    // Filter by type
    if (queryParams.type && queryParams.type !== "All Types" && queryParams.type !== "all") {
      filter.orderType = queryParams.type;
    }

    // Filter by status
    if (queryParams.status && queryParams.status !== "All Statuses" && queryParams.status !== "all") {
      filter.status = queryParams.status;
    }

    const [orders, total] = await Promise.all([
      Order.find(filter)
        .populate("customer", "name mobile customerId")
        .populate("property", "propertyName areaName door")
        .populate("assignedTech", "name roleTitle")
        .populate("invoice")
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .lean(),
      Order.countDocuments(filter),
    ]);

    const pagination = calculatePagination(total, page, limit);
    return { orders, pagination };
  }

  /**
   * Get single order by ID with items and jobs.
   */
  static async getOrderById(id) {
    const order = await Order.findOne({ _id: id, isActive: true })
      .populate("customer")
      .populate("property")
      .populate("assignedTech")
      .populate("invoice")
      .populate("items")
      .populate("jobs");

    if (!order) {
      throw new AppError("Order not found.", HTTP_STATUS.NOT_FOUND);
    }
    return order;
  }

  /**
   * Get subscriptions list with customer and property.
   */
  static async getSubscriptions(queryParams) {
    const searchFields = ["subscriptionId", "typeName", "configuration"];
    const { filter, sort, skip, limit, page } = parseQueryParams(queryParams, searchFields);

    if (queryParams.status && queryParams.status !== "all") {
      filter.status = queryParams.status;
    }

    const [subscriptions, total] = await Promise.all([
      Subscription.find(filter)
        .populate("customer", "name mobile customerId")
        .populate("property", "propertyName areaName door")
        .populate("order", "orderId totalAmount")
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .lean(),
      Subscription.countDocuments(filter),
    ]);

    const formatted = subscriptions.map((s) => ({
      ...s,
      visitsDisplay: `${s.completedVisits} / ${s.totalVisits}`,
    }));

    const pagination = calculatePagination(total, page, limit);
    return { subscriptions: formatted, pagination };
  }

  /**
   * Get subscription details with all planned visits.
   */
  static async getSubscriptionById(id) {
    const sub = await Subscription.findOne({ _id: id, isActive: true })
      .populate("customer")
      .populate("property")
      .populate("order");

    if (!sub) {
      throw new AppError("Subscription not found.", HTTP_STATUS.NOT_FOUND);
    }

    const visits = await SubscriptionVisit.find({ subscription: id, isActive: true })
      .populate("jobOrder")
      .sort({ visitNumber: 1 })
      .lean();

    return {
      ...sub.toObject(),
      visits,
    };
  }

  /**
   * Update subscription status.
   */
  static async updateSubscriptionStatus(id, status, userId) {
    const sub = await Subscription.findOne({ _id: id, isActive: true });
    if (!sub) {
      throw new AppError("Subscription not found.", HTTP_STATUS.NOT_FOUND);
    }

    sub.status = status;
    sub.updatedBy = userId;
    await sub.save();

    await recordAuditLog({
      action: "UPDATE_SUBSCRIPTION_STATUS",
      module: "subscriptions",
      recordId: id,
      performedBy: userId,
      newState: { status },
    });

    return sub;
  }
}

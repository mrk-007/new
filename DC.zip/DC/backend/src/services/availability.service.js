/**
 * @file availability.service.js
 * @description Technician free-time checks against assigned visit windows.
 */
import { Technician } from "../models/Technician.model.js";
import { TechnicianSkill } from "../models/TechnicianSkill.model.js";
import { TechnicianAllocation } from "../models/TechnicianAllocation.model.js";
import { Visit } from "../models/Visit.model.js";
import { ALLOCATION_STATUS, VISIT_STATUS } from "../constants/index.js";
import { addMinutes, overlaps } from "../utils/time.js";

/** Returns true when the technician is active, on duty, and has no overlapping ASSIGNED visit. */
export const isTechnicianFree = async (technicianId, start, end, bufferMinutes = 0) => {
  const technician = await Technician.findById(technicianId);
  if (!technician || !technician.isActive || !technician.isAvailable) return false;

  const allocations = await TechnicianAllocation.find({
    technician: technicianId,
    status: ALLOCATION_STATUS.ASSIGNED,
  }).lean();
  if (!allocations.length) return true;

  const visits = await Visit.find({
    _id: { $in: allocations.map((row) => row.visit) },
    status: { $ne: VISIT_STATUS.CANCELLED },
  }).lean();

  return !visits.some((visit) =>
    overlaps(
      addMinutes(visit.scheduledStart, -bufferMinutes),
      addMinutes(visit.scheduledEnd, bufferMinutes),
      start,
      end
    )
  );
};

/** Returns skilled, available technicians for a window. */
export const findAvailableTechnicians = async ({ skillId, start, end, bufferMinutes = 0 }) => {
  const skilled = await TechnicianSkill.find({ skill: skillId, isSkilled: true }).lean();
  const technicianIds = skilled.map((row) => row.technician);
  const technicians = await Technician.find({
    _id: { $in: technicianIds },
    isActive: true,
    isAvailable: true,
  });
  const free = [];
  for (const technician of technicians) {
    if (await isTechnicianFree(technician._id, start, end, bufferMinutes)) {
      free.push(technician);
    }
  }
  return free;
};

import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { parseQueryParams, calculatePagination } from "../utils/queryHelper.js";
import { recordAuditLog } from "../utils/auditLogger.js";

/**
 * Generic Service Factory for Master Data collections.
 *
 * @param {import("mongoose").Model} Model - Target Mongoose model
 * @param {object} options
 * @param {string} options.resourceName - Human readable name for errors (e.g. "Area")
 * @param {Array<string>} [options.searchFields=[]] - Fields for text search
 * @param {object|string} [options.defaultSort={ createdAt: -1 }] - Default sort rule
 * @param {object|Array} [options.populateOptions=null] - Population definition
 */
export const createMasterService = (Model, options = {}) => {
  const {
    resourceName = "Master Data",
    searchFields = ["name", "label", "code", "title"],
    defaultSort = { createdAt: -1 },
    populateOptions = null,
  } = options;

  return {
    /**
     * Get all active records.
     */
    async getAll(filter = {}) {
      const query = Model.find({ isActive: true, ...filter }).sort(defaultSort);
      if (populateOptions) query.populate(populateOptions);
      return query.lean().exec();
    },

    /**
     * Get paginated records with text search and field filters.
     */
    async getPaginated(queryParams = {}) {
      const { filter, sort, skip, limit, page } = parseQueryParams(queryParams, searchFields);

      const query = Model.find(filter)
        .sort(Object.keys(sort).length ? sort : defaultSort)
        .skip(skip)
        .limit(limit);

      if (populateOptions) query.populate(populateOptions);

      const [items, total] = await Promise.all([
        query.lean().exec(),
        Model.countDocuments(filter).exec(),
      ]);

      const pagination = calculatePagination(total, page, limit);
      return { items, pagination };
    },

    /**
     * Get single record by ID.
     */
    async getById(id) {
      const query = Model.findOne({ _id: id, isActive: true });
      if (populateOptions) query.populate(populateOptions);
      const item = await query.exec();
      if (!item) {
        throw new AppError(`${resourceName} not found with ID ${id}`, HTTP_STATUS.NOT_FOUND);
      }
      return item;
    },

    /**
     * Create a new record.
     */
    async create(data, userId) {
      const item = await Model.create({
        ...data,
        createdBy: userId,
      });

      await recordAuditLog({
        action: `CREATE_${resourceName.toUpperCase().replace(/\s+/g, "_")}`,
        module: "masters",
        recordId: item._id,
        performedBy: userId,
        newState: item,
      });

      if (populateOptions) {
        return Model.findById(item._id).populate(populateOptions);
      }
      return item;
    },

    /**
     * Update an existing record.
     */
    async update(id, data, userId) {
      const existing = await Model.findOne({ _id: id, isActive: true });
      if (!existing) {
        throw new AppError(`${resourceName} not found with ID ${id}`, HTTP_STATUS.NOT_FOUND);
      }

      const previousState = { ...existing.toObject() };
      Object.assign(existing, data, { updatedBy: userId });
      await existing.save();

      await recordAuditLog({
        action: `UPDATE_${resourceName.toUpperCase().replace(/\s+/g, "_")}`,
        module: "masters",
        recordId: existing._id,
        performedBy: userId,
        previousState,
        newState: existing,
      });

      if (populateOptions) {
        return Model.findById(existing._id).populate(populateOptions);
      }
      return existing;
    },

    /**
     * Toggle active state (soft delete or restore).
     */
    async toggleStatus(id, userId) {
      const item = await Model.findById(id);
      if (!item) {
        throw new AppError(`${resourceName} not found with ID ${id}`, HTTP_STATUS.NOT_FOUND);
      }

      item.isActive = !item.isActive;
      item.updatedBy = userId;
      await item.save();

      await recordAuditLog({
        action: `STATUS_${resourceName.toUpperCase().replace(/\s+/g, "_")}`,
        module: "masters",
        recordId: item._id,
        performedBy: userId,
        newState: { isActive: item.isActive },
      });

      return item;
    },

    /**
     * Soft delete by ID.
     */
    async delete(id, userId) {
      const item = await Model.findOne({ _id: id, isActive: true });
      if (!item) {
        throw new AppError(`${resourceName} not found with ID ${id}`, HTTP_STATUS.NOT_FOUND);
      }

      item.isActive = false;
      item.updatedBy = userId;
      await item.save();

      await recordAuditLog({
        action: `DELETE_${resourceName.toUpperCase().replace(/\s+/g, "_")}`,
        module: "masters",
        recordId: item._id,
        performedBy: userId,
      });

      return true;
    },
  };
};

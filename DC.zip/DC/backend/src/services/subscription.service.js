/**
 * @file subscription.service.js
 * @description Subscription create, visit generation, and cancel.
 */
import { Subscription } from "../models/Subscription.model.js";
import { SubscriptionPlan } from "../models/SubscriptionPlan.model.js";
import { SubscriptionTerm } from "../models/SubscriptionTerm.model.js";
import { ServiceFrequency } from "../models/ServiceFrequency.model.js";
import { Customer } from "../models/Customer.model.js";
import { Address } from "../models/Address.model.js";
import { Visit } from "../models/Visit.model.js";
import { AppError } from "../utils/appError.js";
import { AUDIT_ACTION, PRICING_BASIS, VISIT_STATUS, VISIT_TYPE } from "../constants/index.js";
import { addDays, addMinutes, addMonths, formatIstDate, toDateTime } from "../utils/time.js";
import { parsePagination, buildMeta } from "../utils/pagination.js";
import { actorMeta, getById } from "./crud.service.js";
import { log } from "./audit.service.js";
import { resolveSubscriptionPrice } from "./pricing.service.js";
import { applyTax } from "./tax.service.js";
import { resolveDurationMinutes } from "./duration.service.js";
import { createVisit, cancelOpenVisitsFor } from "./visit.service.js";

/** Builds a SUB-YYYYMMDD-XXXX number. */
const nextSubscriptionNumber = async (when) => {
  const day = formatIstDate(when).replace(/-/g, "");
  const prefix = `SUB-${day}-`;
  const count = await Subscription.countDocuments({ subscriptionNumber: { $regex: `^${prefix}` } });
  return `${prefix}${String(count + 1).padStart(4, "0")}`;
};

/** Deletes documents created in a failed request. */
const rollback = async (subscriptionId) => {
  if (!subscriptionId) return;
  const visits = await Visit.find({ subscription: subscriptionId }).select("_id");
  const visitIds = visits.map((v) => v._id);
  const { TechnicianAllocation } = await import("../models/TechnicianAllocation.model.js");
  await TechnicianAllocation.deleteMany({ visit: { $in: visitIds } });
  await Visit.deleteMany({ subscription: subscriptionId });
  await Subscription.deleteOne({ _id: subscriptionId });
};

/** Creates SERVICE visits from startDate until endDate using frequency. */
export const generateServiceVisits = async (subscriptionId, req) => {
  const subscription = await Subscription.findById(subscriptionId);
  if (!subscription) throw new AppError(404, "Subscription not found.");
  const plan = await SubscriptionPlan.findById(subscription.subscriptionPlan);
  const frequency = await ServiceFrequency.findById(subscription.serviceFrequency);
  const durationMinutes = await resolveDurationMinutes({
    visitType: VISIT_TYPE.SERVICE,
    subscriptionPlan: plan,
    bathroomCountId: subscription.bathroomCount,
    propertySizeId: subscription.propertySize,
  });

  const unallocated = [];
  const created = [];
  let sequenceNo = 1;
  let cursor = subscription.startDate;
  while (cursor < subscription.endDate) {
    const dateStr = formatIstDate(cursor);
    const scheduledStart = toDateTime(dateStr, subscription.preferredStartTime);
    const scheduledEnd = addMinutes(scheduledStart, durationMinutes);
    const { visit, allocated } = await createVisit(
      {
        subscription: subscription._id,
        customer: subscription.customer,
        address: subscription.address,
        visitType: VISIT_TYPE.SERVICE,
        sequenceNo,
        scheduledStart,
        scheduledEnd,
        durationMinutes,
        status: VISIT_STATUS.PENDING,
      },
      req
    );
    created.push(visit);
    if (!allocated) unallocated.push(visit);
    sequenceNo += 1;
    cursor = addDays(cursor, frequency.intervalDays);
  }
  return { created, unallocatedVisits: unallocated };
};

/** Creates a subscription, snapshots price, and schedules visits (or a site visit). */
export const createSubscription = async (body, req) => {
  const { actorId, ip, userAgent } = actorMeta(req);
  const customer = await Customer.findById(body.customer);
  if (!customer) throw new AppError(404, "Customer not found.");
  const address = await Address.findById(body.address);
  if (!address || String(address.customer) !== String(customer._id)) {
    throw new AppError(422, "Address does not belong to this customer.");
  }
  const plan = await SubscriptionPlan.findById(body.subscriptionPlan);
  if (!plan) throw new AppError(404, "Subscription plan not found.");
  const term = await SubscriptionTerm.findById(body.subscriptionTerm);
  if (!term) throw new AppError(404, "Subscription term not found.");
  const frequency = await ServiceFrequency.findById(body.serviceFrequency);
  if (!frequency) throw new AppError(404, "Service frequency not found.");

  if (plan.pricingBasis === PRICING_BASIS.BATHROOM_COUNT && !body.bathroomCount) {
    throw new AppError(422, "bathroomCount is required for this plan.");
  }
  if (plan.pricingBasis === PRICING_BASIS.PROPERTY_SIZE && !body.propertySize) {
    throw new AppError(422, "propertySize is required for this plan.");
  }

  const { row } = await resolveSubscriptionPrice({
    subscriptionPlanId: plan._id,
    serviceFrequencyId: frequency._id,
    subscriptionTermId: term._id,
    bathroomCountId: body.bathroomCount,
    propertySizeId: body.propertySize,
  });
  const snapshot = await applyTax(row.price, address);
  const startDate = toDateTime(body.startDate, "00:00");
  const endDate = addMonths(startDate, term.months);

  let subscription;
  try {
    subscription = await Subscription.create({
      subscriptionNumber: await nextSubscriptionNumber(new Date()),
      customer: customer._id,
      address: address._id,
      subscriptionPlan: plan._id,
      subscriptionTerm: term._id,
      serviceFrequency: frequency._id,
      bathroomCount: body.bathroomCount || null,
      propertySize: body.propertySize || null,
      startDate,
      endDate,
      preferredStartTime: body.preferredStartTime,
      ...snapshot,
      status: VISIT_STATUS.PENDING,
      createdBy: actorId,
      updatedBy: actorId,
    });

    await log({
      entity: "Subscription",
      entityId: subscription._id,
      action: AUDIT_ACTION.CREATE,
      before: null,
      after: subscription.toObject(),
      performedBy: actorId,
      ip,
      userAgent,
    });

    if (plan.requiresSiteVisit) {
      const durationMinutes = await resolveDurationMinutes({
        visitType: VISIT_TYPE.SITE_VISIT,
        subscriptionPlan: plan,
      });
      const scheduledStart = toDateTime(body.startDate, body.preferredStartTime);
      const { visit, allocated } = await createVisit(
        {
          subscription: subscription._id,
          customer: customer._id,
          address: address._id,
          visitType: VISIT_TYPE.SITE_VISIT,
          sequenceNo: 0,
          scheduledStart,
          scheduledEnd: addMinutes(scheduledStart, durationMinutes),
          durationMinutes,
          status: VISIT_STATUS.PENDING,
        },
        req
      );
      return { subscription, unallocatedVisits: allocated ? [] : [visit] };
    }

    const generated = await generateServiceVisits(subscription._id, req);
    return { subscription, unallocatedVisits: generated.unallocatedVisits };
  } catch (err) {
    await rollback(subscription?._id);
    throw err;
  }
};

/** Cancels a subscription, pending visits, and allocations. */
export const cancelSubscription = async (id, req) => {
  const subscription = await getById(Subscription, id);
  if (subscription.status === VISIT_STATUS.CANCELLED) {
    throw new AppError(409, "Subscription is already cancelled.");
  }
  const { actorId, ip, userAgent } = actorMeta(req);
  const before = { status: subscription.status };
  subscription.status = VISIT_STATUS.CANCELLED;
  subscription.updatedBy = actorId;
  await subscription.save();
  await log({
    entity: "Subscription",
    entityId: subscription._id,
    action: AUDIT_ACTION.UPDATE,
    before,
    after: { status: VISIT_STATUS.CANCELLED },
    performedBy: actorId,
    ip,
    userAgent,
  });

  await cancelOpenVisitsFor(
    { subscriptionId: subscription._id },
    req,
    req.body?.cancelReason || "Subscription cancelled"
  );
  return subscription;
};

/** Lists subscriptions. */
export const listSubscriptions = async (req) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  if (req.query.search) filter.subscriptionNumber = { $regex: req.query.search, $options: "i" };
  const [items, total] = await Promise.all([
    Subscription.find(filter)
      .populate("customer address subscriptionPlan subscriptionTerm serviceFrequency bathroomCount propertySize")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
    Subscription.countDocuments(filter),
  ]);
  return { items, meta: buildMeta(total, page, limit) };
};

/** Returns a subscription with its visits. */
export const getSubscription = async (id) => {
  const subscription = await getById(
    Subscription,
    id,
    "customer address subscriptionPlan subscriptionTerm serviceFrequency bathroomCount propertySize"
  );
  const visits = await Visit.find({ subscription: subscription._id }).sort({ sequenceNo: 1 });
  return { subscription, visits };
};

import { Product, ProductVariant, Pricing, BathroomCount, PropertySize } from "../models/index.js";
import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { calculateFinancials, endFrom, calculateDurationText } from "../utils/businessRules.js";

export class CatalogService {
  /**
   * Get all products & subscription services for catalog display.
   */
  static async getCatalog(queryParams = {}) {
    const filter = { isActive: true };

    if (queryParams.group && queryParams.group !== "all") {
      filter.group = queryParams.group;
    }

    if (queryParams.search) {
      filter.name = { $regex: queryParams.search.trim(), $options: "i" };
    }

    const products = await Product.find(filter)
      .populate("serviceType")
      .populate("cgstRate")
      .populate("sgstRate")
      .sort({ displayOrder: 1, name: 1 })
      .lean();

    return products;
  }

  /**
   * Get single product with variants and pricing.
   */
  static async getProductById(id) {
    const product = await Product.findOne({ _id: id, isActive: true })
      .populate("serviceType")
      .populate("cgstRate")
      .populate("sgstRate");

    if (!product) {
      throw new AppError("Product not found.", HTTP_STATUS.NOT_FOUND);
    }

    const variants = await ProductVariant.find({ product: id, isActive: true })
      .populate("measurement")
      .lean();

    return {
      ...product.toObject(),
      variants,
    };
  }

  /**
   * Quote Calculator: Server is the sole authority for price, taxes, duration and end time.
   */
  static async calculateQuote({
    productId,
    variantId = null,
    orderMode,
    configValue = "",
    startTime = "09:00",
    discount = 0,
  }) {
    let basePrice = 0;
    let durationMinutes = 120;

    // Resolve Product & Pricing
    if (productId) {
      const product = await Product.findById(productId);
      if (product) {
        basePrice = product.basePrice;
        durationMinutes = product.defaultDurationMinutes;
      }
    }

    // Resolve Duration by Order Mode & Configuration
    if (orderMode === "Bathroom Cleaning") {
      const parsedMins = parseInt(configValue, 10);
      if (!isNaN(parsedMins) && parsedMins > 0) {
        durationMinutes = parsedMins;
      } else {
        const bc = await BathroomCount.findOne({ countValue: 2, isActive: true });
        durationMinutes = bc ? bc.defaultDurationMinutes : 90;
      }
      if (!basePrice) basePrice = 5500;
    } else if (orderMode === "Deep Cleaning") {
      const parsedMins = parseInt(configValue, 10);
      if (!isNaN(parsedMins) && parsedMins > 0) {
        durationMinutes = parsedMins;
      } else {
        const ps = await PropertySize.findOne({ sizeCode: "2BHK", isActive: true });
        durationMinutes = ps ? ps.defaultDurationMinutes : 240;
      }
      if (!basePrice) basePrice = 13974.58;
    } else {
      // Product Installation
      if (variantId) {
        const variantPricing = await Pricing.findOne({ variant: variantId, isActive: true });
        if (variantPricing) {
          basePrice = variantPricing.baseRate;
        }
      }
      if (!basePrice) basePrice = 7500;
      durationMinutes = 120;
    }

    const endTime = endFrom(startTime, durationMinutes);
    const durationText = calculateDurationText(startTime, endTime);

    const financials = calculateFinancials({
      basePrice,
      discount,
      cgstRate: 9,
      sgstRate: 9,
    });

    return {
      ...financials,
      durationMinutes,
      durationText,
      startTime,
      endTime,
    };
  }
}

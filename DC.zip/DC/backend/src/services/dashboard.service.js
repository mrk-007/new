/**
 * @file dashboard.service.js
 * @description Aggregates KPI, today's flow, lifecycle, and catalog preview for the existing frontend.
 */
import { Order } from "../models/Order.model.js";
import { Visit } from "../models/Visit.model.js";
import { Subscription } from "../models/Subscription.model.js";
import { Technician } from "../models/Technician.model.js";
import { Product } from "../models/Product.model.js";
import { SubscriptionPlan } from "../models/SubscriptionPlan.model.js";
import { TechnicianAllocation } from "../models/TechnicianAllocation.model.js";
import { Address } from "../models/Address.model.js";
import { CATALOG_META, LIFECYCLE, ALLOCATION_STATUS, VISIT_STATUS } from "../constants/index.js";
import { endOfDay, startOfDay, startOfMonth } from "../utils/time.js";

/** Formats a rupee amount for the KPI card. */
const formatMoney = (amount) => {
  if (amount >= 100000) return `₹${(amount / 100000).toFixed(2).replace(/\.00$/, "")}L`;
  return `₹${amount.toLocaleString("en-IN")}`;
};

/** Maps a visit status onto the arrival / work / follow-up chips the UI already renders. */
const flowStatus = (visit) => {
  if (visit.status === VISIT_STATUS.CANCELLED) {
    return {
      arrival: { code: "LATE", label: "Cancelled", tone: "danger" },
      workStatus: { code: "CANCELLED", label: "Cancelled", tone: "danger" },
      followUp: { code: "NONE", label: "-", tone: "default" },
    };
  }
  if (visit.status === VISIT_STATUS.COMPLETED) {
    return {
      arrival: { code: "ON_TIME", label: "Arrived", tone: "success" },
      workStatus: { code: "COMPLETED", label: "Completed", tone: "success" },
      followUp: { code: "PENDING", label: "Follow-up", tone: "info" },
    };
  }
  if (visit.status === VISIT_STATUS.IN_PROGRESS) {
    return {
      arrival: { code: "ON_TIME", label: "Reached", tone: "success" },
      workStatus: { code: "IN_PROGRESS", label: "In progress", tone: "warning" },
      followUp: { code: "NONE", label: "-", tone: "default" },
    };
  }
  return {
    arrival: { code: "ON_TIME", label: "Scheduled", tone: "default" },
    workStatus: { code: "ASSIGNED", label: "Pending", tone: "default" },
    followUp: { code: "NONE", label: "-", tone: "default" },
  };
};

/** Builds the dashboard payload used by the existing frontend. */
export const getDashboard = async () => {
  const now = new Date();
  const todayStart = startOfDay(now);
  const todayEnd = endOfDay(now);
  const monthStart = startOfMonth(now);

  const [ordersToday, jobsToday, activeSubscriptions, availableTechnicians, orderSum, subSum] =
    await Promise.all([
      Order.countDocuments({ createdAt: { $gte: todayStart, $lt: todayEnd } }),
      Visit.countDocuments({ scheduledStart: { $gte: todayStart, $lt: todayEnd } }),
      Subscription.countDocuments({
        status: { $in: [VISIT_STATUS.PENDING, VISIT_STATUS.IN_PROGRESS] },
        isCompleted: false,
      }),
      Technician.countDocuments({ isActive: true, isAvailable: true }),
      Order.aggregate([
        { $match: { createdAt: { $gte: monthStart, $lt: todayEnd }, status: { $ne: "CANCELLED" } } },
        { $group: { _id: null, total: { $sum: "$totalAmount" } } },
      ]),
      Subscription.aggregate([
        { $match: { createdAt: { $gte: monthStart, $lt: todayEnd }, status: { $ne: "CANCELLED" } } },
        { $group: { _id: null, total: { $sum: "$totalAmount" } } },
      ]),
    ]);

  const monthCollection = formatMoney((orderSum[0]?.total || 0) + (subSum[0]?.total || 0));

  const todayVisits = await Visit.find({
    scheduledStart: { $gte: todayStart, $lt: todayEnd },
  })
    .populate("customer address order subscription")
    .sort({ scheduledStart: 1 })
    .lean();

  const visitIds = todayVisits.map((v) => v._id);
  const allocations = await TechnicianAllocation.find({
    visit: { $in: visitIds },
    status: ALLOCATION_STATUS.ASSIGNED,
  })
    .populate("technician")
    .lean();
  const techByVisit = new Map(allocations.map((row) => [String(row.visit), row.technician?.name]));

  const todayFlow = await Promise.all(
    todayVisits.map(async (visit) => {
      const address = visit.address;
      const apartmentName = address?.apartment
        ? (await Address.findById(address._id).populate("apartment"))?.apartment?.name
        : null;
      const work = visit.visitType === "SITE_VISIT" ? "Site visit" : "Service";
      const chips = flowStatus(visit);
      return {
        id: String(visit._id),
        property: apartmentName || address?.area || address?.city || "Unknown Property",
        work,
        technician: techByVisit.get(String(visit._id)) || "Unassigned",
        ...chips,
      };
    })
  );

  const products = await Product.find({ isActive: true }).sort({ name: 1 }).limit(4).lean();
  const plans = await SubscriptionPlan.find({ isActive: true }).sort({ name: 1 }).lean();
  const catalogSource = [
    ...products.map((item) => ({ ...item, kind: "product" })),
    ...plans.map((item) => ({ ...item, kind: "plan" })),
  ].slice(0, 4);

  const catalogPreview = catalogSource.map((item, index) => {
    const meta = CATALOG_META[item.code] || { iconKey: "handyman", group: item.kind === "plan" ? "Subscription" : "Product" };
    return {
      id: String(item._id),
      name: item.name,
      iconKey: meta.iconKey,
      group: meta.group,
      description: item.description || item.name,
      price: null,
      displayOrder: index + 1,
    };
  });

  const payload = {
    kpis: {
      ordersToday,
      jobsToday,
      activeSubscriptions,
      availableTechnicians,
      monthCollection,
    },
    todayFlow,
    lifecycle: LIFECYCLE,
    catalogPreview,
  };

  return payload;
};

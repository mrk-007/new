import { Role, Module, RolePermission, User, Technician } from "../models/index.js";
import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { parseQueryParams, calculatePagination } from "../utils/queryHelper.js";
import { recordAuditLog } from "../utils/auditLogger.js";

export class RbacService {
  // ================= ROLES =================
  static async getRoles() {
    return Role.find({ isActive: true }).sort({ roleName: 1 });
  }

  static async getRoleById(roleId) {
    const role = await Role.findOne({ _id: roleId, isActive: true });
    if (!role) {
      throw new AppError("Role not found.", HTTP_STATUS.NOT_FOUND);
    }
    return role;
  }

  static async createRole(data, userId) {
    const exists = await Role.findOne({ roleKey: data.roleKey.toLowerCase() });
    if (exists) {
      throw new AppError(`Role key '${data.roleKey}' already exists.`, HTTP_STATUS.CONFLICT);
    }

    const role = await Role.create({
      ...data,
      createdBy: userId,
    });

    await recordAuditLog({
      action: "CREATE_ROLE",
      module: "roles",
      recordId: role._id,
      performedBy: userId,
      newState: role,
    });

    return role;
  }

  static async updateRole(roleId, data, userId) {
    const role = await Role.findOne({ _id: roleId, isActive: true });
    if (!role) {
      throw new AppError("Role not found.", HTTP_STATUS.NOT_FOUND);
    }

    if (role.isSystemRole && data.roleKey && data.roleKey !== role.roleKey) {
      throw new AppError("System role key cannot be modified.", HTTP_STATUS.BAD_REQUEST);
    }

    const previousState = { ...role.toObject() };
    Object.assign(role, data, { updatedBy: userId });
    await role.save();

    await recordAuditLog({
      action: "UPDATE_ROLE",
      module: "roles",
      recordId: role._id,
      performedBy: userId,
      previousState,
      newState: role,
    });

    return role;
  }

  static async deleteRole(roleId, userId) {
    const role = await Role.findOne({ _id: roleId, isActive: true });
    if (!role) {
      throw new AppError("Role not found.", HTTP_STATUS.NOT_FOUND);
    }

    if (role.isSystemRole) {
      throw new AppError("System role cannot be deleted.", HTTP_STATUS.BAD_REQUEST);
    }

    // Check if any active user assigned to this role
    const usersCount = await User.countDocuments({ role: roleId, isActive: true });
    if (usersCount > 0) {
      throw new AppError(
        `Cannot delete role. There are ${usersCount} active users assigned to this role.`,
        HTTP_STATUS.CONFLICT
      );
    }

    role.isActive = false;
    role.updatedBy = userId;
    await role.save();

    await recordAuditLog({
      action: "DELETE_ROLE",
      module: "roles",
      recordId: role._id,
      performedBy: userId,
    });

    return true;
  }

  // ================= MODULES =================
  static async getModules() {
    return Module.find({ isActive: true }).sort({ displayOrder: 1 });
  }

  static async createModule(data, userId) {
    const exists = await Module.findOne({ moduleKey: data.moduleKey.toLowerCase() });
    if (exists) {
      throw new AppError(`Module key '${data.moduleKey}' already exists.`, HTTP_STATUS.CONFLICT);
    }

    const moduleDoc = await Module.create({
      ...data,
      createdBy: userId,
    });

    return moduleDoc;
  }

  static async updateModule(moduleId, data, userId) {
    const moduleDoc = await Module.findOne({ _id: moduleId, isActive: true });
    if (!moduleDoc) {
      throw new AppError("Module not found.", HTTP_STATUS.NOT_FOUND);
    }

    Object.assign(moduleDoc, data, { updatedBy: userId });
    await moduleDoc.save();
    return moduleDoc;
  }

  // ================= ROLE PERMISSIONS =================
  static async getRolePermissions(roleId) {
    const role = await Role.findOne({ _id: roleId, isActive: true });
    if (!role) {
      throw new AppError("Role not found.", HTTP_STATUS.NOT_FOUND);
    }

    const allModules = await Module.find({ isActive: true }).sort({ displayOrder: 1 });
    const existingPerms = await RolePermission.find({ role: roleId, isActive: true }).populate("module");

    const permMap = new Map();
    existingPerms.forEach((ep) => {
      if (ep.module) {
        permMap.set(ep.module.moduleKey, ep);
      }
    });

    const matrix = allModules.map((m) => {
      const p = permMap.get(m.moduleKey);
      return {
        moduleKey: m.moduleKey,
        moduleName: m.moduleName,
        category: m.category,
        isRead: p ? p.isRead : role.roleKey === "super_admin",
        isWrite: p ? p.isWrite : role.roleKey === "super_admin",
        isDelete: p ? p.isDelete : role.roleKey === "super_admin",
      };
    });

    return { role, permissions: matrix };
  }

  static async updateRolePermissions(roleId, permissionsArray, userId) {
    const role = await Role.findOne({ _id: roleId, isActive: true });
    if (!role) {
      throw new AppError("Role not found.", HTTP_STATUS.NOT_FOUND);
    }

    for (const p of permissionsArray) {
      const moduleDoc = await Module.findOne({ moduleKey: p.moduleKey, isActive: true });
      if (moduleDoc) {
        await RolePermission.findOneAndUpdate(
          { role: roleId, module: moduleDoc._id },
          {
            $set: {
              isRead: Boolean(p.isRead),
              isWrite: Boolean(p.isWrite),
              isDelete: Boolean(p.isDelete),
              updatedBy: userId,
            },
          },
          { upsert: true, new: true }
        );
      }
    }

    await recordAuditLog({
      action: "UPDATE_ROLE_PERMISSIONS",
      module: "roles",
      recordId: roleId,
      performedBy: userId,
      newState: { permissions: permissionsArray },
    });

    return this.getRolePermissions(roleId);
  }

  // ================= USERS =================
  static async getUsers(queryParams) {
    const searchFields = ["username", "fullName", "email", "mobile"];
    const { filter, sort, skip, limit, page } = parseQueryParams(queryParams, searchFields);

    const [users, total] = await Promise.all([
      User.find(filter)
        .populate("role")
        .populate("technicianProfile")
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .lean(),
      User.countDocuments(filter),
    ]);

    const pagination = calculatePagination(total, page, limit);
    return { users, pagination };
  }

  static async getUserById(userId) {
    const user = await User.findOne({ _id: userId, isActive: true })
      .populate("role")
      .populate("technicianProfile");
    if (!user) {
      throw new AppError("User not found.", HTTP_STATUS.NOT_FOUND);
    }
    return user;
  }

  static async createUser(data, creatorId) {
    const existing = await User.findOne({
      $or: [{ username: data.username.toLowerCase() }, ...(data.email ? [{ email: data.email.toLowerCase() }] : [])],
    });

    if (existing) {
      throw new AppError("Username or email already in use.", HTTP_STATUS.CONFLICT);
    }

    const passwordHash = await User.hashPassword(data.password);
    const user = await User.create({
      username: data.username.toLowerCase(),
      fullName: data.fullName,
      email: data.email ? data.email.toLowerCase() : "",
      mobile: data.mobile || "",
      passwordHash,
      role: data.roleId,
      technicianProfile: data.technicianId || null,
      createdBy: creatorId,
    });

    if (data.technicianId) {
      await Technician.findByIdAndUpdate(data.technicianId, { user: user._id });
    }

    await recordAuditLog({
      action: "CREATE_USER",
      module: "users",
      recordId: user._id,
      performedBy: creatorId,
      newState: { username: user.username, role: data.roleId },
    });

    return User.findById(user._id).populate("role").populate("technicianProfile");
  }

  static async updateUser(userId, data, modifierId) {
    const user = await User.findOne({ _id: userId, isActive: true });
    if (!user) {
      throw new AppError("User not found.", HTTP_STATUS.NOT_FOUND);
    }

    const updates = {};
    if (data.fullName !== undefined) updates.fullName = data.fullName;
    if (data.email !== undefined) updates.email = data.email.toLowerCase();
    if (data.mobile !== undefined) updates.mobile = data.mobile;
    if (data.roleId) updates.role = data.roleId;
    if (data.isActive !== undefined) updates.isActive = data.isActive;
    if (data.resetLockout) {
      updates.failedLoginAttempts = 0;
      updates.lockUntil = null;
    }
    updates.updatedBy = modifierId;

    const updatedUser = await User.findByIdAndUpdate(userId, { $set: updates }, { new: true })
      .populate("role")
      .populate("technicianProfile");

    await recordAuditLog({
      action: "UPDATE_USER",
      module: "users",
      recordId: userId,
      performedBy: modifierId,
      newState: updates,
    });

    return updatedUser;
  }

  static async resetUserPassword(userId, newPassword, adminId) {
    const user = await User.findOne({ _id: userId, isActive: true });
    if (!user) {
      throw new AppError("User not found.", HTTP_STATUS.NOT_FOUND);
    }

    const passwordHash = await User.hashPassword(newPassword);
    await User.findByIdAndUpdate(userId, {
      $set: {
        passwordHash,
        refreshTokenHash: null,
        failedLoginAttempts: 0,
        lockUntil: null,
        updatedBy: adminId,
      },
    });

    await recordAuditLog({
      action: "ADMIN_RESET_PASSWORD",
      module: "users",
      recordId: userId,
      performedBy: adminId,
    });

    return true;
  }

  static async deleteUser(userId, adminId) {
    const user = await User.findOne({ _id: userId, isActive: true });
    if (!user) {
      throw new AppError("User not found.", HTTP_STATUS.NOT_FOUND);
    }

    user.isActive = false;
    user.updatedBy = adminId;
    user.refreshTokenHash = null;
    await user.save();

    await recordAuditLog({
      action: "DELETE_USER",
      module: "users",
      recordId: userId,
      performedBy: adminId,
    });

    return true;
  }
}

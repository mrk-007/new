import bcrypt from "bcryptjs";
import { User, Module, RolePermission } from "../models/index.js";
import { generateAccessToken, generateRefreshToken, verifyRefreshToken } from "../utils/tokenHelper.js";
import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { recordAuditLog } from "../utils/auditLogger.js";

export class AuthService {
  /**
   * Authenticate user with credentials and account lockout safety.
   */
  static async login({ username, password, ipAddress, userAgent }) {
    const user = await User.findOne({
      $or: [{ username: username.toLowerCase() }, { email: username.toLowerCase() }],
      isActive: true,
    })
      .select("+passwordHash")
      .populate("role")
      .populate("technicianProfile");

    if (!user) {
      await recordAuditLog({
        action: "LOGIN_FAILED",
        module: "auth",
        performerUsername: username,
        ipAddress,
        userAgent,
        newState: { reason: "User not found" },
      });
      throw new AppError("Invalid username or password credentials.", HTTP_STATUS.UNAUTHORIZED);
    }

    if (user.isLocked) {
      const remainingMinutes = Math.ceil((user.lockUntil - Date.now()) / (60 * 1000));
      await recordAuditLog({
        action: "LOGIN_BLOCKED",
        module: "auth",
        recordId: user._id,
        performerUsername: user.username,
        ipAddress,
        userAgent,
        newState: { lockUntil: user.lockUntil, remainingMinutes },
      });
      throw new AppError(
        `Account is temporarily locked. Please try again after ${remainingMinutes} minutes.`,
        HTTP_STATUS.FORBIDDEN
      );
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      await user.incrementFailedAttempts();
      await recordAuditLog({
        action: "LOGIN_FAILED",
        module: "auth",
        recordId: user._id,
        performerUsername: user.username,
        ipAddress,
        userAgent,
        newState: { failedAttempts: user.failedLoginAttempts + 1 },
      });
      throw new AppError("Invalid username or password credentials.", HTTP_STATUS.UNAUTHORIZED);
    }

    // Reset lockout counter on success
    await user.resetLockout();

    // Generate JWTs
    const tokenPayload = {
      userId: user._id,
      username: user.username,
      roleId: user.role._id,
      roleKey: user.role.roleKey,
      technicianId: user.technicianProfile ? user.technicianProfile._id : null,
    };

    const accessToken = generateAccessToken(tokenPayload);
    const refreshToken = generateRefreshToken({ userId: user._id });

    // Store refresh token hash
    const refreshTokenHash = await bcrypt.hash(refreshToken, 10);
    await User.findByIdAndUpdate(user._id, { refreshTokenHash });

    // Build permissions & dynamic navigation menu
    const { permissions, menu } = await this.buildRolePermissionsAndMenu(user.role);

    await recordAuditLog({
      action: "LOGIN",
      module: "auth",
      recordId: user._id,
      performedBy: user._id,
      performerUsername: user.username,
      ipAddress,
      userAgent,
    });

    return {
      user: {
        id: user._id,
        username: user.username,
        fullName: user.fullName,
        email: user.email,
        mobile: user.mobile,
        role: {
          id: user.role._id,
          roleKey: user.role.roleKey,
          roleName: user.role.roleName,
        },
        technician: user.technicianProfile
          ? {
              id: user.technicianProfile._id,
              techId: user.technicianProfile.techId,
              name: user.technicianProfile.name,
              role: user.technicianProfile.roleTitle,
            }
          : null,
      },
      permissions,
      menu,
      accessToken,
      refreshToken,
    };
  }

  /**
   * Refresh Access Token using valid Refresh Token.
   */
  static async refresh({ refreshToken, ipAddress, userAgent }) {
    let decoded;
    try {
      decoded = verifyRefreshToken(refreshToken);
    } catch {
      throw new AppError("Invalid or expired refresh token. Please log in again.", HTTP_STATUS.UNAUTHORIZED);
    }

    const user = await User.findById(decoded.userId)
      .select("+refreshTokenHash")
      .populate("role")
      .populate("technicianProfile");

    if (!user || !user.isActive || !user.refreshTokenHash) {
      throw new AppError("Session terminated or invalid user.", HTTP_STATUS.UNAUTHORIZED);
    }

    const isMatch = await bcrypt.compare(refreshToken, user.refreshTokenHash);
    if (!isMatch) {
      throw new AppError("Refresh token mismatch or revoked.", HTTP_STATUS.UNAUTHORIZED);
    }

    const tokenPayload = {
      userId: user._id,
      username: user.username,
      roleId: user.role._id,
      roleKey: user.role.roleKey,
      technicianId: user.technicianProfile ? user.technicianProfile._id : null,
    };

    const newAccessToken = generateAccessToken(tokenPayload);

    await recordAuditLog({
      action: "TOKEN_REFRESH",
      module: "auth",
      recordId: user._id,
      performedBy: user._id,
      performerUsername: user.username,
      ipAddress,
      userAgent,
    });

    return {
      accessToken: newAccessToken,
    };
  }

  /**
   * Terminate user session and clear refresh token.
   */
  static async logout({ userId, ipAddress, userAgent }) {
    await User.findByIdAndUpdate(userId, { refreshTokenHash: null });
    await recordAuditLog({
      action: "LOGOUT",
      module: "auth",
      recordId: userId,
      performedBy: userId,
      ipAddress,
      userAgent,
    });
    return true;
  }

  /**
   * Get current authenticated user profile + role + dynamic menu.
   */
  static async getMe(userId) {
    const user = await User.findById(userId)
      .populate("role")
      .populate("technicianProfile");

    if (!user || !user.isActive) {
      throw new AppError("User account not found or inactive.", HTTP_STATUS.NOT_FOUND);
    }

    const { permissions, menu } = await this.buildRolePermissionsAndMenu(user.role);

    return {
      user: {
        id: user._id,
        username: user.username,
        fullName: user.fullName,
        email: user.email,
        mobile: user.mobile,
        role: {
          id: user.role._id,
          roleKey: user.role.roleKey,
          roleName: user.role.roleName,
        },
        technician: user.technicianProfile
          ? {
              id: user.technicianProfile._id,
              techId: user.technicianProfile.techId,
              name: user.technicianProfile.name,
              role: user.technicianProfile.roleTitle,
            }
          : null,
      },
      permissions,
      menu,
    };
  }

  /**
   * Change user password.
   */
  static async changePassword({ userId, currentPassword, newPassword, ipAddress, userAgent }) {
    const user = await User.findById(userId).select("+passwordHash");
    if (!user) {
      throw new AppError("User not found.", HTTP_STATUS.NOT_FOUND);
    }

    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      throw new AppError("Current password incorrect.", HTTP_STATUS.BAD_REQUEST);
    }

    const newHash = await User.hashPassword(newPassword);
    await User.findByIdAndUpdate(userId, {
      passwordHash: newHash,
      refreshTokenHash: null, // Force re-login on all devices
    });

    await recordAuditLog({
      action: "PASSWORD_CHANGE",
      module: "auth",
      recordId: user._id,
      performedBy: user._id,
      performerUsername: user.username,
      ipAddress,
      userAgent,
    });

    return true;
  }

  /**
   * Helper: Builds granular permissions matrix and dynamic navigation menu from DB.
   */
  static async buildRolePermissionsAndMenu(role) {
    const allModules = await Module.find({ isActive: true }).sort({ displayOrder: 1 });
    const isSuperAdmin = role.roleKey === "super_admin";

    let permissions = [];

    if (isSuperAdmin) {
      permissions = allModules.map((m) => ({
        moduleKey: m.moduleKey,
        moduleName: m.moduleName,
        isRead: true,
        isWrite: true,
        isDelete: true,
      }));
    } else {
      const rolePerms = await RolePermission.find({ role: role._id, isActive: true }).populate("module");
      const permMap = new Map();
      rolePerms.forEach((rp) => {
        if (rp.module && rp.module.isActive) {
          permMap.set(rp.module.moduleKey, {
            moduleKey: rp.module.moduleKey,
            moduleName: rp.module.moduleName,
            isRead: rp.isRead,
            isWrite: rp.isWrite,
            isDelete: rp.isDelete,
          });
        }
      });

      permissions = allModules.map((m) => {
        return (
          permMap.get(m.moduleKey) || {
            moduleKey: m.moduleKey,
            moduleName: m.moduleName,
            isRead: false,
            isWrite: false,
            isDelete: false,
          }
        );
      });
    }

    // Dynamic menu: only modules where user has isRead === true
    const allowedKeys = new Set(permissions.filter((p) => p.isRead).map((p) => p.moduleKey));
    const menu = allModules
      .filter((m) => allowedKeys.has(m.moduleKey))
      .map((m) => ({
        key: m.moduleKey,
        label: m.moduleName,
        path: m.routePath,
        icon: m.icon,
        category: m.category,
      }));

    return { permissions, menu };
  }
}

/**
 * @file audit.service.js
 * @description Writes append-only audit rows without failing the parent request.
 */
import { AuditLog } from "../models/AuditLog.model.js";
import { AUDIT_ACTION } from "../constants/index.js";

const SENSITIVE = new Set(["password"]);

/** Removes password fields from a plain object. */
const stripSensitive = (value) => {
  if (!value || typeof value !== "object") return value;
  const clone = { ...value };
  for (const key of SENSITIVE) delete clone[key];
  return clone;
};

/** Returns only fields that changed between two objects. */
export const diffFields = (before = {}, after = {}) => {
  const beforeDiff = {};
  const afterDiff = {};
  const keys = new Set([...Object.keys(before), ...Object.keys(after)]);
  for (const key of keys) {
    if (SENSITIVE.has(key)) continue;
    const left = before[key];
    const right = after[key];
    if (JSON.stringify(left) === JSON.stringify(right)) continue;
    beforeDiff[key] = left;
    afterDiff[key] = right;
  }
  return { before: beforeDiff, after: afterDiff };
};

/** Persists an audit log row; swallows write failures. */
export const log = async ({ entity, entityId, action, before, after, performedBy, ip, userAgent }) => {
  try {
    await AuditLog.create({
      entity,
      entityId,
      action,
      before: stripSensitive(before),
      after: stripSensitive(after),
      performedBy,
      ip,
      userAgent,
      createdBy: performedBy,
      updatedBy: performedBy,
    });
  } catch {
    // Audit must never break the main request.
  }
};

export { AUDIT_ACTION };

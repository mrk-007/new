/**
 * @file customer.service.js
 * @description Customer and address helpers including single-default enforcement.
 */
import { Address } from "../models/Address.model.js";
import { Customer } from "../models/Customer.model.js";
import { AppError } from "../utils/appError.js";
import { create, getById, update, softDelete, actorMeta } from "./crud.service.js";
import { AUDIT_ACTION, log } from "./audit.service.js";

/** Clears other default flags for a customer. */
export const clearOtherDefaults = async (customerId, keepId) => {
  await Address.updateMany(
    { customer: customerId, _id: { $ne: keepId } },
    { $set: { isDefault: false } }
  );
};

/** Creates an address and optionally marks it as the only default. */
export const createAddress = async (customerId, body, req) => {
  await getById(Customer, customerId);
  const address = await create(Address, { ...body, customer: customerId }, req);
  if (address.isDefault) await clearOtherDefaults(customerId, address._id);
  return address;
};

/** Updates an address belonging to any customer. */
export const updateAddress = async (id, body, req) => {
  const address = await update(Address, id, body, req);
  if (address.isDefault) await clearOtherDefaults(address.customer, address._id);
  return address;
};

/** Marks an address as the customer's default. */
export const setDefaultAddress = async (id, req) => {
  const address = await getById(Address, id);
  const { actorId, ip, userAgent } = actorMeta(req);
  const before = { isDefault: address.isDefault };
  address.isDefault = true;
  address.updatedBy = actorId;
  await address.save();
  await clearOtherDefaults(address.customer, address._id);
  await log({
    entity: "Address",
    entityId: address._id,
    action: AUDIT_ACTION.UPDATE,
    before,
    after: { isDefault: true },
    performedBy: actorId,
    ip,
    userAgent,
  });
  return address;
};

/** Lists addresses for a customer. */
export const listAddresses = async (customerId, query) => {
  await getById(Customer, customerId);
  const filter = { customer: customerId };
  if (query.isActive !== "false") filter.isActive = true;
  return Address.find(filter).populate("apartment").sort({ isDefault: -1, createdAt: -1 });
};

/** Soft-deletes an address. */
export const softDeleteAddress = async (id, req) => {
  const address = await getById(Address, id);
  if (!address.isActive) throw new AppError(409, "Address is already inactive.");
  return softDelete(Address, id, req);
};

import {
  Customer,
  CustomerAddress,
  Order,
  Subscription,
  JobOrder,
  Invoice,
  Counter,
  ActiveStatus,
  Area,
} from "../models/index.js";
import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { parseQueryParams, calculatePagination } from "../utils/queryHelper.js";
import { recordAuditLog } from "../utils/auditLogger.js";

export class CustomerService {
  /**
   * Get paginated customer directory with live counts.
   */
  static async getCustomers(queryParams) {
    const searchFields = ["name", "mobile", "email"];
    const { filter, sort, skip, limit, page } = parseQueryParams(queryParams, searchFields);

    // Filter by customer status label if provided
    if (queryParams.status && queryParams.status !== "All Statuses" && queryParams.status !== "all") {
      const statusDoc = await ActiveStatus.findOne({ statusLabel: queryParams.status });
      if (statusDoc) {
        filter.status = statusDoc._id;
      }
    }

    // Filter by area if provided
    if (queryParams.area && queryParams.area !== "all") {
      const propertiesInArea = await CustomerAddress.find({
        areaName: queryParams.area,
        isActive: true,
      }).distinct("customer");
      filter._id = { $in: propertiesInArea };
    }

    const [customersRaw, total] = await Promise.all([
      Customer.find(filter)
        .populate("status")
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .lean(),
      Customer.countDocuments(filter),
    ]);

    // Attach related counts (Properties, Orders, Subscriptions, Open Jobs)
    const customerIds = customersRaw.map((c) => c._id);

    const [propertiesMap, ordersMap, subsMap, openJobsMap] = await Promise.all([
      CustomerAddress.aggregate([
        { $match: { customer: { $in: customerIds }, isActive: true } },
        { $group: { _id: "$customer", count: { $sum: 1 }, items: { $push: "$$ROOT" } } },
      ]),
      Order.aggregate([
        { $match: { customer: { $in: customerIds }, isActive: true } },
        { $group: { _id: "$customer", count: { $sum: 1 } } },
      ]),
      Subscription.aggregate([
        { $match: { customer: { $in: customerIds }, isActive: true } },
        { $group: { _id: "$customer", count: { $sum: 1 } } },
      ]),
      JobOrder.aggregate([
        {
          $match: {
            customer: { $in: customerIds },
            isActive: true,
            statusLabel: { $nin: ["Completed", "Closed"] },
          },
        },
        { $group: { _id: "$customer", count: { $sum: 1 } } },
      ]),
    ]);

    const pMap = new Map(propertiesMap.map((p) => [String(p._id), p]));
    const oMap = new Map(ordersMap.map((o) => [String(o._id), o.count]));
    const sMap = new Map(subsMap.map((s) => [String(s._id), s.count]));
    const jMap = new Map(openJobsMap.map((j) => [String(j._id), j.count]));

    const customers = customersRaw.map((c) => {
      const cId = String(c._id);
      const propData = pMap.get(cId) || { count: 0, items: [] };

      return {
        ...c,
        propertiesCount: propData.count,
        properties: propData.items,
        ordersCount: oMap.get(cId) || 0,
        subscriptionsCount: sMap.get(cId) || 0,
        openJobsCount: jMap.get(cId) || 0,
        statusLabel: c.status?.statusLabel || "Active",
      };
    });

    const pagination = calculatePagination(total, page, limit);
    return { customers, pagination };
  }

  /**
   * Get single customer by ID.
   */
  static async getCustomerById(id) {
    const customer = await Customer.findOne({ _id: id, isActive: true })
      .populate("status")
      .populate("properties");

    if (!customer) {
      throw new AppError("Customer not found.", HTTP_STATUS.NOT_FOUND);
    }
    return customer;
  }

  /**
   * Create a new customer along with their primary property address.
   */
  static async createCustomer(data, userId) {
    // Generate sequential IDs
    const customerId = await Counter.getNextSequence("CUSTOMER", "CUS", 6);
    const propertyId = await Counter.getNextSequence("PROPERTY", "PROP", 3);

    // Resolve active status
    const statusDoc = await ActiveStatus.findOne({ statusCode: "ACTIVE" });

    // Resolve Area reference if exists
    let areaDoc = null;
    if (data.property.areaName) {
      areaDoc = await Area.findOne({ name: data.property.areaName });
    }

    const customer = await Customer.create({
      customerId,
      name: data.name,
      mobile: data.mobile,
      whatsapp: data.whatsapp || data.mobile,
      email: data.email || "",
      status: statusDoc ? statusDoc._id : null,
      createdBy: userId,
    });

    const property = await CustomerAddress.create({
      propertyId,
      customer: customer._id,
      label: data.property.label || "Home",
      propertyName: data.property.propertyName,
      door: data.property.door || "",
      area: areaDoc ? areaDoc._id : null,
      areaName: data.property.areaName,
      address: data.property.address || "",
      isDefault: true,
      createdBy: userId,
    });

    await recordAuditLog({
      action: "CREATE_CUSTOMER",
      module: "customers",
      recordId: customer._id,
      performedBy: userId,
      newState: { customerId, name: customer.name, mobile: customer.mobile, propertyId },
    });

    return {
      ...customer.toObject(),
      status: statusDoc,
      properties: [property],
    };
  }

  /**
   * Update existing customer details.
   */
  static async updateCustomer(id, data, userId) {
    const customer = await Customer.findOne({ _id: id, isActive: true });
    if (!customer) {
      throw new AppError("Customer not found.", HTTP_STATUS.NOT_FOUND);
    }

    const previousState = { ...customer.toObject() };
    Object.assign(customer, data, { updatedBy: userId });
    await customer.save();

    await recordAuditLog({
      action: "UPDATE_CUSTOMER",
      module: "customers",
      recordId: customer._id,
      performedBy: userId,
      previousState,
      newState: customer,
    });

    return customer;
  }

  /**
   * Soft-delete customer.
   */
  static async deleteCustomer(id, userId) {
    const customer = await Customer.findOne({ _id: id, isActive: true });
    if (!customer) {
      throw new AppError("Customer not found.", HTTP_STATUS.NOT_FOUND);
    }

    customer.isActive = false;
    customer.updatedBy = userId;
    await customer.save();

    // Soft delete associated addresses
    await CustomerAddress.updateMany(
      { customer: id, isActive: true },
      { $set: { isActive: false, updatedBy: userId } }
    );

    await recordAuditLog({
      action: "DELETE_CUSTOMER",
      module: "customers",
      recordId: customer._id,
      performedBy: userId,
    });

    return true;
  }

  /**
   * Add additional property address to an existing customer.
   */
  static async addCustomerProperty(customerId, propertyData, userId) {
    const customer = await Customer.findOne({ _id: customerId, isActive: true });
    if (!customer) {
      throw new AppError("Customer not found.", HTTP_STATUS.NOT_FOUND);
    }

    const propertyId = await Counter.getNextSequence("PROPERTY", "PROP", 3);

    // If marked default, unset existing defaults
    if (propertyData.isDefault) {
      await CustomerAddress.updateMany(
        { customer: customerId, isActive: true },
        { $set: { isDefault: false } }
      );
    }

    let areaDoc = null;
    if (propertyData.areaName) {
      areaDoc = await Area.findOne({ name: propertyData.areaName });
    }

    const property = await CustomerAddress.create({
      propertyId,
      customer: customer._id,
      label: propertyData.label || "Home",
      propertyName: propertyData.propertyName,
      door: propertyData.door || "",
      area: areaDoc ? areaDoc._id : null,
      areaName: propertyData.areaName,
      address: propertyData.address || "",
      isDefault: Boolean(propertyData.isDefault),
      createdBy: userId,
    });

    return property;
  }

  /**
   * Customer 360° Comprehensive Profile Dataset.
   */
  static async getCustomer360(customerId) {
    const customer = await Customer.findOne({ _id: customerId, isActive: true }).populate("status");
    if (!customer) {
      throw new AppError("Customer not found.", HTTP_STATUS.NOT_FOUND);
    }

    const [properties, orders, subscriptions, jobs, invoices] = await Promise.all([
      CustomerAddress.find({ customer: customerId, isActive: true }).sort({ isDefault: -1 }),
      Order.find({ customer: customerId, isActive: true }).populate("property").sort({ createdAt: -1 }),
      Subscription.find({ customer: customerId, isActive: true }).populate("property").sort({ createdAt: -1 }),
      JobOrder.find({ customer: customerId, isActive: true })
        .populate("technician", "name roleTitle")
        .populate("property")
        .sort({ plannedDate: -1, startTime: -1 }),
      Invoice.find({ customer: customerId, isActive: true }).sort({ createdAt: -1 }),
    ]);

    const totalPaid = invoices
      .filter((inv) => inv.statusLabel === "Paid")
      .reduce((sum, inv) => sum + inv.totalAmount, 0);

    const stats = {
      propertiesCount: properties.length,
      ordersCount: orders.length,
      subscriptionsCount: subscriptions.length,
      totalPaid,
    };

    // Build Chronological Activity Timeline
    const activityTimeline = [];

    orders.forEach((o) => {
      activityTimeline.push({
        event: "Order created",
        details: `${o.orderId} · ${o.serviceName}`,
        timestamp: o.createdAt,
        actor: "Telecaller",
      });
    });

    invoices.forEach((inv) => {
      activityTimeline.push({
        event: "Invoice generated",
        details: `${inv.invoiceId} (₹${inv.totalAmount.toLocaleString("en-IN")})`,
        timestamp: inv.createdAt,
        actor: "System",
      });
    });

    jobs.forEach((j) => {
      activityTimeline.push({
        event: `Job ${j.statusLabel}`,
        details: `${j.jobId} · ${j.title} (${j.technician?.name || "Unassigned"})`,
        timestamp: j.updatedAt || j.createdAt,
        actor: j.technician?.name || "Operations",
      });
    });

    activityTimeline.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    return {
      customer,
      stats,
      properties,
      orders,
      subscriptions,
      jobs,
      invoices,
      activityTimeline,
    };
  }

  /**
   * Export complete customer record to CSV string.
   */
  static async exportCustomerCsv(customerId) {
    const data = await this.getCustomer360(customerId);
    const c = data.customer;

    let csv = `CUSTOMER 360 RECORD\n`;
    csv += `Customer ID,${c.customerId}\n`;
    csv += `Name,${c.name}\n`;
    csv += `Mobile,${c.mobile}\n`;
    csv += `WhatsApp,${c.whatsapp || ""}\n`;
    csv += `Email,${c.email || ""}\n`;
    csv += `Status,${c.status?.statusLabel || "Active"}\n\n`;

    csv += `PROPERTIES\nProperty ID,Label,Name,Door,Area,Address\n`;
    data.properties.forEach((p) => {
      csv += `${p.propertyId},${p.label},"${p.propertyName}","${p.door}","${p.areaName}","${p.address || ""}"\n`;
    });

    csv += `\nORDERS\nOrder ID,Type,Service,Amount,Invoice,Status,Date\n`;
    data.orders.forEach((o) => {
      csv += `${o.orderId},${o.orderType},"${o.serviceName}",${o.totalAmount},${o.invoiceNumber},${o.status},${o.serviceDate}\n`;
    });

    csv += `\nSUBSCRIPTIONS\nSubscription ID,Type,Configuration,Frequency,Slot,Visits,Next Visit,Status\n`;
    data.subscriptions.forEach((s) => {
      csv += `${s.subscriptionId},${s.typeName},"${s.configuration}",${s.frequency},${s.slot},"${s.completedVisits}/${s.totalVisits}",${s.nextVisitDate},${s.status}\n`;
    });

    csv += `\nJOB ORDERS\nJob ID,Title,Date,Time,Technician,Status,Arrival,Completed\n`;
    data.jobs.forEach((j) => {
      csv += `${j.jobId},"${j.title}",${j.plannedDate},"${j.startTime}-${j.endTime}","${j.technician?.name || ""}",${j.statusLabel},${j.arrivalTime || ""},${j.workCompletedTime || ""}\n`;
    });

    return csv;
  }
}

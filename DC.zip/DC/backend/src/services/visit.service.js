/**
 * @file visit.service.js
 * @description Visit lifecycle, listing, allocation retry, and parent status side-effects.
 */
import { Visit } from "../models/Visit.model.js";
import { Order } from "../models/Order.model.js";
import { Subscription } from "../models/Subscription.model.js";
import { Technician } from "../models/Technician.model.js";
import { TechnicianAllocation } from "../models/TechnicianAllocation.model.js";
import { Address } from "../models/Address.model.js";
import { AppError } from "../utils/appError.js";
import {
  ALLOCATION_STATUS,
  AUDIT_ACTION,
  ORDER_STATUS,
  VISIT_STATUS,
  VISIT_TRANSITIONS,
  VISIT_TYPE,
} from "../constants/index.js";
import { parsePagination, buildMeta } from "../utils/pagination.js";
import { startOfDay, endOfDay, toDateTime } from "../utils/time.js";
import { actorMeta, getById } from "./crud.service.js";
import { log, diffFields } from "./audit.service.js";
import { allocateVisit, reassignVisit, releaseAllocation } from "./allocation.service.js";
import { applyTax } from "./tax.service.js";

const VISIT_POPULATE = "customer address order subscription";

/** Asserts a visit status transition is allowed. */
const assertTransition = (from, to) => {
  if (!VISIT_TRANSITIONS[from]?.includes(to)) {
    throw new AppError(409, `Invalid visit transition from ${from} to ${to}.`);
  }
};

/** Writes a visit audit row for a status change. */
const auditVisit = async (visit, before, req) => {
  const { actorId, ip, userAgent } = actorMeta(req);
  const diff = diffFields(before, visit.toObject());
  await log({
    entity: "Visit",
    entityId: visit._id,
    action: AUDIT_ACTION.UPDATE,
    before: diff.before,
    after: diff.after,
    performedBy: actorId,
    ip,
    userAgent,
  });
};

/** Appends order status history and snapshots tax when quoting. */
const changeOrderStatus = async (order, status, req, note) => {
  const { actorId, ip, userAgent } = actorMeta(req);
  const before = { status: order.status };
  order.status = status;
  if (status === ORDER_STATUS.COMPLETED) order.deliveredAt = new Date();
  order.statusHistory.push({ status, changedAt: new Date(), changedBy: actorId, note });
  order.updatedBy = actorId;
  await order.save();
  await log({
    entity: "Order",
    entityId: order._id,
    action: AUDIT_ACTION.UPDATE,
    before,
    after: { status },
    performedBy: actorId,
    ip,
    userAgent,
  });
};

/** Marks a subscription completed when every SERVICE visit is COMPLETED. */
export const refreshSubscriptionCompletion = async (subscriptionId, req) => {
  if (!subscriptionId) return;
  const subscription = await Subscription.findById(subscriptionId);
  if (!subscription || subscription.status === VISIT_STATUS.CANCELLED) return;
  const serviceVisits = await Visit.find({
    subscription: subscriptionId,
    visitType: VISIT_TYPE.SERVICE,
  });
  if (!serviceVisits.length) return;
  const allDone = serviceVisits.every((visit) => visit.status === VISIT_STATUS.COMPLETED);
  if (!allDone) return;
  const { actorId, ip, userAgent } = actorMeta(req);
  const before = { status: subscription.status, isCompleted: subscription.isCompleted };
  subscription.status = VISIT_STATUS.COMPLETED;
  subscription.isCompleted = true;
  subscription.updatedBy = actorId;
  await subscription.save();
  await log({
    entity: "Subscription",
    entityId: subscription._id,
    action: AUDIT_ACTION.UPDATE,
    before,
    after: { status: VISIT_STATUS.COMPLETED, isCompleted: true },
    performedBy: actorId,
    ip,
    userAgent,
  });
};

/** Creates a visit document and attempts allocation. */
export const createVisit = async (payload, req) => {
  const { actorId } = actorMeta(req);
  const visit = await Visit.create({ ...payload, createdBy: actorId, updatedBy: actorId });
  await log({
    entity: "Visit",
    entityId: visit._id,
    action: AUDIT_ACTION.CREATE,
    before: null,
    after: visit.toObject(),
    performedBy: actorId,
    ip: req.ip,
    userAgent: req.get("user-agent"),
  });
  const allocation = await allocateVisit(visit, req);
  return { visit, allocated: Boolean(allocation) };
};

/** Lists visits with date/status/technician/type filters. */
export const listVisits = async (req, extraFilter = {}) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = { ...extraFilter };
  if (req.query.status) filter.status = req.query.status;
  if (req.query.visitType) filter.visitType = req.query.visitType;
  if (req.query.date) {
    const start = toDateTime(req.query.date, "00:00");
    filter.scheduledStart = { $gte: start, $lt: endOfDay(start) };
  }
  if (req.query.technician) {
    const rows = await TechnicianAllocation.find({
      technician: req.query.technician,
      status: ALLOCATION_STATUS.ASSIGNED,
    }).select("visit");
    filter._id = { $in: rows.map((row) => row.visit) };
  }
  const [items, total] = await Promise.all([
    Visit.find(filter).populate(VISIT_POPULATE).sort({ scheduledStart: 1 }).skip(skip).limit(limit),
    Visit.countDocuments(filter),
  ]);
  return { items, meta: buildMeta(total, page, limit) };
};

/** Lists visits assigned to the authenticated technician user. */
export const listMine = async (req) => {
  const technician = await Technician.findOne({ user: req.user._id, isActive: true });
  if (!technician) throw new AppError(404, "No technician profile is linked to this user.");
  req.query.technician = String(technician._id);
  return listVisits(req);
};

/** Starts a visit and lifts the parent booking into IN_PROGRESS. */
export const startVisit = async (id, req) => {
  const visit = await getById(Visit, id);
  assertTransition(visit.status, VISIT_STATUS.IN_PROGRESS);
  const before = visit.toObject();
  visit.status = VISIT_STATUS.IN_PROGRESS;
  visit.startedAt = new Date();
  visit.updatedBy = req.user._id;
  await visit.save();
  await auditVisit(visit, before, req);

  if (visit.order) {
    const order = await Order.findById(visit.order);
    if (order && visit.visitType === VISIT_TYPE.SERVICE && order.status === ORDER_STATUS.CONFIRMED) {
      await changeOrderStatus(order, ORDER_STATUS.IN_PROGRESS, req, "Service visit started");
    }
  }
  if (visit.subscription) {
    const subscription = await Subscription.findById(visit.subscription);
    if (subscription && subscription.status === VISIT_STATUS.PENDING) {
      const { actorId, ip, userAgent } = actorMeta(req);
      const subBefore = { status: subscription.status };
      subscription.status = VISIT_STATUS.IN_PROGRESS;
      subscription.updatedBy = actorId;
      await subscription.save();
      await log({
        entity: "Subscription",
        entityId: subscription._id,
        action: AUDIT_ACTION.UPDATE,
        before: subBefore,
        after: { status: VISIT_STATUS.IN_PROGRESS },
        performedBy: actorId,
        ip,
        userAgent,
      });
    }
  }
  return visit;
};

/** Completes a visit, applying site-report quoting and generating follow-on visits. */
export const completeVisit = async (id, req) => {
  const visit = await getById(Visit, id, "order subscription");
  assertTransition(visit.status, VISIT_STATUS.COMPLETED);
  const before = visit.toObject();
  const body = req.body || {};
  if (visit.visitType === VISIT_TYPE.SITE_VISIT) {
    const quoted = Number(body.quotedAmount);
    if (Number.isNaN(quoted)) throw new AppError(400, "quotedAmount is required to complete a site visit.");
    visit.siteReport = {
      notes: body.notes,
      width: body.width,
      height: body.height,
      unit: body.unit,
      quotedAmount: quoted,
    };
  }
  visit.status = VISIT_STATUS.COMPLETED;
  visit.isCompleted = true;
  visit.completedAt = new Date();
  visit.updatedBy = req.user._id;
  await visit.save();
  await auditVisit(visit, before, req);

  if (visit.order && visit.visitType === VISIT_TYPE.SITE_VISIT) {
    const order = await Order.findById(visit.order);
    const address = await Address.findById(order.address);
    const quoted = Number(visit.siteReport?.quotedAmount);
    const snapshot = await applyTax(quoted, address);
    Object.assign(order, snapshot, { quotedAmount: quoted });
    await changeOrderStatus(order, ORDER_STATUS.QUOTED, req, "Site visit completed");
  }

  if (visit.order && visit.visitType === VISIT_TYPE.SERVICE) {
    const order = await Order.findById(visit.order);
    await changeOrderStatus(order, ORDER_STATUS.COMPLETED, req, "Service visit completed");
  }

  if (visit.subscription && visit.visitType === VISIT_TYPE.SITE_VISIT) {
    const { generateServiceVisits } = await import("./subscription.service.js");
    const generated = await generateServiceVisits(visit.subscription, req);
    return { visit, generated };
  }

  if (visit.subscription && visit.visitType === VISIT_TYPE.SERVICE) {
    await refreshSubscriptionCompletion(visit.subscription, req);
  }

  return { visit };
};

/** Cancels a visit and releases its allocation. */
export const cancelVisit = async (id, req) => {
  const visit = await getById(Visit, id);
  return cancelOpenVisit(visit, req, req.body?.cancelReason || "Visit cancelled");
};

/** Cancels pending/in-progress visits for a parent booking. */
export const cancelOpenVisitsFor = async ({ orderId, subscriptionId }, req, reason) => {
  const filter = {
    status: { $in: [VISIT_STATUS.PENDING, VISIT_STATUS.IN_PROGRESS] },
  };
  if (orderId) filter.order = orderId;
  if (subscriptionId) filter.subscription = subscriptionId;
  const visits = await Visit.find(filter);
  for (const visit of visits) {
    await cancelOpenVisit(visit, req, reason);
  }
};

/** Applies CANCELLED to one open visit with audit and allocation release. */
const cancelOpenVisit = async (visit, req, reason) => {
  assertTransition(visit.status, VISIT_STATUS.CANCELLED);
  const before = visit.toObject();
  visit.status = VISIT_STATUS.CANCELLED;
  visit.cancelReason = reason;
  visit.updatedBy = req.user._id;
  await visit.save();
  await auditVisit(visit, before, req);
  await releaseAllocation(visit._id, req, reason);
  return visit;
};

/** Retries auto-allocation for a pending visit. */
export const retryAllocate = async (id, req) => {
  const visit = await getById(Visit, id);
  const existing = await TechnicianAllocation.findOne({
    visit: visit._id,
    status: ALLOCATION_STATUS.ASSIGNED,
  });
  if (existing) return existing;
  const allocation = await allocateVisit(visit, req, req.body?.technicianId);
  if (!allocation) throw new AppError(409, "No skilled technician is free for this visit.");
  return allocation;
};

/** Reassigns a visit to another technician. */
export const reassign = async (id, req) => {
  const visit = await getById(Visit, id);
  return reassignVisit(visit, req, req.body?.technicianId);
};

export { startOfDay };

/**
 * @file pricing.service.js
 * @description Resolves a single active Pricing row by exact combination.
 */
import { Pricing } from "../models/Pricing.model.js";
import { Product } from "../models/Product.model.js";
import { SubscriptionPlan } from "../models/SubscriptionPlan.model.js";
import { Address } from "../models/Address.model.js";
import { AppError } from "../utils/appError.js";
import { PRODUCT_CODE, SERVICE_TYPE_CODE } from "../constants/index.js";
import { applyTax } from "./tax.service.js";

/** Throws when a required document is missing. */
const requireDoc = async (Model, id, label) => {
  const doc = await Model.findById(id);
  if (!doc) throw new AppError(404, `${label} not found.`);
  return doc;
};

/** Looks up ORDER pricing by product. */
export const resolveOrderPrice = async (productId) => {
  const product = await Product.findById(productId).populate("serviceType");
  if (!product) throw new AppError(404, "Product not found.");
  if (product.code === PRODUCT_CODE.MOSQUITO_NET) {
    throw new AppError(422, "Mosquito net price is entered after the site visit.");
  }
  const row = await Pricing.findOne({
    product: product._id,
    isActive: true,
  });
  if (!row) throw new AppError(422, "Price not configured for this combination.");
  return { product, row };
};

/** Looks up SUBSCRIPTION pricing by plan combination. */
export const resolveSubscriptionPrice = async ({
  subscriptionPlanId,
  serviceFrequencyId,
  subscriptionTermId,
  bathroomCountId,
  propertySizeId,
}) => {
  const plan = await SubscriptionPlan.findById(subscriptionPlanId);
  if (!plan) throw new AppError(404, "Subscription plan not found.");
  const filter = {
    subscriptionPlan: plan._id,
    serviceFrequency: serviceFrequencyId,
    subscriptionTerm: subscriptionTermId,
    isActive: true,
  };
  if (bathroomCountId) filter.bathroomCount = bathroomCountId;
  if (propertySizeId) filter.propertySize = propertySizeId;
  const row = await Pricing.findOne(filter);
  if (!row) throw new AppError(422, "Price not configured for this combination.");
  return { plan, row };
};

/** Builds a quote with tax for an order or subscription combination. */
export const quote = async (query) => {
  const address = await requireDoc(Address, query.addressId, "Address");
  if (query.productId) {
    const { row } = await resolveOrderPrice(query.productId);
    const quantity = Math.max(parseInt(query.quantity, 10) || 1, 1);
    const snapshot = await applyTax(row.price * quantity, address);
    return { kind: SERVICE_TYPE_CODE.ORDER, quantity, price: row.price, ...snapshot };
  }

  const { row } = await resolveSubscriptionPrice({
    subscriptionPlanId: query.subscriptionPlanId,
    serviceFrequencyId: query.serviceFrequencyId,
    subscriptionTermId: query.subscriptionTermId,
    bathroomCountId: query.bathroomCountId,
    propertySizeId: query.propertySizeId,
  });
  const snapshot = await applyTax(row.price, address);
  return { kind: SERVICE_TYPE_CODE.SUBSCRIPTION, price: row.price, ...snapshot };
};

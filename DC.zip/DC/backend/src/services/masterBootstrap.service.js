import {
  ActiveStatus,
  Area,
  Apartment,
  ServiceType,
  Measurement,
  Tax,
  Product,
  ProductVariant,
  Pricing,
  BathroomCount,
  PropertySize,
  ServiceDuration,
  SubscriptionPlan,
  TimeSlot,
  TechnicianRole,
  Skill,
  JobStatus,
  FollowUpStatus,
  CompletionResult,
  PaymentMethod,
  PaymentStatus,
  SchedulingRule,
  Technician,
} from "../models/index.js";
import { AppError } from "../utils/AppError.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";

export class MasterBootstrapService {
  /**
   * Aggregated bootstrap endpoint returning all master and dependent dropdown data.
   */
  static async getBootstrapData() {
    const [
      activeStatuses,
      areas,
      apartments,
      serviceTypes,
      measurements,
      taxes,
      productsRaw,
      productVariantsRaw,
      pricings,
      bathroomCounts,
      propertySizes,
      serviceDurations,
      subscriptionPlans,
      timeSlots,
      technicianRoles,
      skills,
      jobStatuses,
      followUpStatuses,
      completionResults,
      paymentMethods,
      paymentStatuses,
      schedulingRules,
      technicians,
    ] = await Promise.all([
      ActiveStatus.find({ isActive: true }).sort({ statusCode: 1 }).lean(),
      Area.find({ isActive: true }).sort({ name: 1 }).lean(),
      Apartment.find({ isActive: true }).populate("area").sort({ name: 1 }).lean(),
      ServiceType.find({ isActive: true }).sort({ defaultDurationMinutes: 1 }).lean(),
      Measurement.find({ isActive: true }).sort({ measurementCode: 1 }).lean(),
      Tax.find({ isActive: true }).sort({ ratePercent: 1 }).lean(),
      Product.find({ isActive: true })
        .populate("serviceType")
        .populate("cgstRate")
        .populate("sgstRate")
        .sort({ displayOrder: 1, name: 1 })
        .lean(),
      ProductVariant.find({ isActive: true })
        .populate("product")
        .populate("measurement")
        .sort({ sku: 1 })
        .lean(),
      Pricing.find({ isActive: true }).populate("product").populate("variant").lean(),
      BathroomCount.find({ isActive: true }).sort({ countValue: 1 }).lean(),
      PropertySize.find({ isActive: true }).sort({ displayOrder: 1 }).lean(),
      ServiceDuration.find({ isActive: true })
        .populate("serviceType")
        .populate("bathroomCount")
        .populate("propertySize")
        .lean(),
      SubscriptionPlan.find({ isActive: true }).populate("serviceType").sort({ displayOrder: 1 }).lean(),
      TimeSlot.find({ isActive: true }).sort({ displayOrder: 1, startTime: 1 }).lean(),
      TechnicianRole.find({ isActive: true }).sort({ defaultCapacity: -1 }).lean(),
      Skill.find({ isActive: true }).sort({ category: 1, skillName: 1 }).lean(),
      JobStatus.find({ isActive: true }).sort({ rank: 1 }).lean(),
      FollowUpStatus.find({ isActive: true }).sort({ statusCode: 1 }).lean(),
      CompletionResult.find({ isActive: true }).sort({ resultCode: 1 }).lean(),
      PaymentMethod.find({ isActive: true }).sort({ methodName: 1 }).lean(),
      PaymentStatus.find({ isActive: true }).sort({ statusCode: 1 }).lean(),
      SchedulingRule.find({ isActive: true }).sort({ ruleKey: 1 }).lean(),
      Technician.find({ isActive: true }).populate("role").populate("skills").sort({ name: 1 }).lean(),
    ]);

    // Build Dependent Relationships:
    // 1. Group Apartments by Area
    const apartmentsByArea = {};
    for (const apt of apartments) {
      const areaId = apt.area?._id?.toString() || "unassigned";
      if (!apartmentsByArea[areaId]) {
        apartmentsByArea[areaId] = [];
      }
      apartmentsByArea[areaId].push(apt);
    }

    // 2. Map Variants and Pricing to Products
    const pricingMap = new Map();
    pricings.forEach((p) => {
      const key = `${p.product?._id?.toString()}_${p.variant?._id?.toString() || "base"}`;
      pricingMap.set(key, p);
    });

    const products = productsRaw.map((prod) => {
      const prodId = prod._id.toString();
      const variants = productVariantsRaw
        .filter((v) => v.product?._id?.toString() === prodId)
        .map((v) => {
          const priceObj = pricingMap.get(`${prodId}_${v._id.toString()}`);
          return {
            ...v,
            pricing: priceObj || null,
          };
        });

      const basePricing = pricingMap.get(`${prodId}_base`);

      return {
        ...prod,
        basePricing: basePricing || null,
        variants,
      };
    });

    // 3. Subscription Plans grouped by Service Type
    const plansByServiceType = {};
    for (const plan of subscriptionPlans) {
      const stName = plan.serviceType?.typeName || "Other";
      if (!plansByServiceType[stName]) {
        plansByServiceType[stName] = [];
      }
      plansByServiceType[stName].push(plan);
    }

    return {
      activeStatuses,
      areas,
      apartments,
      apartmentsByArea,
      serviceTypes,
      measurements,
      taxes,
      products,
      productVariants: productVariantsRaw,
      bathroomCounts,
      propertySizes,
      serviceDurations,
      subscriptionPlans,
      plansByServiceType,
      timeSlots,
      technicianRoles,
      skills,
      jobStatuses,
      followUpStatuses,
      completionResults,
      paymentMethods,
      paymentStatuses,
      schedulingRules,
      technicians,
      propertyLabels: [
        { label: "Home", value: "Home" },
        { label: "Office", value: "Office" },
        { label: "Other", value: "Other" },
      ],
      travelBuffers: [
        { label: "30 minutes", value: 30 },
        { label: "45 minutes", value: 45 },
        { label: "60 minutes", value: 60 },
      ],
    };
  }

  /**
   * Retrieve records for an individual master collection by identifier.
   */
  static async getMasterByName(name) {
    const registry = {
      "active-statuses": ActiveStatus,
      areas: Area,
      apartments: Apartment,
      "service-types": ServiceType,
      measurements: Measurement,
      taxes: Tax,
      products: Product,
      "product-variants": ProductVariant,
      pricings: Pricing,
      "bathroom-counts": BathroomCount,
      "property-sizes": PropertySize,
      "service-durations": ServiceDuration,
      "subscription-plans": SubscriptionPlan,
      "time-slots": TimeSlot,
      "technician-roles": TechnicianRole,
      skills: Skill,
      "job-statuses": JobStatus,
      "follow-up-statuses": FollowUpStatus,
      "completion-results": CompletionResult,
      "payment-methods": PaymentMethod,
      "payment-statuses": PaymentStatus,
      "scheduling-rules": SchedulingRule,
    };

    const Model = registry[name.toLowerCase()];
    if (!Model) {
      throw new AppError(
        `Master resource '${name}' not found. Valid names are: ${Object.keys(registry).join(", ")}`,
        HTTP_STATUS.NOT_FOUND
      );
    }

    return Model.find({ isActive: true }).sort({ createdAt: -1 }).lean();
  }
}

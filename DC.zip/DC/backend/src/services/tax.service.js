/**
 * @file tax.service.js
 * @description Resolves location-based tax and computes CGST/SGST amounts.
 */
import { Tax } from "../models/Tax.model.js";
import { AppError } from "../utils/appError.js";

/** Rounds a number to two decimal places. */
export const round2 = (value) => Math.round((value + Number.EPSILON) * 100) / 100;

/** Finds an active tax row: city+state first, then state-only. */
export const resolveTax = async (address) => {
  const state = address?.state;
  const city = address?.city;
  if (!state) throw new AppError(422, "Address state is required to calculate tax.");

  const cityMatch = city
    ? await Tax.findOne({ isActive: true, state, city })
    : null;
  if (cityMatch) return cityMatch;

  const stateMatch = await Tax.findOne({
    isActive: true,
    state,
    $or: [{ city: null }, { city: "" }, { city: { $exists: false } }],
  });
  if (!stateMatch) throw new AppError(422, "Tax is not configured for this address location.");
  return stateMatch;
};

/** Applies CGST/SGST to a taxable base and returns a price snapshot. */
export const applyTax = async (baseAmount, address) => {
  const tax = await resolveTax(address);
  const unitPrice = round2(baseAmount);
  const cgstAmount = round2(unitPrice * tax.cgstRate / 100);
  const sgstAmount = round2(unitPrice * tax.sgstRate / 100);
  return {
    unitPrice,
    cgstRate: tax.cgstRate,
    sgstRate: tax.sgstRate,
    cgstAmount,
    sgstAmount,
    totalAmount: round2(unitPrice + cgstAmount + sgstAmount),
  };
};

/**
 * @file crud.service.js
 * @description Generic list/get/create/update/soft-delete with audit logging.
 */
import { AppError } from "../utils/appError.js";
import { parsePagination, buildMeta } from "../utils/pagination.js";
import { isValidObjectId } from "../utils/objectId.js";
import { AUDIT_ACTION, log, diffFields } from "./audit.service.js";

/** Reads actor and request metadata used by audit rows. */
export const actorMeta = (req) => ({
  actorId: req.user?._id,
  ip: req.ip,
  userAgent: req.get("user-agent"),
});

/** Drops actor and identity fields so they cannot be taken from the request body. */
export const sanitizePayload = (payload = {}) => {
  const next = { ...payload };
  delete next.createdBy;
  delete next.updatedBy;
  delete next._id;
  delete next.createdAt;
  delete next.updatedAt;
  return next;
};

/** Builds an isActive filter; omitted when the query asks for all. */
export const activeFilter = (query, { defaultActive = true } = {}) => {
  if (query.isActive === undefined || query.isActive === "") {
    return defaultActive ? { isActive: true } : {};
  }
  if (query.isActive === "all") return {};
  return { isActive: query.isActive === "true" || query.isActive === true };
};

/** Builds a case-insensitive OR search across named fields. */
export const searchFilter = (search, fields) => {
  if (!search || !fields?.length) return {};
  const regex = { $regex: String(search).trim(), $options: "i" };
  return { $or: fields.map((field) => ({ [field]: regex })) };
};

/** Lists documents with pagination, search, and optional populate. */
export const list = async (Model, req, { searchFields = ["name"], populate = "", extraFilter = {} } = {}) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = {
    ...activeFilter(req.query),
    ...searchFilter(req.query.search, searchFields),
    ...extraFilter,
  };
  const [items, total] = await Promise.all([
    Model.find(filter).populate(populate).sort({ createdAt: -1 }).skip(skip).limit(limit),
    Model.countDocuments(filter),
  ]);
  return { items, meta: buildMeta(total, page, limit) };
};

/** Loads one document by id or throws 404. */
export const getById = async (Model, id, populate = "") => {
  if (!isValidObjectId(id)) throw new AppError(400, "Invalid identifier.");
  const doc = await Model.findById(id).populate(populate);
  if (!doc) throw new AppError(404, `${Model.modelName} not found.`);
  return doc;
};

/** Creates a document, stamps actors, and writes a CREATE audit row. */
export const create = async (Model, payload, req) => {
  const { actorId, ip, userAgent } = actorMeta(req);
  const doc = await Model.create({ ...sanitizePayload(payload), createdBy: actorId, updatedBy: actorId });
  await log({
    entity: Model.modelName,
    entityId: doc._id,
    action: AUDIT_ACTION.CREATE,
    before: null,
    after: doc.toObject(),
    performedBy: actorId,
    ip,
    userAgent,
  });
  return doc;
};

/** Updates a document, stores only changed fields in audit. */
export const update = async (Model, id, payload, req) => {
  const doc = await getById(Model, id);
  const { actorId, ip, userAgent } = actorMeta(req);
  const before = doc.toObject();
  Object.assign(doc, sanitizePayload(payload), { updatedBy: actorId });
  await doc.save();
  const after = doc.toObject();
  const diff = diffFields(before, after);
  await log({
    entity: Model.modelName,
    entityId: doc._id,
    action: AUDIT_ACTION.UPDATE,
    before: diff.before,
    after: diff.after,
    performedBy: actorId,
    ip,
    userAgent,
  });
  return doc;
};

/** Soft-deletes a master by setting isActive to false. */
export const softDelete = async (Model, id, req) => {
  const doc = await getById(Model, id);
  const { actorId, ip, userAgent } = actorMeta(req);
  const before = { isActive: doc.isActive };
  doc.isActive = false;
  doc.updatedBy = actorId;
  await doc.save();
  await log({
    entity: Model.modelName,
    entityId: doc._id,
    action: AUDIT_ACTION.DELETE,
    before,
    after: { isActive: false },
    performedBy: actorId,
    ip,
    userAgent,
  });
  return doc;
};

/**
 * @file timeslot.service.js
 * @description Generates bookable slots from all active TimeSlot windows.
 */
import { TimeSlot } from "../models/TimeSlot.model.js";
import { Product } from "../models/Product.model.js";
import { SubscriptionPlan } from "../models/SubscriptionPlan.model.js";
import { Skill } from "../models/Skill.model.js";
import { AppError } from "../utils/appError.js";
import { VISIT_TYPE } from "../constants/index.js";
import { addMinutes, formatIstTime, isPastSlot, toDateTime } from "../utils/time.js";
import { resolveDurationMinutes } from "./duration.service.js";
import { findAvailableTechnicians } from "./availability.service.js";

/** Loads the skill linked to a product or subscription plan. */
export const resolveSkill = async ({ productId, subscriptionPlanId }) => {
  const skill = productId
    ? await Skill.findOne({ product: productId, isActive: true })
    : await Skill.findOne({ subscriptionPlan: subscriptionPlanId, isActive: true });
  if (!skill) throw new AppError(422, "Skill is not configured for this service.");
  return skill;
};

/** Splits each window into duration-sized slots separated by bufferMinutes. */
const generateWindowSlots = (dateStr, window, durationMinutes) => {
  const slots = [];
  let cursor = toDateTime(dateStr, window.startTime);
  const windowEnd = toDateTime(dateStr, window.endTime);
  while (true) {
    const start = cursor;
    const end = addMinutes(start, durationMinutes);
    if (end > windowEnd) break;
    slots.push({
      start,
      end,
      bufferMinutes: window.bufferMinutes || 0,
    });
    cursor = addMinutes(end, window.bufferMinutes || 0);
  }
  return slots;
};

/** Returns available slot descriptors for a date, duration, and skill. */
export const getAvailableSlots = async ({ date, durationMinutes, skillId }) => {
  const windows = await TimeSlot.find({ isActive: true }).sort({ startTime: 1 });
  const generated = windows.flatMap((window) => generateWindowSlots(date, window, durationMinutes));
  const results = [];
  for (const slot of generated) {
    const technicians = await findAvailableTechnicians({
      skillId,
      start: slot.start,
      end: slot.end,
      bufferMinutes: slot.bufferMinutes,
    });
    const past = isPastSlot(slot.start);
    const available = !past && technicians.length > 0;
    results.push({
      startTime: formatIstTime(slot.start),
      endTime: formatIstTime(slot.end),
      available,
      availableTechnicians: available
        ? technicians.map((tech) => ({ id: tech._id, name: tech.name }))
        : [],
    });
  }
  return results;
};

/** Resolves duration and skill from query params, then lists slots. */
export const listAvailableSlots = async (query) => {
  const date = query.date;
  if (!date) throw new AppError(400, "date is required.");
  if (query.visitType && !Object.values(VISIT_TYPE).includes(query.visitType)) {
    throw new AppError(400, "visitType must be SITE_VISIT or SERVICE.");
  }

  if (query.productId) {
    const product = await Product.findById(query.productId);
    if (!product) throw new AppError(404, "Product not found.");
    const visitType =
      query.visitType || (product.requiresSiteVisit ? VISIT_TYPE.SITE_VISIT : VISIT_TYPE.SERVICE);
    const durationMinutes = await resolveDurationMinutes({ visitType, product });
    const skill = await resolveSkill({ productId: product._id });
    return getAvailableSlots({ date, durationMinutes, skillId: skill._id });
  }

  if (!query.subscriptionPlanId) throw new AppError(400, "productId or subscriptionPlanId is required.");
  const plan = await SubscriptionPlan.findById(query.subscriptionPlanId);
  if (!plan) throw new AppError(404, "Subscription plan not found.");
  const visitType =
    query.visitType || (plan.requiresSiteVisit ? VISIT_TYPE.SITE_VISIT : VISIT_TYPE.SERVICE);
  const durationMinutes = await resolveDurationMinutes({
    visitType,
    subscriptionPlan: plan,
    bathroomCountId: query.bathroomCountId,
    propertySizeId: query.propertySizeId,
  });
  const skill = await resolveSkill({ subscriptionPlanId: plan._id });
  return getAvailableSlots({ date, durationMinutes, skillId: skill._id });
};

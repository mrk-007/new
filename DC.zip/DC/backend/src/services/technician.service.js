/**
 * @file technician.service.js
 * @description Technician availability and skill-matrix replacement.
 */
import { Technician } from "../models/Technician.model.js";
import { Skill } from "../models/Skill.model.js";
import { TechnicianSkill } from "../models/TechnicianSkill.model.js";
import { AppError } from "../utils/appError.js";
import { getById, update } from "./crud.service.js";
import { AUDIT_ACTION, log } from "./audit.service.js";
import { actorMeta } from "./crud.service.js";

/** Toggles technician on-duty availability. */
export const setAvailability = async (id, isAvailable, req) => {
  return update(Technician, id, { isAvailable }, req);
};

/** Returns every skill with this technician's isSkilled flag. */
export const getSkillMatrix = async (id) => {
  await getById(Technician, id);
  const skills = await Skill.find({ isActive: true }).sort({ name: 1 });
  const rows = await TechnicianSkill.find({ technician: id }).lean();
  const bySkill = new Map(rows.map((row) => [String(row.skill), row.isSkilled]));
  return skills.map((skill) => ({
    skill: skill._id,
    code: skill.code,
    name: skill.name,
    isSkilled: Boolean(bySkill.get(String(skill._id))),
  }));
};

/** Replaces the technician skill matrix from an array of { skill, isSkilled }. */
export const replaceSkillMatrix = async (id, skills, req) => {
  await getById(Technician, id);
  if (!Array.isArray(skills)) throw new AppError(400, "skills must be an array.");
  const { actorId, ip, userAgent } = actorMeta(req);
  for (const entry of skills) {
    if (!entry.skill) continue;
    await TechnicianSkill.findOneAndUpdate(
      { technician: id, skill: entry.skill },
      {
        technician: id,
        skill: entry.skill,
        isSkilled: Boolean(entry.isSkilled),
        updatedBy: actorId,
        createdBy: actorId,
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  }
  await log({
    entity: "TechnicianSkill",
    entityId: id,
    action: AUDIT_ACTION.UPDATE,
    before: null,
    after: { skills },
    performedBy: actorId,
    ip,
    userAgent,
  });
  return getSkillMatrix(id);
};

/**
 * @file duration.service.js
 * @description Resolves visit duration from Duration rows or site-visit minutes.
 */
import { Duration } from "../models/Duration.model.js";
import { AppError } from "../utils/appError.js";
import { PRICING_BASIS, VISIT_TYPE } from "../constants/index.js";

/** Loads minutes for a Duration target or throws 422. */
const minutesFor = async (filter, label) => {
  const row = await Duration.findOne({ ...filter, isActive: true });
  if (!row) throw new AppError(422, `Duration is not configured for this ${label}.`);
  return row.minutes;
};

/** Resolves duration minutes for an order or subscription visit. */
export const resolveDurationMinutes = async ({
  visitType,
  product,
  subscriptionPlan,
  bathroomCountId,
  propertySizeId,
}) => {
  if (visitType === VISIT_TYPE.SITE_VISIT) {
    return product?.siteVisitMinutes || subscriptionPlan?.siteVisitMinutes || 30;
  }
  if (product) return minutesFor({ product: product._id }, "product");
  if (subscriptionPlan?.pricingBasis === PRICING_BASIS.BATHROOM_COUNT) {
    return minutesFor({ bathroomCount: bathroomCountId }, "bathroom count");
  }
  if (subscriptionPlan?.pricingBasis === PRICING_BASIS.PROPERTY_SIZE) {
    return minutesFor({ propertySize: propertySizeId }, "property size");
  }
  throw new AppError(422, "Duration is not configured for this combination.");
};

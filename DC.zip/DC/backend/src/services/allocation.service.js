/**
 * @file allocation.service.js
 * @description Assigns technicians to visits with continuity and load balancing.
 */
import { TechnicianAllocation } from "../models/TechnicianAllocation.model.js";
import { Visit } from "../models/Visit.model.js";
import { TimeSlot } from "../models/TimeSlot.model.js";
import { Order } from "../models/Order.model.js";
import { Subscription } from "../models/Subscription.model.js";
import { AppError } from "../utils/appError.js";
import { ALLOCATION_STATUS, AUDIT_ACTION, VISIT_STATUS } from "../constants/index.js";
import { startOfDay, endOfDay } from "../utils/time.js";
import { findAvailableTechnicians, isTechnicianFree } from "./availability.service.js";
import { resolveSkill } from "./timeslot.service.js";
import { actorMeta } from "./crud.service.js";
import { log } from "./audit.service.js";

/** Reads the largest buffer among active windows. */
const maxBuffer = async () => {
  const windows = await TimeSlot.find({ isActive: true }).lean();
  return windows.reduce((max, row) => Math.max(max, row.bufferMinutes || 0), 0);
};

/** Counts ASSIGNED allocations for a technician on the visit's calendar day. */
const dayLoad = async (technicianId, when) => {
  const visits = await Visit.find({
    scheduledStart: { $gte: startOfDay(when), $lt: endOfDay(when) },
    status: { $ne: VISIT_STATUS.CANCELLED },
  }).select("_id");
  return TechnicianAllocation.countDocuments({
    technician: technicianId,
    status: ALLOCATION_STATUS.ASSIGNED,
    visit: { $in: visits.map((v) => v._id) },
  });
};

/** Picks continuity technician, else the candidate with the fewest jobs that day. */
const pickTechnician = async (candidates, visit) => {
  if (!candidates.length) return null;
  if (visit.subscription) {
    const previous = await TechnicianAllocation.findOne({
      subscription: visit.subscription,
      status: ALLOCATION_STATUS.ASSIGNED,
    }).sort({ allocatedAt: -1 });
    if (previous) {
      const match = candidates.find((tech) => String(tech._id) === String(previous.technician));
      if (match) return match;
    }
  }
  let best = candidates[0];
  let bestLoad = await dayLoad(best._id, visit.scheduledStart);
  for (const tech of candidates.slice(1)) {
    const load = await dayLoad(tech._id, visit.scheduledStart);
    if (load < bestLoad) {
      best = tech;
      bestLoad = load;
    }
  }
  return best;
};

/** Releases the current ASSIGNED allocation for a visit. */
export const releaseAllocation = async (visitId, req, reason = "Reassigned") => {
  const current = await TechnicianAllocation.findOne({
    visit: visitId,
    status: ALLOCATION_STATUS.ASSIGNED,
  });
  if (!current) return null;
  const { actorId, ip, userAgent } = actorMeta(req);
  current.status = ALLOCATION_STATUS.RELEASED;
  current.releaseReason = reason;
  current.updatedBy = actorId;
  await current.save();
  await log({
    entity: "TechnicianAllocation",
    entityId: current._id,
    action: AUDIT_ACTION.UPDATE,
    before: { status: ALLOCATION_STATUS.ASSIGNED },
    after: { status: ALLOCATION_STATUS.RELEASED, releaseReason: reason },
    performedBy: actorId,
    ip,
    userAgent,
  });
  return current;
};

/** Resolves the skill for a visit from its order product or subscription plan. */
const skillForVisit = async (visit) => {
  if (visit.order) {
    const order = visit.populated("order") ? visit.order : await Order.findById(visit.order);
    return resolveSkill({ productId: order.product });
  }
  const subscription = visit.populated("subscription")
    ? visit.subscription
    : await Subscription.findById(visit.subscription);
  return resolveSkill({ subscriptionPlanId: subscription.subscriptionPlan });
};

/** Allocates a visit; returns null when nobody is free. */
export const allocateVisit = async (visit, req, preferredTechnicianId) => {
  const skill = await skillForVisit(visit);
  const bufferMinutes = await maxBuffer();
  let candidates = await findAvailableTechnicians({
    skillId: skill._id,
    start: visit.scheduledStart,
    end: visit.scheduledEnd,
    bufferMinutes,
  });

  if (preferredTechnicianId) {
    candidates = candidates.filter((tech) => String(tech._id) === String(preferredTechnicianId));
    if (!candidates.length) throw new AppError(409, "Requested technician is not free for this slot.");
  }

  const chosen = await pickTechnician(candidates, visit);
  if (!chosen) return null;

  const stillFree = await isTechnicianFree(chosen._id, visit.scheduledStart, visit.scheduledEnd, bufferMinutes);
  if (!stillFree) return null;

  const { actorId, ip, userAgent } = actorMeta(req);
  const allocation = await TechnicianAllocation.create({
    technician: chosen._id,
    visit: visit._id,
    subscription: visit.subscription,
    order: visit.order,
    allocatedAt: new Date(),
    status: ALLOCATION_STATUS.ASSIGNED,
    createdBy: actorId,
    updatedBy: actorId,
  });
  await log({
    entity: "TechnicianAllocation",
    entityId: allocation._id,
    action: AUDIT_ACTION.CREATE,
    before: null,
    after: allocation.toObject(),
    performedBy: actorId,
    ip,
    userAgent,
  });
  return allocation;
};

/** Releases the previous assignment and creates a new one. */
export const reassignVisit = async (visit, req, technicianId) => {
  await releaseAllocation(visit._id, req, "Reassigned");
  const allocation = await allocateVisit(visit, req, technicianId);
  if (!allocation) throw new AppError(409, "No skilled technician is free for this visit.");
  return allocation;
};

/**
 * @file pagination.js
 * @description Parses list query parameters into skip/limit and meta.
 */

/** Reads page and limit from the request query with sane defaults. */
export const parsePagination = (query) => {
  const page = Math.max(parseInt(query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(query.limit, 10) || 20, 1), 100);
  const skip = (page - 1) * limit;
  return { page, limit, skip };
};

/** Builds list meta from total count and pagination. */
export const buildMeta = (total, page, limit) => ({
  page,
  limit,
  total,
  totalPages: Math.ceil(total / limit) || 0,
});

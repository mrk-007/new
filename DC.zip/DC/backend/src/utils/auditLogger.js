import { AuditLog } from "../models/index.js";
import { logger } from "../config/logger.js";

/**
 * Persist an audit log entry.
 *
 * @param {object} params
 * @param {string} params.action - e.g. "LOGIN", "LOGOUT", "CREATE", "UPDATE", "DELETE", "PASSWORD_CHANGE"
 * @param {string} params.module - e.g. "auth", "users", "roles"
 * @param {string|null} [params.recordId=null]
 * @param {object|null} [params.previousState=null]
 * @param {object|null} [params.newState=null]
 * @param {import("mongoose").Types.ObjectId|null} [params.performedBy=null]
 * @param {string} [params.performerUsername="system"]
 * @param {string} [params.ipAddress=""]
 * @param {string} [params.userAgent=""]
 */
export const recordAuditLog = async ({
  action,
  module,
  recordId = "",
  previousState = null,
  newState = null,
  performedBy = null,
  performerUsername = "system",
  ipAddress = "",
  userAgent = "",
}) => {
  try {
    await AuditLog.create({
      action,
      module,
      recordId: recordId ? String(recordId) : "",
      previousState,
      newState,
      performedBy,
      performerUsername,
      ipAddress,
      userAgent,
    });
  } catch (error) {
    logger.error(`Failed to record audit log: ${error.message}`);
  }
};

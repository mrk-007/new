/**
 * @file appError.js
 * @description Application error type carrying HTTP status and optional field errors.
 */

/** Operational HTTP error used by services and the central error handler. */
export class AppError extends Error {
  constructor(statusCode, message, errors) {
    super(message);
    this.statusCode = statusCode;
    this.errors = errors;
    this.name = "AppError";
  }
}

/**
 * @file objectId.js
 * @description ObjectId validation helpers.
 */
import mongoose from "mongoose";

const HEX_24 = /^[a-fA-F0-9]{24}$/;

/** Returns true when value is a 24-character hex ObjectId. */
export const isValidObjectId = (value) => typeof value === "string" && HEX_24.test(value);

/** Converts a valid id string into a Mongoose ObjectId. */
export const toObjectId = (value) => new mongoose.Types.ObjectId(value);

/**
 * Async handler utility to eliminate repetitive try-catch blocks in Express controllers.
 * @param {Function} fn - Async controller function (req, res, next) => Promise<any>
 * @returns {Function} Express middleware function
 */
export const asyncHandler = (fn) => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

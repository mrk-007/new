/**
 * @file asyncHandler.js
 * @description Wraps async Express handlers so rejections reach the error middleware.
 */

/** Forwards rejected promises from an async route handler to next(). */
export const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

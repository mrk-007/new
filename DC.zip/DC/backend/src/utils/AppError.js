import { HTTP_STATUS } from "../constants/httpStatusCodes.js";

/**
 * Custom Operational Application Error.
 */
export class AppError extends Error {
  /**
   * @param {string} message - Human-readable error message.
   * @param {number} [statusCode=500] - HTTP Status Code.
   * @param {Array<object>|object|null} [details=null] - Additional contextual error metadata or validation issues.
   */
  constructor(message, statusCode = HTTP_STATUS.INTERNAL_SERVER_ERROR, details = null) {
    super(message);
    this.name = "AppError";
    this.statusCode = statusCode;
    this.status = `${statusCode}`.startsWith("4") ? "fail" : "error";
    this.isOperational = true;
    this.details = details;

    Error.captureStackTrace(this, this.constructor);
  }

  static badRequest(message, details = null) {
    return new AppError(message, HTTP_STATUS.BAD_REQUEST, details);
  }

  static unauthorized(message = "Unauthorized access", details = null) {
    return new AppError(message, HTTP_STATUS.UNAUTHORIZED, details);
  }

  static forbidden(message = "Access forbidden", details = null) {
    return new AppError(message, HTTP_STATUS.FORBIDDEN, details);
  }

  static notFound(message = "Resource not found", details = null) {
    return new AppError(message, HTTP_STATUS.NOT_FOUND, details);
  }

  static conflict(message = "Resource state conflict", details = null) {
    return new AppError(message, HTTP_STATUS.CONFLICT, details);
  }

  static unprocessable(message = "Unprocessable entity", details = null) {
    return new AppError(message, HTTP_STATUS.UNPROCESSABLE_ENTITY, details);
  }

  static internal(message = "Internal server error", details = null) {
    return new AppError(message, HTTP_STATUS.INTERNAL_SERVER_ERROR, details);
  }
}

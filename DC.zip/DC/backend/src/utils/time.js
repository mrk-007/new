/**
 * @file time.js
 * @description Asia/Kolkata (+05:30) date helpers for scheduling.
 */
import { IST_OFFSET_MINUTES } from "../constants/index.js";

const OFFSET_MS = IST_OFFSET_MINUTES * 60 * 1000;

/** Pads a number to two digits. */
const pad = (n) => String(n).padStart(2, "0");

/** Reads calendar parts in IST from a Date instant. */
export const getIstParts = (date) => {
  const shifted = new Date(date.getTime() + OFFSET_MS);
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth() + 1,
    day: shifted.getUTCDate(),
    hour: shifted.getUTCHours(),
    minute: shifted.getUTCMinutes(),
  };
};

/** Formats YYYY-MM-DD in IST. */
export const formatIstDate = (date) => {
  const p = getIstParts(date);
  return `${p.year}-${pad(p.month)}-${pad(p.day)}`;
};

/** Formats HH:mm in IST. */
export const formatIstTime = (date) => {
  const p = getIstParts(date);
  return `${pad(p.hour)}:${pad(p.minute)}`;
};

/** Builds a Date from an IST calendar date string and HH:mm time. */
export const toDateTime = (dateStr, timeStr) => {
  const [year, month, day] = dateStr.split("-").map(Number);
  const [hour, minute] = timeStr.split(":").map(Number);
  return new Date(Date.UTC(year, month - 1, day, hour, minute) - OFFSET_MS);
};

/** Adds minutes to a Date instant. */
export const addMinutes = (date, minutes) => new Date(date.getTime() + minutes * 60 * 1000);

/** Returns true when two half-open ranges overlap. */
export const overlaps = (startA, endA, startB, endB) => startA < endB && startB < endA;

/** IST start of the calendar day containing the given instant. */
export const startOfDay = (date) => {
  const p = getIstParts(date);
  return toDateTime(`${p.year}-${pad(p.month)}-${pad(p.day)}`, "00:00");
};

/** IST end of the calendar day containing the given instant. */
export const endOfDay = (date) => {
  const p = getIstParts(date);
  return addMinutes(toDateTime(`${p.year}-${pad(p.month)}-${pad(p.day)}`, "23:59"), 1);
};

/** IST start of the calendar month containing the given instant. */
export const startOfMonth = (date) => {
  const p = getIstParts(date);
  return toDateTime(`${p.year}-${pad(p.month)}-01`, "00:00");
};

/** Number of days in a calendar month. */
const daysInMonth = (year, month) => new Date(Date.UTC(year, month, 0)).getUTCDate();

/** Adds calendar months in IST, clamping the day if needed. */
export const addMonths = (date, months) => {
  const p = getIstParts(date);
  const index = p.year * 12 + (p.month - 1) + months;
  const year = Math.floor(index / 12);
  const month = (index % 12) + 1;
  const day = Math.min(p.day, daysInMonth(year, month));
  return toDateTime(`${year}-${pad(month)}-${pad(day)}`, `${pad(p.hour)}:${pad(p.minute)}`);
};

/** Adds calendar days in IST. */
export const addDays = (date, days) => {
  const p = getIstParts(date);
  const utcNoon = Date.UTC(p.year, p.month - 1, p.day + days, 12, 0);
  const shifted = new Date(utcNoon);
  const year = shifted.getUTCFullYear();
  const month = shifted.getUTCMonth() + 1;
  const day = shifted.getUTCDate();
  return toDateTime(`${year}-${pad(month)}-${pad(day)}`, `${pad(p.hour)}:${pad(p.minute)}`);
};

/** True when an IST slot start is already in the past relative to now. */
export const isPastSlot = (start) => start.getTime() <= Date.now();

import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { RESPONSE_MESSAGES } from "../constants/responseMessages.js";

/**
 * Standard API Response Envelope Helpers.
 */

/**
 * Send standard success response envelope.
 * @param {import("express").Response} res
 * @param {object} options
 * @param {number} [options.statusCode=200]
 * @param {string} [options.message]
 * @param {any} [options.data=null]
 * @param {object|null} [options.meta=null]
 */
export const sendSuccess = (
  res,
  {
    statusCode = HTTP_STATUS.OK,
    message = RESPONSE_MESSAGES.SUCCESS,
    data = null,
    meta = null,
  } = {}
) => {
  return res.status(statusCode).json({
    success: true,
    message,
    data,
    meta,
  });
};

/**
 * Send HTTP 201 Created response envelope.
 * @param {import("express").Response} res
 * @param {object} options
 */
export const sendCreated = (
  res,
  { message = RESPONSE_MESSAGES.CREATED, data = null, meta = null } = {}
) => {
  return sendSuccess(res, {
    statusCode: HTTP_STATUS.CREATED,
    message,
    data,
    meta,
  });
};

/**
 * Send paginated collection response envelope.
 * @param {import("express").Response} res
 * @param {object} options
 * @param {Array<any>} options.data
 * @param {object} options.pagination - { page, limit, total, totalPages, hasNext, hasPrev }
 * @param {string} [options.message]
 */
export const sendPaginated = (
  res,
  {
    data = [],
    pagination = {},
    message = RESPONSE_MESSAGES.SUCCESS,
  } = {}
) => {
  return res.status(HTTP_STATUS.OK).json({
    success: true,
    message,
    data,
    meta: {
      pagination: {
        page: Number(pagination.page) || 1,
        limit: Number(pagination.limit) || data.length,
        total: Number(pagination.total) || data.length,
        totalPages: Number(pagination.totalPages) || 1,
        hasNext: Boolean(pagination.hasNext),
        hasPrev: Boolean(pagination.hasPrev),
      },
    },
  });
};

/**
 * Send error response envelope.
 * @param {import("express").Response} res
 * @param {object} options
 */
export const sendError = (
  res,
  {
    statusCode = HTTP_STATUS.INTERNAL_SERVER_ERROR,
    message = RESPONSE_MESSAGES.SERVER_ERROR,
    details = null,
  } = {}
) => {
  return res.status(statusCode).json({
    success: false,
    message,
    data: null,
    meta: details ? { details } : null,
  });
};

import { JobOrder } from "../models/index.js";

/**
 * Calculates human-readable duration between two HH:MM time strings.
 * @param {string} startTime - "09:00"
 * @param {string} endTime - "10:30"
 * @returns {string} "90 mins"
 */
export const calculateDurationText = (startTime, endTime) => {
  if (!startTime || !endTime) return "0 mins";
  const [ah, am] = startTime.split(":").map(Number);
  const [bh, bm] = endTime.split(":").map(Number);
  const diff = bh * 60 + bm - (ah * 60 + am);
  return `${diff} mins`;
};

/**
 * Calculates duration in integer minutes.
 * @param {string} startTime
 * @param {string} endTime
 * @returns {number}
 */
export const calculateDurationMinutes = (startTime, endTime) => {
  if (!startTime || !endTime) return 0;
  const [ah, am] = startTime.split(":").map(Number);
  const [bh, bm] = endTime.split(":").map(Number);
  return bh * 60 + bm - (ah * 60 + am);
};

/**
 * Computes end time "HH:MM" by adding minutes to start time with 24-hr rollover.
 * @param {string} startTime - "09:00"
 * @param {number} durationMinutes - 90
 * @returns {string} "10:30"
 */
export const endFrom = (startTime, durationMinutes) => {
  if (!startTime) return "00:00";
  const [h, m] = startTime.split(":").map(Number);
  const total = h * 60 + m + Number(durationMinutes || 0);
  const endH = Math.floor(total / 60) % 24;
  const endM = total % 60;
  return `${String(endH).padStart(2, "0")}:${String(endM).padStart(2, "0")}`;
};

/**
 * Validates if two time intervals on the same day overlap.
 * @param {string} a - Start A "09:00"
 * @param {string} b - End A "10:30"
 * @param {string} c - Start B "10:00"
 * @param {string} d - End B "12:00"
 * @returns {boolean} True if intervals intersect
 */
export const overlap = (a, b, c, d) => {
  return a < d && c < b;
};

/**
 * Determines whether a job arrival was late compared to scheduled start.
 * @param {string} arrivalTime - "09:18"
 * @param {string} scheduledStart - "09:00"
 * @returns {boolean}
 */
export const isArrivalLate = (arrivalTime, scheduledStart) => {
  if (!arrivalTime || !scheduledStart) return false;
  return arrivalTime > scheduledStart;
};

/**
 * Detects time overlap conflicts against active database job orders.
 * Validates both property overlap and technician overlap.
 *
 * @param {object} params
 * @param {string|null} [params.excludeJobId=null] - Job ID to exclude when updating
 * @param {string} params.date - "YYYY-MM-DD"
 * @param {string} params.startTime - "HH:MM"
 * @param {string} params.endTime - "HH:MM"
 * @param {string} params.propertyId - ObjectId string
 * @param {string} params.technicianId - ObjectId string
 * @returns {Promise<{ hasConflict: boolean, conflictingJob: object|null, reason: string|null }>}
 */
export const checkAssignmentConflict = async ({
  excludeJobId = null,
  date,
  startTime,
  endTime,
  propertyId,
  technicianId,
}) => {
  const query = {
    isActive: true,
    plannedDate: date,
    statusLabel: { $nin: ["Completed", "Closed"] },
    $or: [{ property: propertyId }, { technician: technicianId }],
  };

  if (excludeJobId) {
    query._id = { $ne: excludeJobId };
  }

  const candidateJobs = await JobOrder.find(query)
    .populate("technician", "name roleTitle")
    .populate("property", "propertyName areaName door")
    .lean();

  for (const job of candidateJobs) {
    if (overlap(startTime, endTime, job.startTime, job.endTime)) {
      const isProperty = String(job.property?._id) === String(propertyId);
      const isTech = String(job.technician?._id) === String(technicianId);

      let reason = "Time slot overlap detected";
      if (isProperty && isTech) {
        reason = `Both property (${job.property?.propertyName}) and technician (${job.technician?.name}) are already booked between ${job.startTime} and ${job.endTime}.`;
      } else if (isProperty) {
        reason = `Property (${job.property?.propertyName}) already has a service scheduled between ${job.startTime} and ${job.endTime} (Job: ${job.jobId}).`;
      } else if (isTech) {
        reason = `Technician (${job.technician?.name}) is already assigned to another job between ${job.startTime} and ${job.endTime} (Job: ${job.jobId}).`;
      }

      return {
        hasConflict: true,
        conflictingJob: job,
        reason,
      };
    }
  }

  return {
    hasConflict: false,
    conflictingJob: null,
    reason: null,
  };
};

/**
 * Financial calculation helper.
 * Computes GST breakdown (CGST 9%, SGST 9%) and total amounts with proper rounding.
 *
 * @param {object} params
 * @param {number} params.basePrice
 * @param {number} [params.discount=0]
 * @param {number} [params.cgstRate=9]
 * @param {number} [params.sgstRate=9]
 */
export const calculateFinancials = ({
  basePrice = 0,
  discount = 0,
  cgstRate = 9,
  sgstRate = 9,
}) => {
  const taxable = Math.max(0, Number(basePrice) - Number(discount));
  const cgstAmount = Math.round(((taxable * cgstRate) / 100) * 100) / 100;
  const sgstAmount = Math.round(((taxable * sgstRate) / 100) * 100) / 100;
  const total = Math.round((taxable + cgstAmount + sgstAmount) * 100) / 100;

  return {
    charges: Number(basePrice),
    discount: Number(discount),
    taxableAmount: taxable,
    cgstRate,
    cgstAmount,
    sgstRate,
    sgstAmount,
    total,
  };
};

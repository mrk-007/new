import { APP_CONSTANTS } from "../constants/appConstants.js";

/**
 * Parses request query parameters into Mongoose query components.
 *
 * @param {object} query - Express req.query object
 * @param {Array<string>} [searchFields=[]] - Fields to apply text search regex on
 * @returns {object} { filter, sort, skip, limit, page }
 */
export const parseQueryParams = (query = {}, searchFields = []) => {
  const page = Math.max(1, parseInt(query.page, 10) || APP_CONSTANTS.DEFAULT_PAGE);
  const requestedLimit = parseInt(query.limit, 10) || APP_CONSTANTS.DEFAULT_LIMIT;
  const limit = Math.min(Math.max(1, requestedLimit), APP_CONSTANTS.MAX_LIMIT);
  const skip = (page - 1) * limit;

  // Build Sort Object
  let sort = {};
  if (query.sort) {
    const fields = query.sort.split(",");
    fields.forEach((field) => {
      const trimmed = field.trim();
      if (trimmed.startsWith("-")) {
        sort[trimmed.substring(1)] = -1;
      } else {
        sort[trimmed] = 1;
      }
    });
  } else {
    sort = { [APP_CONSTANTS.DEFAULT_SORT_FIELD]: APP_CONSTANTS.DEFAULT_SORT_ORDER };
  }

  // Build Filters
  const excludedFields = ["page", "limit", "sort", "search", "fields", "_"];
  const filter = {};

  Object.keys(query).forEach((key) => {
    if (!excludedFields.includes(key)) {
      const value = query[key];
      if (value !== undefined && value !== null && value !== "" && value !== "all") {
        if (value === "true") {
          filter[key] = true;
        } else if (value === "false") {
          filter[key] = false;
        } else {
          filter[key] = value;
        }
      }
    }
  });

  // Always enforce soft-delete filter unless explicitly overridden
  if (filter.isActive === undefined) {
    filter.isActive = true;
  }

  // Build Search Filter
  if (query.search && query.search.trim() !== "" && searchFields.length > 0) {
    const searchRegex = new RegExp(query.search.trim(), "i");
    const searchConditions = searchFields.map((field) => ({
      [field]: searchRegex,
    }));

    if (filter.$or) {
      filter.$and = [{ $or: filter.$or }, { $or: searchConditions }];
      delete filter.$or;
    } else {
      filter.$or = searchConditions;
    }
  }

  return { filter, sort, skip, limit, page };
};

/**
 * Calculates pagination metadata.
 *
 * @param {number} total - Total matching documents
 * @param {number} page - Current page
 * @param {number} limit - Items per page
 * @returns {object} Pagination metadata
 */
export const calculatePagination = (total, page, limit) => {
  const totalPages = Math.ceil(total / limit) || 1;
  return {
    total,
    page,
    limit,
    totalPages,
    hasNext: page < totalPages,
    hasPrev: page > 1,
  };
};

/**
 * @file seed.js
 * @description Database seeding runner performing idempotent upserts across all entities in dependency order.
 */
import mongoose from "mongoose";
import { env } from "../config/env.js";
import {
  User,
  Master,
  Technician,
  Customer,
  Product,
  Order,
  Subscription,
  JobOrder,
} from "../models/index.js";
import {
  MASTERS,
  TECHNICIANS,
  CUSTOMERS,
  PRODUCTS,
  ORDERS,
  SUBSCRIPTIONS,
  JOB_ORDERS,
} from "./seedData.js";

/**
 * Calculates date relative to today using an integer day offset.
 */
const calculateRelativeDate = (offset = 0) => {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  d.setHours(9, 0, 0, 0);
  return d;
};

/**
 * Executes idempotent database seeding in strict dependency order.
 */
export const seed = async () => {
  if (!env.MONGODB_URI || !env.ADMIN_EMAIL || !env.ADMIN_PASSWORD || !env.JWT_SECRET) {
    throw new Error(
      "Missing required environment variables for seeding: MONGODB_URI, ADMIN_EMAIL, ADMIN_PASSWORD, JWT_SECRET."
    );
  }

  await mongoose.connect(env.MONGODB_URI);

  const shouldReset = process.argv.includes("--reset");
  if (shouldReset) {
    await Promise.all([
      User.deleteMany({}),
      Master.deleteMany({}),
      Technician.deleteMany({}),
      Customer.deleteMany({}),
      Product.deleteMany({}),
      Order.deleteMany({}),
      Subscription.deleteMany({}),
      JobOrder.deleteMany({}),
    ]);
  }

  // 1. Admin User
  let admin = await User.findOne({ email: env.ADMIN_EMAIL });
  if (!admin) {
    admin = await User.create({
      fullName: "Operations Admin",
      email: env.ADMIN_EMAIL,
      password: env.ADMIN_PASSWORD,
      role: "admin",
    });
  }

  // 2. Masters
  for (const item of MASTERS) {
    await Master.findOneAndUpdate(
      { type: item.type, code: item.code },
      { ...item, createdBy: admin._id },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  }

  // 3. Technicians
  for (const tech of TECHNICIANS) {
    await Technician.findOneAndUpdate({ mobile: tech.mobile }, tech, {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    });
  }

  // 4. Customers
  for (const cust of CUSTOMERS) {
    await Customer.findOneAndUpdate({ mobile: cust.mobile }, cust, {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    });
  }

  // 5. Products
  for (const prod of PRODUCTS) {
    await Product.findOneAndUpdate(
      { name: prod.name },
      { ...prod, createdBy: admin._id },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
  }

  // Lookup Maps
  const [allTechs, allCusts, allProds] = await Promise.all([
    Technician.find().lean(),
    Customer.find().lean(),
    Product.find().lean(),
  ]);

  const techByName = new Map(allTechs.map((t) => [t.name, t._id]));
  const custByMobile = new Map(allCusts.map((c) => [c.mobile, c._id]));
  const prodByName = new Map(allProds.map((p) => [p.name, p._id]));

  // 6. Orders
  for (const ord of ORDERS) {
    const customerId = custByMobile.get(ord.customerMobile);
    const productId = prodByName.get(ord.productName);
    const technicianId = techByName.get(ord.technicianName);

    if (customerId && productId) {
      await Order.findOneAndUpdate(
        { orderId: ord.orderId },
        {
          orderId: ord.orderId,
          customer: customerId,
          product: productId,
          technician: technicianId,
          serviceDate: calculateRelativeDate(ord.dayOffset),
          amount: ord.amount,
          paidAmount: ord.paidAmount,
        },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
    }
  }

  const allOrders = await Order.find().lean();
  const orderById = new Map(allOrders.map((o) => [o.orderId, o._id]));

  // 7. Subscriptions
  for (const sub of SUBSCRIPTIONS) {
    const customerId = custByMobile.get(sub.customerMobile);
    const productId = prodByName.get(sub.productName);

    if (customerId && productId) {
      await Subscription.findOneAndUpdate(
        { customer: customerId, product: productId },
        {
          customer: customerId,
          product: productId,
          status: sub.status,
          startDate: calculateRelativeDate(sub.dayOffset),
        },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
    }
  }

  // 8. Job Orders
  for (const job of JOB_ORDERS) {
    const orderDocId = orderById.get(job.orderId);
    const customerId = custByMobile.get(job.customerMobile);
    const technicianId = techByName.get(job.technicianName);

    if (orderDocId && customerId && technicianId) {
      await JobOrder.findOneAndUpdate(
        { order: orderDocId, work: job.work, technician: technicianId },
        {
          order: orderDocId,
          customer: customerId,
          work: job.work,
          technician: technicianId,
          serviceDate: calculateRelativeDate(job.dayOffset),
          arrivalStatus: job.arrivalStatus,
          arrivalDelayMinutes: job.arrivalDelayMinutes,
          workStatus: job.workStatus,
          followUpStatus: job.followUpStatus,
        },
        { upsert: true, new: true, setDefaultsOnInsert: true }
      );
    }
  }

  await mongoose.disconnect();
};

if (process.argv[1]?.endsWith("seed.js")) {
  seed()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Seeding failed:", err.message);
      process.exit(1);
    });
}

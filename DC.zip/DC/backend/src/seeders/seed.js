/**
 * @file seed.js
 * @description Idempotent seed script; --reset clears collections first.
 */
import { connectDB, disconnectDB } from "../config/db.js";
import { env } from "../config/env.js";
import {
  Role,
  User,
  ServiceType,
  Product,
  SubscriptionPlan,
  SubscriptionTerm,
  ServiceFrequency,
  BathroomCount,
  PropertySize,
  Duration,
  Skill,
  TimeSlot,
  Tax,
  Technician,
  TechnicianSkill,
} from "../models/index.js";
import * as data from "./seedData.js";

const RESET = process.argv.includes("--reset");

const SEEDED_MODELS = [
  TechnicianSkill,
  Technician,
  Duration,
  Skill,
  TimeSlot,
  Tax,
  Product,
  SubscriptionPlan,
  SubscriptionTerm,
  ServiceFrequency,
  BathroomCount,
  PropertySize,
  ServiceType,
  User,
  Role,
];

/** Upserts a document by filter and stamps the admin actor. */
const upsert = async (Model, filter, payload, actorId) => {
  const existing = await Model.findOne(filter);
  if (existing) {
    Object.assign(existing, payload, { updatedBy: actorId, isActive: true });
    await existing.save();
    return existing;
  }
  return Model.create({ ...payload, ...filter, createdBy: actorId, updatedBy: actorId });
};

/** Finds or creates the admin user from environment credentials. */
const ensureAdmin = async () => {
  let adminRole = await Role.findOne({ roleName: "Admin" });
  if (!adminRole) {
    adminRole = await Role.create({
      roleName: "Admin",
      isRead: true,
      isWrite: true,
      isDelete: true,
      isActive: true,
    });
  }

  let admin = await User.findOne({ email: env.ADMIN_EMAIL.toLowerCase() }).select("+password");
  if (!admin) {
    admin = await User.create({
      email: env.ADMIN_EMAIL.toLowerCase(),
      password: env.ADMIN_PASSWORD,
      role: adminRole._id,
      isActive: true,
    });
  } else {
    admin.role = adminRole._id;
    admin.isActive = true;
    await admin.save();
  }

  if (!adminRole.createdBy) {
    adminRole.createdBy = admin._id;
    adminRole.updatedBy = admin._id;
    await adminRole.save();
  }
  return admin;
};

/** Seeds all reference data using the admin as createdBy. */
const seed = async () => {
  await connectDB();
  if (RESET) {
    for (const Model of SEEDED_MODELS) {
      await Model.deleteMany({});
    }
  }

  const admin = await ensureAdmin();
  const actorId = admin._id;

  const roleDocs = {};
  for (const role of data.roles) {
    roleDocs[role.roleName] = await upsert(Role, { roleName: role.roleName }, role, actorId);
  }

  const serviceTypeDocs = {};
  for (const item of data.serviceTypes) {
    serviceTypeDocs[item.code] = await upsert(ServiceType, { code: item.code }, item, actorId);
  }

  const productDocs = {};
  for (const item of data.products) {
    productDocs[item.code] = await upsert(
      Product,
      { code: item.code },
      { ...item, serviceType: serviceTypeDocs.ORDER._id },
      actorId
    );
  }

  const planDocs = {};
  for (const item of data.subscriptionPlans) {
    planDocs[item.code] = await upsert(
      SubscriptionPlan,
      { code: item.code },
      { ...item, serviceType: serviceTypeDocs.SUBSCRIPTION._id },
      actorId
    );
  }

  for (const item of data.subscriptionTerms) {
    await upsert(SubscriptionTerm, { months: item.months }, item, actorId);
  }
  for (const item of data.serviceFrequencies) {
    await upsert(ServiceFrequency, { intervalDays: item.intervalDays }, item, actorId);
  }

  const bathroomDocs = {};
  for (const item of data.bathroomCounts) {
    bathroomDocs[item.count] = await upsert(BathroomCount, { count: item.count }, item, actorId);
  }
  const propertyDocs = {};
  for (const item of data.propertySizes) {
    propertyDocs[item.bedrooms] = await upsert(PropertySize, { bedrooms: item.bedrooms }, item, actorId);
  }

  for (const [count, minutes] of Object.entries(data.durationMinutes.bathrooms)) {
    await upsert(Duration, { bathroomCount: bathroomDocs[count]._id }, { minutes: Number(minutes) }, actorId);
  }
  for (const [bedrooms, minutes] of Object.entries(data.durationMinutes.bedrooms)) {
    await upsert(Duration, { propertySize: propertyDocs[bedrooms]._id }, { minutes: Number(minutes) }, actorId);
  }
  for (const [code, minutes] of Object.entries(data.durationMinutes.products)) {
    await upsert(Duration, { product: productDocs[code]._id }, { minutes: Number(minutes) }, actorId);
  }

  const skillDocs = {};
  for (const item of data.skills) {
    const payload = {
      code: item.code,
      name: item.name,
      product: item.productCode ? productDocs[item.productCode]._id : null,
      subscriptionPlan: item.planCode ? planDocs[item.planCode]._id : null,
    };
    skillDocs[item.code] = await upsert(Skill, { code: item.code }, payload, actorId);
  }

  for (const item of data.timeSlots) {
    await upsert(TimeSlot, { name: item.name }, item, actorId);
  }
  for (const item of data.taxes) {
    const filter = { state: item.state, city: item.city || null };
    await upsert(Tax, filter, item, actorId);
  }

  const technicianRole = roleDocs.Technician;
  for (const item of data.technicians) {
    const existingTechUser = await User.findOne({ email: item.email });
    const techUser = existingTechUser
      ? await upsert(
          User,
          { email: item.email },
          { email: item.email, role: technicianRole._id, isActive: true },
          actorId
        )
      : await upsert(
          User,
          { email: item.email },
          { email: item.email, password: env.ADMIN_PASSWORD, role: technicianRole._id, isActive: true },
          actorId
        );
    const technician = await upsert(
      Technician,
      { mobile: item.mobile },
      {
        name: item.name,
        mobile: item.mobile,
        email: item.email,
        user: techUser._id,
        isAvailable: true,
        isActive: true,
      },
      actorId
    );
    for (const skillCode of Object.keys(skillDocs)) {
      await upsert(
        TechnicianSkill,
        { technician: technician._id, skill: skillDocs[skillCode]._id },
        { isSkilled: item.skills.includes(skillCode) },
        actorId
      );
    }
  }

  process.stdout.write("Seed completed.\n");
  await disconnectDB();
};

seed().catch(async (err) => {
  process.stderr.write(`${err.message}\n`);
  await disconnectDB();
  process.exit(1);
});

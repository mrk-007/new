import mongoose from "mongoose";
import { connectDB, disconnectDB } from "../config/db.js";
import { logger } from "../config/logger.js";
import { seedMasterData } from "./masterData.seed.js";
import { seedOperationalData } from "./operationalData.seed.js";

const runSeeder = async () => {
  const isReset = process.argv.includes("--reset");

  try {
    logger.info(`Starting database seeder${isReset ? " with RESET flag" : ""}...`);
    await connectDB();

    if (isReset) {
      logger.warn("RESET flag detected. Dropping all collections...");
      const collections = await mongoose.connection.db.collections();
      for (const col of collections) {
        await col.drop();
        logger.info(`Dropped collection: ${col.collectionName}`);
      }
      logger.info("Database reset complete. Proceeding to fresh seed.");
    }

    const masterDocs = await seedMasterData();
    await seedOperationalData(masterDocs);

    logger.info("Database seeding completed successfully!");
    await disconnectDB();
    process.exit(0);
  } catch (error) {
    logger.error(`Seeding failed with error: ${error.message}`, { stack: error.stack });
    await disconnectDB();
    process.exit(1);
  }
};

runSeeder();

/**
 * @file seedData.js
 * @description Static seed payloads only; no database calls.
 */

export const roles = [
  { roleName: "Admin", isRead: true, isWrite: true, isDelete: true },
  { roleName: "Manager", isRead: true, isWrite: true, isDelete: false },
  { roleName: "Technician", isRead: true, isWrite: false, isDelete: false },
];

export const serviceTypes = [
  { code: "ORDER", name: "One-Time Product Order" },
  { code: "SUBSCRIPTION", name: "Recurring Subscription" },
];

export const products = [
  {
    code: "HANGER",
    name: "Hanger",
    requiresSiteVisit: false,
    siteVisitMinutes: 30,
    description: "Hanger installation",
  },
  {
    code: "SHOE_RACK",
    name: "Shoe Rack",
    requiresSiteVisit: false,
    siteVisitMinutes: 30,
    description: "Shoe rack installation",
  },
  {
    code: "MOSQUITO_NET",
    name: "Mosquito Net",
    requiresSiteVisit: true,
    siteVisitMinutes: 30,
    description: "Custom mosquito net after site measurement",
  },
];

export const subscriptionPlans = [
  {
    code: "DEEP_CLEANING",
    name: "Deep Cleaning",
    pricingBasis: "PROPERTY_SIZE",
    requiresSiteVisit: true,
    siteVisitMinutes: 30,
  },
  {
    code: "BATHROOM_CLEANING",
    name: "Bathroom Cleaning",
    pricingBasis: "BATHROOM_COUNT",
    requiresSiteVisit: false,
    siteVisitMinutes: 30,
  },
];

export const subscriptionTerms = [
  { name: "2 Months", months: 2 },
  { name: "3 Months", months: 3 },
  { name: "6 Months", months: 6 },
  { name: "12 Months", months: 12 },
];

export const serviceFrequencies = [
  { name: "Once a week", intervalDays: 7 },
  { name: "Once in two weeks", intervalDays: 14 },
];

export const bathroomCounts = [
  { name: "1 Bathroom", count: 1 },
  { name: "2 Bathrooms", count: 2 },
  { name: "3 Bathrooms", count: 3 },
  { name: "4 Bathrooms", count: 4 },
];

export const propertySizes = [
  { name: "1 BHK", bedrooms: 1 },
  { name: "2 BHK", bedrooms: 2 },
  { name: "3 BHK", bedrooms: 3 },
];

export const durationMinutes = {
  bathrooms: { 1: 30, 2: 45, 3: 60, 4: 75 },
  bedrooms: { 1: 120, 2: 150, 3: 180 },
  products: { HANGER: 60, SHOE_RACK: 60, MOSQUITO_NET: 90 },
};

export const skills = [
  { code: "HANGER_INSTALL", name: "Hanger Installation", productCode: "HANGER" },
  { code: "SHOE_RACK_INSTALL", name: "Shoe Rack Installation", productCode: "SHOE_RACK" },
  { code: "MOSQUITO_NET_INSTALL", name: "Mosquito Net Installation", productCode: "MOSQUITO_NET" },
  { code: "DEEP_CLEANING", name: "Deep Cleaning", planCode: "DEEP_CLEANING" },
  { code: "BATHROOM_CLEANING", name: "Bathroom Cleaning", planCode: "BATHROOM_CLEANING" },
];

export const timeSlots = [
  { name: "Morning Window", startTime: "06:00", endTime: "12:00", bufferMinutes: 15 },
];

export const taxes = [
  { state: "Karnataka", city: "Bengaluru", cgstRate: 9, sgstRate: 9 },
  { state: "Tamil Nadu", city: null, cgstRate: 9, sgstRate: 9 },
];

export const technicians = [
  {
    name: "Ravi Kumar",
    mobile: "9876500001",
    email: "ravi.tech@example.com",
    skills: ["HANGER_INSTALL", "SHOE_RACK_INSTALL", "MOSQUITO_NET_INSTALL", "DEEP_CLEANING", "BATHROOM_CLEANING"],
  },
  {
    name: "Anita Sharma",
    mobile: "9876500002",
    email: "anita.tech@example.com",
    skills: ["DEEP_CLEANING", "BATHROOM_CLEANING"],
  },
  {
    name: "Suresh Nair",
    mobile: "9876500003",
    email: "suresh.tech@example.com",
    skills: ["HANGER_INSTALL", "SHOE_RACK_INSTALL", "MOSQUITO_NET_INSTALL"],
  },
];

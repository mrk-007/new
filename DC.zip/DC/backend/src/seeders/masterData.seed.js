import {
  Role,
  Module,
  RolePermission,
  ActiveStatus,
  Area,
  Apartment,
  ServiceType,
  Measurement,
  Tax,
  Product,
  ProductVariant,
  Pricing,
  BathroomCount,
  PropertySize,
  ServiceDuration,
  SubscriptionPlan,
  TimeSlot,
  TechnicianRole,
  Skill,
  JobStatus,
  FollowUpStatus,
  CompletionResult,
  PaymentMethod,
  PaymentStatus,
  SchedulingRule,
  Counter,
} from "../models/index.js";
import { logger } from "../config/logger.js";

export const seedMasterData = async () => {
  logger.info("Seeding master data...");

  // 1. Counters
  const counters = [
    { entityKey: "CUSTOMER", prefix: "CUS", seq: 3, padding: 6 },
    { entityKey: "PROPERTY", prefix: "PROP", seq: 3, padding: 3 },
    { entityKey: "ORDER", prefix: "ORD-2026", seq: 1103, padding: 4 },
    { entityKey: "SUBSCRIPTION", prefix: "SUB", seq: 302, padding: 6 },
    { entityKey: "JOB_ORDER", prefix: "JOB", seq: 2503, padding: 4 },
    { entityKey: "INVOICE", prefix: "INV", seq: 1103, padding: 6 },
    { entityKey: "PAYMENT", prefix: "PAY", seq: 1103, padding: 6 },
    { entityKey: "TECHNICIAN", prefix: "TECH", seq: 2, padding: 3 },
  ];
  for (const c of counters) {
    await Counter.findOneAndUpdate({ entityKey: c.entityKey }, { $set: c }, { upsert: true, new: true });
  }

  // 2. Active Statuses
  const statuses = [
    { statusCode: "ACTIVE", statusLabel: "Active", badgeColorHex: "#148457", badgeClass: "green" },
    { statusCode: "INACTIVE", statusLabel: "Inactive", badgeColorHex: "#64748b", badgeClass: "muted" },
    { statusCode: "SUSPENDED", statusLabel: "Suspended", badgeColorHex: "#c62828", badgeClass: "red" },
  ];
  for (const s of statuses) {
    await ActiveStatus.findOneAndUpdate({ statusCode: s.statusCode }, { $set: s }, { upsert: true, new: true });
  }

  // 3. Roles
  const roles = [
    { roleKey: "super_admin", roleName: "Super Admin", description: "Full operational and administrative control", isSystemRole: true },
    { roleKey: "telecaller", roleName: "Telecaller", description: "Customer registration, order booking, scheduling, and follow-up", isSystemRole: true },
    { roleKey: "technician", roleName: "Technician", description: "Mobile-optimized job execution and status updates", isSystemRole: true },
  ];
  const roleDocs = {};
  for (const r of roles) {
    roleDocs[r.roleKey] = await Role.findOneAndUpdate({ roleKey: r.roleKey }, { $set: r }, { upsert: true, new: true });
  }

  // 4. Modules
  const modules = [
    { moduleKey: "dashboard", moduleName: "Operations Dashboard", routePath: "/dashboard", category: "Operations", displayOrder: 1, icon: "⌂" },
    { moduleKey: "customers", moduleName: "Customers Directory", routePath: "/customers", category: "Operations", displayOrder: 2, icon: "◎" },
    { moduleKey: "orders", moduleName: "Customer Orders", routePath: "/orders", category: "Operations", displayOrder: 3, icon: "▣" },
    { moduleKey: "subscriptions", moduleName: "Cleaning Subscriptions", routePath: "/subscriptions", category: "Operations", displayOrder: 4, icon: "↻" },
    { moduleKey: "jobs", moduleName: "Job Orders", routePath: "/jobs", category: "Operations", displayOrder: 5, icon: "▤" },
    { moduleKey: "schedule", moduleName: "Schedule & Calendar", routePath: "/schedule", category: "Operations", displayOrder: 6, icon: "▦" },
    { moduleKey: "technicians", moduleName: "Technicians & Skills", routePath: "/technicians", category: "Operations", displayOrder: 7, icon: "♟" },
    { moduleKey: "catalog", moduleName: "Products & Services", routePath: "/catalog", category: "Operations", displayOrder: 8, icon: "◫" },
    { moduleKey: "invoices", moduleName: "Invoices & Payments", routePath: "/invoices", category: "Finance", displayOrder: 9, icon: "₹" },
    { moduleKey: "configuration", moduleName: "Configuration", routePath: "/configuration", category: "Administration", displayOrder: 10, icon: "⚙" },
    { moduleKey: "tech_jobs", moduleName: "Technician Jobs", routePath: "/tech/jobs", category: "Technician", displayOrder: 11, icon: "⌂" },
    { moduleKey: "tech_calendar", moduleName: "Technician Calendar", routePath: "/tech/calendar", category: "Technician", displayOrder: 12, icon: "▦" },
    { moduleKey: "tech_history", moduleName: "Technician History", routePath: "/tech/history", category: "Technician", displayOrder: 13, icon: "✓" },
    { moduleKey: "tech_profile", moduleName: "Technician Profile", routePath: "/tech/profile", category: "Technician", displayOrder: 14, icon: "♟" },
  ];
  const moduleDocs = {};
  for (const m of modules) {
    moduleDocs[m.moduleKey] = await Module.findOneAndUpdate({ moduleKey: m.moduleKey }, { $set: m }, { upsert: true, new: true });
  }

  // 5. Role Permissions Matrix
  const permissionsConfig = [
    // Super Admin: All modules Read/Write/Delete
    ...Object.keys(moduleDocs).map((modKey) => ({
      role: roleDocs.super_admin._id,
      module: moduleDocs[modKey]._id,
      isRead: true,
      isWrite: true,
      isDelete: true,
    })),
    // Telecaller: Operations & Finance (restricted from configuration)
    { role: roleDocs.telecaller._id, module: moduleDocs.dashboard._id, isRead: true, isWrite: false, isDelete: false },
    { role: roleDocs.telecaller._id, module: moduleDocs.customers._id, isRead: true, isWrite: true, isDelete: false },
    { role: roleDocs.telecaller._id, module: moduleDocs.orders._id, isRead: true, isWrite: true, isDelete: false },
    { role: roleDocs.telecaller._id, module: moduleDocs.subscriptions._id, isRead: true, isWrite: true, isDelete: false },
    { role: roleDocs.telecaller._id, module: moduleDocs.jobs._id, isRead: true, isWrite: true, isDelete: false },
    { role: roleDocs.telecaller._id, module: moduleDocs.schedule._id, isRead: true, isWrite: true, isDelete: false },
    { role: roleDocs.telecaller._id, module: moduleDocs.technicians._id, isRead: true, isWrite: false, isDelete: false },
    { role: roleDocs.telecaller._id, module: moduleDocs.catalog._id, isRead: true, isWrite: false, isDelete: false },
    { role: roleDocs.telecaller._id, module: moduleDocs.invoices._id, isRead: true, isWrite: true, isDelete: false },
    // Technician: Only tech workspace modules
    { role: roleDocs.technician._id, module: moduleDocs.tech_jobs._id, isRead: true, isWrite: true, isDelete: false },
    { role: roleDocs.technician._id, module: moduleDocs.tech_calendar._id, isRead: true, isWrite: false, isDelete: false },
    { role: roleDocs.technician._id, module: moduleDocs.tech_history._id, isRead: true, isWrite: false, isDelete: false },
    { role: roleDocs.technician._id, module: moduleDocs.tech_profile._id, isRead: true, isWrite: false, isDelete: false },
  ];
  for (const p of permissionsConfig) {
    await RolePermission.findOneAndUpdate(
      { role: p.role, module: p.module },
      { $set: p },
      { upsert: true, new: true }
    );
  }

  // 6. Areas
  const areas = [
    { areaCode: "ANR", name: "Anna Nagar", city: "Chennai", state: "Tamil Nadu", pincode: "600040" },
    { areaCode: "VEL", name: "Velachery", city: "Chennai", state: "Tamil Nadu", pincode: "600042" },
    { areaCode: "TEY", name: "Teynampet", city: "Chennai", state: "Tamil Nadu", pincode: "600018" },
    { areaCode: "SPG", name: "SPGC Nagar", city: "Vellakulam", state: "Tamil Nadu", pincode: "625701" },
  ];
  const areaDocs = {};
  for (const a of areas) {
    areaDocs[a.name] = await Area.findOneAndUpdate({ name: a.name }, { $set: a }, { upsert: true, new: true });
  }

  // 7. Apartments
  const apartments = [
    { name: "Lake View Apartments", area: areaDocs["Anna Nagar"]._id, address: "Lake Road, Chennai - 600040" },
    { name: "Green Court", area: areaDocs["Velachery"]._id, address: "Main Road, Chennai" },
    { name: "Skyline Towers", area: areaDocs["Teynampet"]._id, address: "Anna Salai, Chennai" },
    { name: "MS Residency", area: areaDocs["SPGC Nagar"]._id, address: "South Side, Vellakulam" },
  ];
  const aptDocs = {};
  for (const apt of apartments) {
    aptDocs[apt.name] = await Apartment.findOneAndUpdate({ name: apt.name }, { $set: apt }, { upsert: true, new: true });
  }

  // 8. Service Types
  const serviceTypes = [
    { typeCode: "INSTALLATION", typeName: "Product Installation", category: "Product Installation", defaultDurationMinutes: 120, isRecurringSubscription: false, calendarColorHex: "#5b47dc" },
    { typeCode: "BATHROOM_CLEANING", typeName: "Bathroom Cleaning", category: "Subscription", defaultDurationMinutes: 90, isRecurringSubscription: true, calendarColorHex: "#148457" },
    { typeCode: "DEEP_CLEANING", typeName: "Deep Cleaning", category: "Subscription", defaultDurationMinutes: 240, isRecurringSubscription: true, calendarColorHex: "#2563eb" },
  ];
  const stDocs = {};
  for (const st of serviceTypes) {
    stDocs[st.typeName] = await ServiceType.findOneAndUpdate({ typeName: st.typeName }, { $set: st }, { upsert: true, new: true });
  }

  // 9. Taxes (CGST 9%, SGST 9%)
  const taxes = [
    { taxCode: "CGST_9", taxName: "CGST @ 9%", ratePercent: 9, taxType: "GST" },
    { taxCode: "SGST_9", taxName: "SGST @ 9%", ratePercent: 9, taxType: "GST" },
  ];
  const taxDocs = {};
  for (const t of taxes) {
    taxDocs[t.taxCode] = await Tax.findOneAndUpdate({ taxCode: t.taxCode }, { $set: t }, { upsert: true, new: true });
  }

  // 10. Measurements
  const measurements = [
    { measurementCode: "4_SHELF_WALL", label: "4 Shelf · Wall Mounted", description: "4-tier shoe cabinet", unit: "Unit" },
    { measurementCode: "5_PIPE_5FT", label: "5 Pipe · 5 Feet", description: "Pull and dry ceiling system", unit: "Unit" },
    { measurementCode: "6_PIPE_6FT", label: "6 Pipe · 6 Feet", description: "Heavy duty cloth drying rack", unit: "Unit" },
    { measurementCode: "STANDARD_SLIDING", label: "Standard 3 Track Sliding", description: "Mosquito mesh", unit: "SqFt" },
  ];
  const measurementDocs = {};
  for (const m of measurements) {
    measurementDocs[m.measurementCode] = await Measurement.findOneAndUpdate({ measurementCode: m.measurementCode }, { $set: m }, { upsert: true, new: true });
  }

  // 11. Products & Services (Catalog)
  const catalog = [
    { productCode: "PROD_HANGER", name: "Pull & Dry Cloth Drying Hangers", serviceType: stDocs["Product Installation"]._id, group: "Product Installation", icon: "🪟", description: "Customer order with invoice, delivery, installation and job closure.", basePrice: 4500, defaultDurationMinutes: 90, badgeColor: "purple" },
    { productCode: "PROD_SHOE_RACK", name: "Wall Mounted Shoe Racks", serviceType: stDocs["Product Installation"]._id, group: "Product Installation", icon: "👞", description: "Customer order with invoice, delivery, installation and job closure.", basePrice: 7500, defaultDurationMinutes: 120, badgeColor: "purple" },
    { productCode: "PROD_MOSQUITO_NET", name: "Sliding Mosquito Nets", serviceType: stDocs["Product Installation"]._id, group: "Product Installation", icon: "🦟", description: "Customer order with invoice, delivery, installation and job closure.", basePrice: 3800, defaultDurationMinutes: 60, badgeColor: "purple" },
    { productCode: "PROD_BIRD_NET", name: "Anti-Bird Net", serviceType: stDocs["Product Installation"]._id, group: "Product Installation", icon: "🕊️", description: "Customer order with invoice, delivery, installation and job closure.", basePrice: 2500, defaultDurationMinutes: 90, badgeColor: "purple" },
    { productCode: "PROD_GRILL", name: "Invisible Grills", serviceType: stDocs["Product Installation"]._id, group: "Product Installation", icon: "🏙️", description: "Customer order with invoice, delivery, installation and job closure.", basePrice: 12000, defaultDurationMinutes: 180, badgeColor: "purple" },
    { productCode: "PROD_WATER_PURIFIER", name: "Aquaguard Water Purifier", serviceType: stDocs["Product Installation"]._id, group: "Product Installation", icon: "💧", description: "Customer order with invoice, delivery, installation and job closure.", basePrice: 14500, defaultDurationMinutes: 90, badgeColor: "purple" },
    { productCode: "SERV_BATHROOM_CLEANING", name: "Bathroom Cleaning Subscription", serviceType: stDocs["Bathroom Cleaning"]._id, group: "Subscription", icon: "🚿", description: "Recurring visit schedule with technician assignment and service tracking.", basePrice: 5500, defaultDurationMinutes: 90, badgeColor: "green" },
    { productCode: "SERV_DEEP_CLEANING", name: "Home / Office Deep Cleaning Subscription", serviceType: stDocs["Deep Cleaning"]._id, group: "Subscription", icon: "🧹", description: "Recurring visit schedule with technician assignment and service tracking.", basePrice: 13974.58, defaultDurationMinutes: 240, badgeColor: "blue" },
  ];
  const productDocs = {};
  for (const p of catalog) {
    productDocs[p.name] = await Product.findOneAndUpdate(
      { productCode: p.productCode },
      { $set: { ...p, cgstRate: taxDocs.CGST_9._id, sgstRate: taxDocs.SGST_9._id } },
      { upsert: true, new: true }
    );
  }

  // 12. Product Variants & Pricing
  const variants = [
    { sku: "SKU-SHOE-4SHELF", product: productDocs["Wall Mounted Shoe Racks"]._id, measurement: measurementDocs["4_SHELF_WALL"]._id, variantName: "4 Shelf · Wall Mounted", additionalPrice: 0, durationMinutes: 120, isDefault: true },
    { sku: "SKU-HANGER-6PIPE", product: productDocs["Pull & Dry Cloth Drying Hangers"]._id, measurement: measurementDocs["6_PIPE_6FT"]._id, variantName: "6 Pipe · 6 Feet", additionalPrice: 500, durationMinutes: 90, isDefault: true },
  ];
  for (const v of variants) {
    const variantDoc = await ProductVariant.findOneAndUpdate({ sku: v.sku }, { $set: v }, { upsert: true, new: true });
    await Pricing.findOneAndUpdate(
      { product: v.product, variant: variantDoc._id },
      { $set: { baseRate: 7500, maxDiscountPercent: 10, defaultDiscountAmount: 0 } },
      { upsert: true, new: true }
    );
  }

  // 13. Bathroom Counts
  const bathroomCounts = [
    { countValue: 1, label: "1 Bathroom", defaultDurationMinutes: 60, displayOrder: 1 },
    { countValue: 2, label: "2 Bathrooms", defaultDurationMinutes: 90, displayOrder: 2 },
    { countValue: 3, label: "3 Bathrooms", defaultDurationMinutes: 120, displayOrder: 3 },
    { countValue: 4, label: "4 Bathrooms", defaultDurationMinutes: 150, displayOrder: 4 },
  ];
  const bCounts = {};
  for (const b of bathroomCounts) {
    bCounts[b.countValue] = await BathroomCount.findOneAndUpdate({ countValue: b.countValue }, { $set: b }, { upsert: true, new: true });
  }

  // 14. Property Sizes
  const propertySizes = [
    { sizeCode: "1BHK", label: "1BHK", defaultDurationMinutes: 180, displayOrder: 1 },
    { sizeCode: "2BHK", label: "2BHK", defaultDurationMinutes: 240, displayOrder: 2 },
    { sizeCode: "3BHK", label: "3BHK", defaultDurationMinutes: 300, displayOrder: 3 },
    { sizeCode: "VILLA", label: "Villa / Large Office", defaultDurationMinutes: 360, displayOrder: 4 },
  ];
  const pSizes = {};
  for (const ps of propertySizes) {
    pSizes[ps.sizeCode] = await PropertySize.findOneAndUpdate({ sizeCode: ps.sizeCode }, { $set: ps }, { upsert: true, new: true });
  }

  // 15. Service Durations Matrix
  for (const count of Object.values(bCounts)) {
    await ServiceDuration.findOneAndUpdate(
      { serviceType: stDocs["Bathroom Cleaning"]._id, bathroomCount: count._id },
      { $set: { durationMinutes: count.defaultDurationMinutes } },
      { upsert: true, new: true }
    );
  }
  for (const size of Object.values(pSizes)) {
    await ServiceDuration.findOneAndUpdate(
      { serviceType: stDocs["Deep Cleaning"]._id, propertySize: size._id },
      { $set: { durationMinutes: size.defaultDurationMinutes } },
      { upsert: true, new: true }
    );
  }

  // 16. Subscription Plans
  const plans = [
    { planCode: "BATH_WEEKLY_8", planName: "Once Every Week · 8 Visits", serviceType: stDocs["Bathroom Cleaning"]._id, frequency: "Once Every Week", totalVisits: 8, intervalDays: 7, displayOrder: 1 },
    { planCode: "BATH_BIWEEKLY_8", planName: "Once in 2 Weeks · 8 Visits", serviceType: stDocs["Bathroom Cleaning"]._id, frequency: "Once in 2 Weeks", totalVisits: 8, intervalDays: 14, displayOrder: 2 },
    { planCode: "DEEP_WEEKLY_4", planName: "Once Every Week · 4 Visits", serviceType: stDocs["Deep Cleaning"]._id, frequency: "Once Every Week", totalVisits: 4, intervalDays: 7, displayOrder: 3 },
    { planCode: "DEEP_BIWEEKLY_6", planName: "Once in 2 Weeks · 6 Visits", serviceType: stDocs["Deep Cleaning"]._id, frequency: "Once in 2 Weeks", totalVisits: 6, intervalDays: 14, displayOrder: 4 },
  ];
  for (const pl of plans) {
    await SubscriptionPlan.findOneAndUpdate({ planCode: pl.planCode }, { $set: pl }, { upsert: true, new: true });
  }

  // 17. Time Slots
  const slots = [
    { slotCode: "SLOT_0900_1030", label: "09:00 - 10:30", startTime: "09:00", endTime: "10:30", displayOrder: 1 },
    { slotCode: "SLOT_1000_1400", label: "10:00 - 14:00", startTime: "10:00", endTime: "14:00", displayOrder: 2 },
    { slotCode: "SLOT_1400_1600", label: "14:00 - 16:00", startTime: "14:00", endTime: "16:00", displayOrder: 3 },
    { slotCode: "SLOT_1600_1800", label: "16:00 - 18:00", startTime: "16:00", endTime: "18:00", displayOrder: 4 },
  ];
  for (const sl of slots) {
    await TimeSlot.findOneAndUpdate({ slotCode: sl.slotCode }, { $set: sl }, { upsert: true, new: true });
  }

  // 18. Technician Roles
  const techRoles = [
    { roleCode: "ROLE_INSTALLATION", roleTitle: "Installation Technician", defaultCapacity: 5, description: "Hanger, shoe rack, mosquito nets and grill installer" },
    { roleCode: "ROLE_BATHROOM_CLEANER", roleTitle: "Bathroom Cleaning Technician", defaultCapacity: 5, description: "Bathroom scrubbing and sanitization specialist" },
    { roleCode: "ROLE_DEEP_CLEANER", roleTitle: "Deep Cleaning Technician", defaultCapacity: 3, description: "Full house and office deep cleaning team" },
    { roleCode: "ROLE_MULTI_SKILLED", roleTitle: "Multi-skilled Technician", defaultCapacity: 5, description: "Certified in both installation and cleaning operations" },
  ];
  const trDocs = {};
  for (const tr of techRoles) {
    trDocs[tr.roleTitle] = await TechnicianRole.findOneAndUpdate({ roleCode: tr.roleCode }, { $set: tr }, { upsert: true, new: true });
  }

  // 19. Skills
  const skills = [
    { skillCode: "SKILL_SHOE_RACK", skillName: "Shoe Rack", category: "Installation" },
    { skillCode: "SKILL_CLOTH_HANGER", skillName: "Cloth Hanger", category: "Installation" },
    { skillCode: "SKILL_MOSQUITO_NET", skillName: "Mosquito Net", category: "Installation" },
    { skillCode: "SKILL_BIRD_NET", skillName: "Anti-Bird Net", category: "Installation" },
    { skillCode: "SKILL_INVISIBLE_GRILL", skillName: "Invisible Grill", category: "Installation" },
    { skillCode: "SKILL_WATER_PURIFIER", skillName: "Water Purifier", category: "Installation" },
    { skillCode: "SKILL_BATHROOM_CLEANING", skillName: "Bathroom Cleaning", category: "Cleaning" },
    { skillCode: "SKILL_DEEP_CLEANING", skillName: "Deep Cleaning", category: "Cleaning" },
  ];
  const skillDocs = {};
  for (const sk of skills) {
    skillDocs[sk.skillName] = await Skill.findOneAndUpdate({ skillCode: sk.skillCode }, { $set: sk }, { upsert: true, new: true });
  }

  // 20. Job Statuses
  const jobStatuses = [
    { statusCode: "UNASSIGNED", statusLabel: "Unassigned", rank: -1, badgeClass: "muted", badgeColorHex: "#64748b" },
    { statusCode: "ASSIGNED", statusLabel: "Assigned", rank: 0, badgeClass: "purple", badgeColorHex: "#5b47dc" },
    { statusCode: "ON_THE_WAY", statusLabel: "On the Way", rank: 1, badgeClass: "blue", badgeColorHex: "#2563eb" },
    { statusCode: "REACHED", statusLabel: "Reached", rank: 2, badgeClass: "amber", badgeColorHex: "#ad6500" },
    { statusCode: "IN_PROGRESS", statusLabel: "In Progress", rank: 3, badgeClass: "blue", badgeColorHex: "#2563eb" },
    { statusCode: "COMPLETED", statusLabel: "Completed", rank: 4, badgeClass: "green", badgeColorHex: "#148457" },
    { statusCode: "CLOSED", statusLabel: "Closed", rank: 5, badgeClass: "green", badgeColorHex: "#08764b", isTerminalState: true },
  ];
  const jsDocs = {};
  for (const js of jobStatuses) {
    jsDocs[js.statusLabel] = await JobStatus.findOneAndUpdate({ statusCode: js.statusCode }, { $set: js }, { upsert: true, new: true });
  }

  // 21. Follow-up Statuses
  const followUpStatuses = [
    { statusCode: "PENDING", statusLabel: "Pending", badgeClass: "amber", badgeColorHex: "#ad6500" },
    { statusCode: "CUSTOMER_CONFIRMED", statusLabel: "Customer Confirmed", badgeClass: "green", badgeColorHex: "#148457" },
    { statusCode: "ISSUE_REPORTED", statusLabel: "Issue Reported", badgeClass: "red", badgeColorHex: "#c62828" },
    { statusCode: "CLOSED", statusLabel: "Closed", badgeClass: "muted", badgeColorHex: "#64748b" },
  ];
  const fsDocs = {};
  for (const fs of followUpStatuses) {
    fsDocs[fs.statusLabel] = await FollowUpStatus.findOneAndUpdate({ statusCode: fs.statusCode }, { $set: fs }, { upsert: true, new: true });
  }

  // 22. Completion Results
  const completionResults = [
    { resultCode: "SUCCESS", label: "Completed Successfully", triggersReschedule: false, isSuccess: true },
    { resultCode: "PARTIAL", label: "Partially Completed", triggersReschedule: true, isSuccess: false },
    { resultCode: "NOT_AVAILABLE", label: "Customer Not Available", triggersReschedule: true, isSuccess: false },
    { resultCode: "MATERIAL_REQ", label: "Material Required", triggersReschedule: true, isSuccess: false },
    { resultCode: "RESCHEDULE_REQ", label: "Reschedule Required", triggersReschedule: true, isSuccess: false },
  ];
  for (const cr of completionResults) {
    await CompletionResult.findOneAndUpdate({ resultCode: cr.resultCode }, { $set: cr }, { upsert: true, new: true });
  }

  // 23. Payment Methods
  const paymentMethods = [
    { methodCode: "UPI", methodName: "UPI", requiresTransactionRef: true, description: "Instant QR / UPI handle payment" },
    { methodCode: "CASH", methodName: "Cash", requiresTransactionRef: false, description: "Cash on delivery / service" },
    { methodCode: "BANK_TRANSFER", methodName: "Bank Transfer", requiresTransactionRef: true, description: "Direct NEFT / IMPS transfer" },
  ];
  const pmDocs = {};
  for (const pm of paymentMethods) {
    pmDocs[pm.methodName] = await PaymentMethod.findOneAndUpdate({ methodCode: pm.methodCode }, { $set: pm }, { upsert: true, new: true });
  }

  // 24. Payment Statuses
  const paymentStatuses = [
    { statusCode: "PAID", statusLabel: "Paid", badgeClass: "green", badgeColorHex: "#148457" },
    { statusCode: "UNPAID", statusLabel: "Unpaid", badgeClass: "red", badgeColorHex: "#c62828" },
    { statusCode: "PARTIALLY_PAID", statusLabel: "Partially Paid", badgeClass: "amber", badgeColorHex: "#ad6500" },
    { statusCode: "REFUNDED", statusLabel: "Refunded", badgeClass: "blue", badgeColorHex: "#2563eb" },
  ];
  for (const ps of paymentStatuses) {
    await PaymentStatus.findOneAndUpdate({ statusCode: ps.statusCode }, { $set: ps }, { upsert: true, new: true });
  }

  // 25. Scheduling Rules
  const schedulingRules = [
    { ruleKey: "TRAVEL_BUFFER_DEFAULT", ruleName: "Default Travel Buffer", ruleValue: 30, unit: "minutes" },
    { ruleKey: "TRAVEL_BUFFER_OPTIONS", ruleName: "Travel Buffer Options", ruleValue: [30, 45, 60], unit: "minutes" },
    { ruleKey: "DEFAULT_TECH_CAPACITY", ruleName: "Default Daily Capacity", ruleValue: 5, unit: "jobs" },
    { ruleKey: "PREVENT_OVERLAP", ruleName: "Prevent Property/Technician Overlap", ruleValue: true, unit: "boolean" },
  ];
  for (const sr of schedulingRules) {
    await SchedulingRule.findOneAndUpdate({ ruleKey: sr.ruleKey }, { $set: sr }, { upsert: true, new: true });
  }

  logger.info("Master data successfully seeded.");
  return { roleDocs, areaDocs, aptDocs, stDocs, trDocs, skillDocs, jsDocs, fsDocs, pmDocs };
};

import {
  User,
  Customer,
  CustomerAddress,
  Technician,
  Order,
  OrderItem,
  Subscription,
  JobOrder,
  Invoice,
  Payment,
  ActiveStatus,
} from "../models/index.js";
import { logger } from "../config/logger.js";

export const seedOperationalData = async (masterDocs) => {
  logger.info("Seeding operational prototype data...");
  const { roleDocs, areaDocs, aptDocs, stDocs, trDocs, skillDocs, jsDocs, fsDocs } = masterDocs;

  const activeStatus = await ActiveStatus.findOne({ statusCode: "ACTIVE" });

  // 1. Technicians
  const techniciansData = [
    {
      techId: "TECH-001",
      name: "Arun S.",
      mobile: "9876543210",
      role: trDocs["Multi-skilled Technician"]._id,
      roleTitle: "Multi-skilled Technician",
      area: areaDocs["Anna Nagar"]._id,
      baseArea: "Anna Nagar",
      dailyCapacity: 5,
      skills: [
        skillDocs["Shoe Rack"]._id,
        skillDocs["Cloth Hanger"]._id,
        skillDocs["Invisible Grill"]._id,
        skillDocs["Bathroom Cleaning"]._id,
      ],
      skillNames: ["Shoe Rack", "Cloth Hanger", "Invisible Grill", "Bathroom Cleaning"],
    },
    {
      techId: "TECH-002",
      name: "Ravi K.",
      mobile: "9876543211",
      role: trDocs["Bathroom Cleaning Technician"]._id,
      roleTitle: "Cleaning Technician",
      area: areaDocs["Teynampet"]._id,
      baseArea: "Teynampet",
      dailyCapacity: 5,
      skills: [skillDocs["Bathroom Cleaning"]._id, skillDocs["Deep Cleaning"]._id],
      skillNames: ["Bathroom Cleaning", "Deep Cleaning"],
    },
    {
      techId: "TEAM-002",
      name: "Cleaning Team 2",
      mobile: "9876543212",
      role: trDocs["Deep Cleaning Technician"]._id,
      roleTitle: "Deep Cleaning Team",
      area: areaDocs["Velachery"]._id,
      baseArea: "Velachery",
      dailyCapacity: 3,
      skills: [skillDocs["Deep Cleaning"]._id, skillDocs["Bathroom Cleaning"]._id],
      skillNames: ["Deep Cleaning", "Bathroom Cleaning"],
    },
  ];

  const techDocs = {};
  for (const t of techniciansData) {
    techDocs[t.techId] = await Technician.findOneAndUpdate(
      { techId: t.techId },
      { $set: t },
      { upsert: true, new: true }
    );
  }

  // 2. Users (Super Admin, Telecaller, Technicians)
  const defaultPasswordHash = await User.hashPassword("Password@123");
  const usersData = [
    {
      username: "admin",
      fullName: "Super Admin",
      email: "admin@jollyhomeneeds.com",
      passwordHash: defaultPasswordHash,
      role: roleDocs.super_admin._id,
      mobile: "9840012345",
    },
    {
      username: "telecaller",
      fullName: "Operations Telecaller",
      email: "telecaller@jollyhomeneeds.com",
      passwordHash: defaultPasswordHash,
      role: roleDocs.telecaller._id,
      mobile: "9840012346",
    },
    {
      username: "tech001",
      fullName: "Arun S.",
      email: "arun@jollyhomeneeds.com",
      passwordHash: defaultPasswordHash,
      role: roleDocs.technician._id,
      technicianProfile: techDocs["TECH-001"]._id,
      mobile: "9876543210",
    },
    {
      username: "tech002",
      fullName: "Ravi K.",
      email: "ravi@jollyhomeneeds.com",
      passwordHash: defaultPasswordHash,
      role: roleDocs.technician._id,
      technicianProfile: techDocs["TECH-002"]._id,
      mobile: "9876543211",
    },
  ];

  for (const u of usersData) {
    const userDoc = await User.findOneAndUpdate(
      { username: u.username },
      { $set: u },
      { upsert: true, new: true }
    );
    if (u.technicianProfile) {
      await Technician.findByIdAndUpdate(u.technicianProfile, { user: userDoc._id });
    }
  }

  // 3. Customers & Properties
  const customersData = [
    {
      customerId: "CUS-000001",
      name: "Aslam",
      mobile: "8745654565",
      whatsapp: "8745654565",
      email: "aslam@example.com",
      status: activeStatus._id,
      property: {
        propertyId: "PROP-001",
        label: "Home",
        propertyName: "MS Residency",
        apartment: aptDocs["MS Residency"]?._id || null,
        door: "1/100",
        area: areaDocs["SPGC Nagar"]?._id || null,
        areaName: "SPGC Nagar",
        address: "South Side, Vellakulam",
        isDefault: true,
      },
    },
    {
      customerId: "CUS-000002",
      name: "Priya Nair",
      mobile: "9988776655",
      whatsapp: "9988776655",
      email: "priya@example.com",
      status: activeStatus._id,
      property: {
        propertyId: "PROP-002",
        label: "Home",
        propertyName: "Lake View Apartments",
        apartment: aptDocs["Lake View Apartments"]?._id || null,
        door: "A-402",
        area: areaDocs["Anna Nagar"]?._id || null,
        areaName: "Anna Nagar",
        address: "Lake Road, Chennai - 600040",
        isDefault: true,
      },
    },
    {
      customerId: "CUS-000003",
      name: "Rajesh Babu",
      mobile: "9123456789",
      whatsapp: "9123456789",
      email: "rajesh@example.com",
      status: activeStatus._id,
      property: {
        propertyId: "PROP-003",
        label: "Home",
        propertyName: "Green Court",
        apartment: aptDocs["Green Court"]?._id || null,
        door: "B-806",
        area: areaDocs["Velachery"]?._id || null,
        areaName: "Velachery",
        address: "Main Road, Chennai",
        isDefault: true,
      },
    },
  ];

  const customerDocs = {};
  const propertyDocs = {};

  for (const c of customersData) {
    const custDoc = await Customer.findOneAndUpdate(
      { customerId: c.customerId },
      {
        $set: {
          customerId: c.customerId,
          name: c.name,
          mobile: c.mobile,
          whatsapp: c.whatsapp,
          email: c.email,
          status: c.status,
        },
      },
      { upsert: true, new: true }
    );
    customerDocs[c.customerId] = custDoc;

    const propDoc = await CustomerAddress.findOneAndUpdate(
      { propertyId: c.property.propertyId },
      {
        $set: {
          ...c.property,
          customer: custDoc._id,
        },
      },
      { upsert: true, new: true }
    );
    propertyDocs[c.property.propertyId] = propDoc;
  }

  // 4. Invoices, Orders, Subscriptions & Jobs
  // Order 1: ORD-2026-1101 (Installation)
  const inv1 = await Invoice.findOneAndUpdate(
    { invoiceId: "INV-001101" },
    {
      $set: {
        invoiceId: "INV-001101",
        orderNumber: "ORD-2026-1101",
        customer: customerDocs["CUS-000001"]._id,
        category: "Product Installation",
        subTotal: 7500,
        cgst: 675,
        sgst: 675,
        totalAmount: 8850,
        statusLabel: "Paid",
        paymentMode: "UPI",
        transactionRef: "UPI/2026/874565",
      },
    },
    { upsert: true, new: true }
  );

  const ord1 = await Order.findOneAndUpdate(
    { orderId: "ORD-2026-1101" },
    {
      $set: {
        orderId: "ORD-2026-1101",
        customer: customerDocs["CUS-000001"]._id,
        property: propertyDocs["PROP-001"]._id,
        serviceType: stDocs["Product Installation"]._id,
        orderType: "Product Installation",
        serviceName: "Wall Mounted Shoe Rack",
        configuration: "4 Shelf · Wall Mounted",
        plan: "1 Unit",
        serviceDate: "2026-11-02",
        startTime: "14:00",
        endTime: "16:00",
        durationMinutes: 120,
        assignedTech: techDocs["TECH-001"]._id,
        charges: 7500,
        discount: 0,
        cgst: 675,
        sgst: 675,
        totalAmount: 8850,
        paymentModeName: "UPI",
        invoice: inv1._id,
        invoiceNumber: "INV-001101",
        status: "Installation Scheduled",
      },
    },
    { upsert: true, new: true }
  );
  await Invoice.findByIdAndUpdate(inv1._id, { order: ord1._id });

  await OrderItem.findOneAndUpdate(
    { order: ord1._id },
    {
      $set: {
        order: ord1._id,
        itemTitle: "Wall Mounted Shoe Rack - 4 Shelf",
        quantity: 1,
        unitPrice: 7500,
        cgstAmount: 675,
        sgstAmount: 675,
        totalAmount: 8850,
      },
    },
    { upsert: true }
  );

  // Order 2: ORD-2026-1102 (Bathroom Cleaning Subscription)
  const inv2 = await Invoice.findOneAndUpdate(
    { invoiceId: "INV-001102" },
    {
      $set: {
        invoiceId: "INV-001102",
        orderNumber: "ORD-2026-1102",
        customer: customerDocs["CUS-000002"]._id,
        category: "Bathroom Cleaning",
        subTotal: 5500,
        cgst: 495,
        sgst: 495,
        totalAmount: 6490,
        statusLabel: "Paid",
        paymentMode: "UPI",
        transactionRef: "UPI/2026/998877",
      },
    },
    { upsert: true, new: true }
  );

  const ord2 = await Order.findOneAndUpdate(
    { orderId: "ORD-2026-1102" },
    {
      $set: {
        orderId: "ORD-2026-1102",
        customer: customerDocs["CUS-000002"]._id,
        property: propertyDocs["PROP-002"]._id,
        serviceType: stDocs["Bathroom Cleaning"]._id,
        orderType: "Bathroom Cleaning",
        serviceName: "2 Bathrooms · Weekly · 8 Visits",
        configuration: "2 Bathrooms · 90 mins",
        plan: "Once Every Week · 8 Visits",
        serviceDate: "2026-11-02",
        startTime: "09:00",
        endTime: "10:30",
        durationMinutes: 90,
        assignedTech: techDocs["TECH-002"]._id,
        charges: 5500,
        discount: 0,
        cgst: 495,
        sgst: 495,
        totalAmount: 6490,
        paymentModeName: "UPI",
        invoice: inv2._id,
        invoiceNumber: "INV-001102",
        status: "Active",
      },
    },
    { upsert: true, new: true }
  );
  await Invoice.findByIdAndUpdate(inv2._id, { order: ord2._id });

  const sub1 = await Subscription.findOneAndUpdate(
    { subscriptionId: "SUB-000301" },
    {
      $set: {
        subscriptionId: "SUB-000301",
        order: ord2._id,
        customer: customerDocs["CUS-000002"]._id,
        property: propertyDocs["PROP-002"]._id,
        serviceType: stDocs["Bathroom Cleaning"]._id,
        typeName: "Bathroom Cleaning",
        configuration: "2 Bathrooms · 90 mins",
        frequency: "Once Every Week",
        slot: "09:00-10:30",
        totalVisits: 8,
        completedVisits: 4,
        nextVisitDate: "03 Nov 2026",
        invoice: inv2._id,
        invoiceNumber: "INV-001102",
        status: "Active",
      },
    },
    { upsert: true, new: true }
  );

  // Order 3: ORD-2026-1103 (Deep Cleaning Subscription)
  const inv3 = await Invoice.findOneAndUpdate(
    { invoiceId: "INV-001103" },
    {
      $set: {
        invoiceId: "INV-001103",
        orderNumber: "ORD-2026-1103",
        customer: customerDocs["CUS-000003"]._id,
        category: "Deep Cleaning",
        subTotal: 13974.58,
        cgst: 1257.71,
        sgst: 1257.71,
        totalAmount: 16490,
        statusLabel: "Paid",
        paymentMode: "UPI",
        transactionRef: "UPI/2026/912345",
      },
    },
    { upsert: true, new: true }
  );

  const ord3 = await Order.findOneAndUpdate(
    { orderId: "ORD-2026-1103" },
    {
      $set: {
        orderId: "ORD-2026-1103",
        customer: customerDocs["CUS-000003"]._id,
        property: propertyDocs["PROP-003"]._id,
        serviceType: stDocs["Deep Cleaning"]._id,
        orderType: "Deep Cleaning",
        serviceName: "3BHK · Once in 2 Weeks · 6 Visits",
        configuration: "3BHK · 4 hours",
        plan: "Once in 2 Weeks · 6 Visits",
        serviceDate: "2026-11-02",
        startTime: "10:00",
        endTime: "14:00",
        durationMinutes: 240,
        assignedTech: techDocs["TEAM-002"]._id,
        charges: 13974.58,
        discount: 0,
        cgst: 1257.71,
        sgst: 1257.71,
        totalAmount: 16490,
        paymentModeName: "UPI",
        invoice: inv3._id,
        invoiceNumber: "INV-001103",
        status: "Active",
      },
    },
    { upsert: true, new: true }
  );
  await Invoice.findByIdAndUpdate(inv3._id, { order: ord3._id });

  const sub2 = await Subscription.findOneAndUpdate(
    { subscriptionId: "SUB-000302" },
    {
      $set: {
        subscriptionId: "SUB-000302",
        order: ord3._id,
        customer: customerDocs["CUS-000003"]._id,
        property: propertyDocs["PROP-003"]._id,
        serviceType: stDocs["Deep Cleaning"]._id,
        typeName: "Deep Cleaning",
        configuration: "3BHK · 4 hours",
        frequency: "Once in 2 Weeks",
        slot: "10:00-14:00",
        totalVisits: 6,
        completedVisits: 2,
        nextVisitDate: "14 Nov 2026",
        invoice: inv3._id,
        invoiceNumber: "INV-001103",
        status: "Active",
      },
    },
    { upsert: true, new: true }
  );

  // 5. Job Orders
  // JOB-2501
  await JobOrder.findOneAndUpdate(
    { jobId: "JOB-2501" },
    {
      $set: {
        jobId: "JOB-2501",
        order: ord2._id,
        subscription: sub1._id,
        customer: customerDocs["CUS-000002"]._id,
        property: propertyDocs["PROP-002"]._id,
        title: "Bathroom Cleaning · 2 Bathrooms",
        serviceType: stDocs["Bathroom Cleaning"]._id,
        typeName: "Bathroom Cleaning",
        plannedDate: "2026-11-02",
        startTime: "09:00",
        endTime: "10:30",
        durationMinutes: 90,
        technician: techDocs["TECH-002"]._id,
        status: jsDocs["Completed"]?._id || null,
        statusLabel: "Completed",
        arrivalTime: "09:02",
        workStartedTime: "09:06",
        workCompletedTime: "10:28",
        followUpStatus: fsDocs["Pending"]?._id || null,
        customerFollowup: "Pending",
      },
    },
    { upsert: true }
  );

  // JOB-2502
  await JobOrder.findOneAndUpdate(
    { jobId: "JOB-2502" },
    {
      $set: {
        jobId: "JOB-2502",
        order: ord3._id,
        subscription: sub2._id,
        customer: customerDocs["CUS-000003"]._id,
        property: propertyDocs["PROP-003"]._id,
        title: "Deep Cleaning · 3BHK",
        serviceType: stDocs["Deep Cleaning"]._id,
        typeName: "Deep Cleaning",
        plannedDate: "2026-11-02",
        startTime: "10:00",
        endTime: "14:00",
        durationMinutes: 240,
        technician: techDocs["TEAM-002"]._id,
        status: jsDocs["In Progress"]?._id || null,
        statusLabel: "In Progress",
        arrivalTime: "10:18",
        workStartedTime: "10:25",
        workCompletedTime: "",
        customerFollowup: "",
      },
    },
    { upsert: true }
  );

  // JOB-2503
  await JobOrder.findOneAndUpdate(
    { jobId: "JOB-2503" },
    {
      $set: {
        jobId: "JOB-2503",
        order: ord1._id,
        customer: customerDocs["CUS-000001"]._id,
        property: propertyDocs["PROP-001"]._id,
        title: "Shoe Rack Delivery & Installation",
        serviceType: stDocs["Product Installation"]._id,
        typeName: "Installation",
        plannedDate: "2026-11-02",
        startTime: "14:00",
        endTime: "16:00",
        durationMinutes: 120,
        technician: techDocs["TECH-001"]._id,
        status: jsDocs["Assigned"]?._id || null,
        statusLabel: "Assigned",
        arrivalTime: "",
        workStartedTime: "",
        workCompletedTime: "",
        customerFollowup: "",
      },
    },
    { upsert: true }
  );

  // 6. Payments
  const paymentsData = [
    { paymentId: "PAY-001101", invoice: inv1._id, customer: customerDocs["CUS-000001"]._id, amount: 8850, methodName: "UPI", transactionRef: "UPI/2026/874565" },
    { paymentId: "PAY-001102", invoice: inv2._id, customer: customerDocs["CUS-000002"]._id, amount: 6490, methodName: "UPI", transactionRef: "UPI/2026/998877" },
    { paymentId: "PAY-001103", invoice: inv3._id, customer: customerDocs["CUS-000003"]._id, amount: 16490, methodName: "UPI", transactionRef: "UPI/2026/912345" },
  ];
  for (const pay of paymentsData) {
    await Payment.findOneAndUpdate({ paymentId: pay.paymentId }, { $set: pay }, { upsert: true });
  }

  logger.info("Operational prototype data successfully seeded.");
};

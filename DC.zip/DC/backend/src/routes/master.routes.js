import { Router } from "express";
import { getBootstrap, getMasterByName } from "../controllers/masterBootstrap.controller.js";
import { createMasterService } from "../services/masterData.factory.js";
import { createMasterController } from "../controllers/masterData.factory.js";
import { authenticate, authorize } from "../middlewares/auth.middleware.js";
import {
  ActiveStatus,
  Area,
  Apartment,
  ServiceType,
  Measurement,
  Tax,
  Product,
  ProductVariant,
  Pricing,
  BathroomCount,
  PropertySize,
  ServiceDuration,
  SubscriptionPlan,
  TimeSlot,
  TechnicianRole,
  Skill,
  JobStatus,
  FollowUpStatus,
  CompletionResult,
  PaymentMethod,
  PaymentStatus,
  SchedulingRule,
} from "../models/index.js";

const router = Router();

// ================= BOOTSTRAP ENDPOINTS =================
router.get("/masters/bootstrap", getBootstrap);
router.get("/masters/:name", getMasterByName);

/**
 * Helper to register standard CRUD endpoints for any Master Collection.
 *
 * @param {string} path - URL sub-path (e.g. "/masters/areas")
 * @param {import("mongoose").Model} Model - Target Model
 * @param {object} options - Service configuration options
 */
const registerMasterEndpoints = (path, Model, options) => {
  const service = createMasterService(Model, options);
  const controller = createMasterController(service, options.resourceName);

  router.get(path, controller.getAll);
  router.get(`${path}/:id`, controller.getById);

  router.post(
    path,
    authenticate,
    authorize("configuration", "write"),
    controller.create
  );

  router.put(
    `${path}/:id`,
    authenticate,
    authorize("configuration", "write"),
    controller.update
  );

  router.patch(
    `${path}/:id/status`,
    authenticate,
    authorize("configuration", "write"),
    controller.toggleStatus
  );

  router.delete(
    `${path}/:id`,
    authenticate,
    authorize("configuration", "delete"),
    controller.delete
  );
};

// Register specific CRUD routes for each master collection:
registerMasterEndpoints("/masters/areas", Area, {
  resourceName: "Area",
  searchFields: ["name", "areaCode", "city", "pincode"],
  defaultSort: { name: 1 },
});

registerMasterEndpoints("/masters/apartments", Apartment, {
  resourceName: "Apartment",
  searchFields: ["name", "address"],
  populateOptions: "area",
  defaultSort: { name: 1 },
});

registerMasterEndpoints("/masters/service-types", ServiceType, {
  resourceName: "Service Type",
  searchFields: ["typeName", "typeCode", "category"],
  defaultSort: { defaultDurationMinutes: 1 },
});

registerMasterEndpoints("/masters/measurements", Measurement, {
  resourceName: "Measurement",
  searchFields: ["label", "measurementCode"],
  defaultSort: { label: 1 },
});

registerMasterEndpoints("/masters/taxes", Tax, {
  resourceName: "Tax",
  searchFields: ["taxName", "taxCode"],
  defaultSort: { ratePercent: 1 },
});

registerMasterEndpoints("/masters/products", Product, {
  resourceName: "Product",
  searchFields: ["name", "productCode", "description"],
  populateOptions: ["serviceType", "cgstRate", "sgstRate"],
  defaultSort: { displayOrder: 1, name: 1 },
});

registerMasterEndpoints("/masters/product-variants", ProductVariant, {
  resourceName: "Product Variant",
  searchFields: ["sku", "variantName"],
  populateOptions: ["product", "measurement"],
  defaultSort: { sku: 1 },
});

registerMasterEndpoints("/masters/pricing", Pricing, {
  resourceName: "Pricing",
  populateOptions: ["product", "variant"],
  defaultSort: { createdAt: -1 },
});

registerMasterEndpoints("/masters/bathroom-counts", BathroomCount, {
  resourceName: "Bathroom Count",
  searchFields: ["label"],
  defaultSort: { countValue: 1 },
});

registerMasterEndpoints("/masters/property-sizes", PropertySize, {
  resourceName: "Property Size",
  searchFields: ["label", "sizeCode"],
  defaultSort: { displayOrder: 1 },
});

registerMasterEndpoints("/masters/service-durations", ServiceDuration, {
  resourceName: "Service Duration",
  populateOptions: ["serviceType", "bathroomCount", "propertySize"],
  defaultSort: { durationMinutes: 1 },
});

registerMasterEndpoints("/masters/subscription-plans", SubscriptionPlan, {
  resourceName: "Subscription Plan",
  searchFields: ["planName", "planCode", "frequency"],
  populateOptions: "serviceType",
  defaultSort: { displayOrder: 1 },
});

registerMasterEndpoints("/masters/time-slots", TimeSlot, {
  resourceName: "Time Slot",
  searchFields: ["label", "slotCode"],
  defaultSort: { displayOrder: 1, startTime: 1 },
});

registerMasterEndpoints("/masters/technician-roles", TechnicianRole, {
  resourceName: "Technician Role",
  searchFields: ["roleTitle", "roleCode"],
  defaultSort: { defaultCapacity: -1 },
});

registerMasterEndpoints("/masters/skills", Skill, {
  resourceName: "Skill",
  searchFields: ["skillName", "skillCode", "category"],
  defaultSort: { category: 1, skillName: 1 },
});

registerMasterEndpoints("/masters/job-statuses", JobStatus, {
  resourceName: "Job Status",
  searchFields: ["statusLabel", "statusCode"],
  defaultSort: { rank: 1 },
});

registerMasterEndpoints("/masters/follow-up-statuses", FollowUpStatus, {
  resourceName: "Follow Up Status",
  searchFields: ["statusLabel", "statusCode"],
  defaultSort: { statusCode: 1 },
});

registerMasterEndpoints("/masters/completion-results", CompletionResult, {
  resourceName: "Completion Result",
  searchFields: ["label", "resultCode"],
  defaultSort: { resultCode: 1 },
});

registerMasterEndpoints("/masters/payment-methods", PaymentMethod, {
  resourceName: "Payment Method",
  searchFields: ["methodName", "methodCode"],
  defaultSort: { methodName: 1 },
});

registerMasterEndpoints("/masters/payment-statuses", PaymentStatus, {
  resourceName: "Payment Status",
  searchFields: ["statusLabel", "statusCode"],
  defaultSort: { statusCode: 1 },
});

registerMasterEndpoints("/masters/scheduling-rules", SchedulingRule, {
  resourceName: "Scheduling Rule",
  searchFields: ["ruleName", "ruleKey"],
  defaultSort: { ruleKey: 1 },
});

registerMasterEndpoints("/masters/active-statuses", ActiveStatus, {
  resourceName: "Active Status",
  searchFields: ["statusLabel", "statusCode"],
  defaultSort: { statusCode: 1 },
});

export default router;

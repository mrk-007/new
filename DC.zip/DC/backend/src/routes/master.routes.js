/**
 * @file master.routes.js
 * @description Express routing definitions for master dropdown and status lookups.
 */
import { Router } from "express";
import { getMasters } from "../controllers/master.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();

router.get("/masters", authenticate, getMasters);

export default router;

/**
 * @file visit.routes.js
 * @description Visit listing and lifecycle routes.
 */
import { Router } from "express";
import * as visitController from "../controllers/visit.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { completeVisitRules, cancelVisitRules, reassignVisitRules, allocateVisitRules } from "../validators/visit.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
router.use(authenticate);
router.get("/", authorize(PERMISSION.READ), visitController.list);
router.get("/mine", authorize(PERMISSION.READ), visitController.mine);
router.get("/:id", authorize(PERMISSION.READ), visitController.get);
router.patch("/:id/start", authorize(PERMISSION.WRITE), visitController.start);
router.patch("/:id/complete", authorize(PERMISSION.WRITE), validateBody(completeVisitRules), visitController.complete);
router.patch("/:id/cancel", authorize(PERMISSION.WRITE), validateBody(cancelVisitRules), visitController.cancel);
router.post("/:id/allocate", authorize(PERMISSION.WRITE), validateBody(allocateVisitRules), visitController.allocate);
router.patch("/:id/reassign", authorize(PERMISSION.WRITE), validateBody(reassignVisitRules), visitController.reassign);

export default router;

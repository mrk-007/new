/**
 * @file address.routes.js
 * @description Standalone address update, delete, and default routes.
 */
import { Router } from "express";
import * as customerController from "../controllers/customer.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { updateAddressRules } from "../validators/address.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
router.use(authenticate);
router.put("/:id", authorize(PERMISSION.WRITE), validateBody(updateAddressRules), customerController.updateAddress);
router.patch("/:id", authorize(PERMISSION.WRITE), validateBody(updateAddressRules), customerController.updateAddress);
router.delete("/:id", authorize(PERMISSION.DELETE), customerController.removeAddress);
router.patch("/:id/default", authorize(PERMISSION.WRITE), customerController.setDefault);

export default router;

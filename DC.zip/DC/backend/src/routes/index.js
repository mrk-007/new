import { Router } from "express";
import healthRoutes from "./health.routes.js";
import authRoutes from "./auth.routes.js";
import rbacRoutes from "./rbac.routes.js";
import masterRoutes from "./master.routes.js";
import customerRoutes from "./customer.routes.js";
import catalogRoutes from "./catalog.routes.js";
import orderRoutes from "./order.routes.js";
import dashboardRoutes from "./dashboard.routes.js";

const apiRouter = Router();

// Base health check
apiRouter.use(healthRoutes);

// Authentication & Session
apiRouter.use("/auth", authRoutes);

// Access Control & Configuration Management
apiRouter.use(rbacRoutes);

// Master Data & Unified Bootstrap Endpoints
apiRouter.use(masterRoutes);

// Dashboard Operations Overview
apiRouter.use(dashboardRoutes);

// Customer Management & 360 Profile
apiRouter.use(customerRoutes);

// Product Catalog & Price Quoting
apiRouter.use(catalogRoutes);

// Orders & Recurring Cleaning Subscriptions
apiRouter.use(orderRoutes);

export default apiRouter;

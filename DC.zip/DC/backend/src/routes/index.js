/**
 * @file index.js
 * @description Central API router aggregating authentication and dashboard endpoints.
 */
import { Router } from "express";
import authRoutes from "./auth.routes.js";
import dashboardRoutes from "./dashboard.routes.js";

const apiRouter = Router();

apiRouter.use("/auth", authRoutes);
apiRouter.use(dashboardRoutes);
apiRouter.use(require('./jobOrder.routes.js').default);
apiRouter.use(require('./schedule.routes.js').default);
apiRouter.use(require('./subscription.routes.js').default);
apiRouter.use(require('./payment.routes.js').default);
apiRouter.use(require('./myJobs.routes.js').default);


export default apiRouter;

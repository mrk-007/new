/**
 * @file index.js
 * @description Mounts all /api/v1 resource routers.
 */
import { Router } from "express";
import { masterRouter } from "./master.factory.js";
import authRoutes from "./auth.routes.js";
import userRoutes from "./user.routes.js";
import customerRoutes from "./customer.routes.js";
import addressRoutes from "./address.routes.js";
import technicianRoutes from "./technician.routes.js";
import orderRoutes from "./order.routes.js";
import subscriptionRoutes from "./subscription.routes.js";
import visitRoutes from "./visit.routes.js";
import pricingRoutes from "./pricing.routes.js";
import timeSlotRoutes from "./timeslot.routes.js";
import dashboardRoutes from "./dashboard.routes.js";
import auditRoutes from "./audit.routes.js";
import {
  Role,
  Apartment,
  ServiceType,
  Product,
  SubscriptionPlan,
  SubscriptionTerm,
  ServiceFrequency,
  BathroomCount,
  PropertySize,
  Duration,
  Tax,
  Skill,
} from "../models/index.js";
import {
  roleRules,
  apartmentRules,
  serviceTypeRules,
  productRules,
  subscriptionPlanRules,
  subscriptionTermRules,
  serviceFrequencyRules,
  bathroomCountRules,
  propertySizeRules,
  durationRules,
  taxRules,
  skillRules,
} from "../validators/masters.rules.js";

const apiRouter = Router();

apiRouter.use("/auth", authRoutes);
apiRouter.use("/users", userRoutes);
apiRouter.use("/roles", masterRouter(Role, { searchFields: ["roleName"], createRules: roleRules }));
apiRouter.use("/apartments", masterRouter(Apartment, { searchFields: ["name"], createRules: apartmentRules }));
apiRouter.use("/service-types", masterRouter(ServiceType, { searchFields: ["name", "code"], createRules: serviceTypeRules }));
apiRouter.use("/products", masterRouter(Product, { searchFields: ["name", "code"], populate: "serviceType", createRules: productRules }));
apiRouter.use(
  "/subscription-plans",
  masterRouter(SubscriptionPlan, { searchFields: ["name", "code"], populate: "serviceType", createRules: subscriptionPlanRules })
);
apiRouter.use("/subscription-terms", masterRouter(SubscriptionTerm, { searchFields: ["name"], createRules: subscriptionTermRules }));
apiRouter.use("/service-frequencies", masterRouter(ServiceFrequency, { searchFields: ["name"], createRules: serviceFrequencyRules }));
apiRouter.use("/bathroom-counts", masterRouter(BathroomCount, { searchFields: ["name"], createRules: bathroomCountRules }));
apiRouter.use("/property-sizes", masterRouter(PropertySize, { searchFields: ["name"], createRules: propertySizeRules }));
apiRouter.use(
  "/durations",
  masterRouter(Duration, { searchFields: [], populate: "bathroomCount propertySize product", createRules: durationRules })
);
apiRouter.use("/pricing", pricingRoutes);
apiRouter.use("/time-slots", timeSlotRoutes);
apiRouter.use("/taxes", masterRouter(Tax, { searchFields: ["state", "city"], createRules: taxRules }));
apiRouter.use("/skills", masterRouter(Skill, { searchFields: ["name", "code"], populate: "product subscriptionPlan", createRules: skillRules }));
apiRouter.use("/customers", customerRoutes);
apiRouter.use("/addresses", addressRoutes);
apiRouter.use("/technicians", technicianRoutes);
apiRouter.use("/orders", orderRoutes);
apiRouter.use("/subscriptions", subscriptionRoutes);
apiRouter.use("/visits", visitRoutes);
apiRouter.use("/audit-logs", auditRoutes);
apiRouter.use("/dashboard", dashboardRoutes);

export default apiRouter;

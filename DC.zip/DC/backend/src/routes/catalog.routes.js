import { Router } from "express";
import { getCatalog, getProductById, calculateQuote } from "../controllers/catalog.controller.js";
import { authenticate, authorize } from "../middlewares/auth.middleware.js";
import { validateRequest } from "../middlewares/validateRequest.js";
import { calculateQuoteSchema } from "../validators/order.validator.js";

const router = Router();

router.get("/catalog", authenticate, authorize("catalog", "read"), getCatalog);
router.get("/catalog/:id", authenticate, authorize("catalog", "read"), getProductById);
router.post(
  "/catalog/calculate-quote",
  authenticate,
  authorize("orders", "read"),
  validateRequest(calculateQuoteSchema),
  calculateQuote
);

export default router;

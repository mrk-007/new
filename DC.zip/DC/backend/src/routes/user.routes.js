/**
 * @file user.routes.js
 * @description User list/get/update/soft-delete routes.
 */
import { Router } from "express";
import * as userController from "../controllers/user.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { updateUserRules } from "../validators/user.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
router.use(authenticate);
router.get("/", authorize(PERMISSION.READ), userController.list);
router.get("/:id", authorize(PERMISSION.READ), userController.get);
router.put("/:id", authorize(PERMISSION.WRITE), validateBody(updateUserRules), userController.update);
router.patch("/:id", authorize(PERMISSION.WRITE), validateBody(updateUserRules), userController.update);
router.delete("/:id", authorize(PERMISSION.DELETE), userController.remove);

export default router;

/**
 * @file subscription.routes.js
 * @description Route definitions for subscription operations.
 */
import { Router } from "express";
import { getSubscriptions, createSubscription, updateSubscriptionStatus } from "../controllers/subscription.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();
router.use(authenticate);

router.get("/subscriptions", getSubscriptions);
router.post("/subscriptions", createSubscription);
router.patch("/subscriptions/:id/status", updateSubscriptionStatus);

export default router;

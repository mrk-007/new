/**
 * @file subscription.routes.js
 * @description Recurring subscription routes.
 */
import { Router } from "express";
import * as subscriptionController from "../controllers/subscription.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { createSubscriptionRules, cancelSubscriptionRules } from "../validators/subscription.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
router.use(authenticate);
router.post("/", authorize(PERMISSION.WRITE), validateBody(createSubscriptionRules), subscriptionController.create);
router.get("/", authorize(PERMISSION.READ), subscriptionController.list);
router.get("/:id", authorize(PERMISSION.READ), subscriptionController.get);
router.post("/:id/cancel", authorize(PERMISSION.WRITE), validateBody(cancelSubscriptionRules), subscriptionController.cancel);

export default router;

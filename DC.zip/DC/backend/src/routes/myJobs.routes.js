/**
 * @file myJobs.routes.js
 * @description Routes for technician "My Jobs" view and status updates.
 */
import { Router } from "express";
import { getMyJobs, updateMyJobStatus } from "../controllers/myJobs.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { requireRole } from "../middlewares/role.middleware.js";

const router = Router();
router.use(authenticate);
router.use(requireRole(['technician']));

router.get("/my-jobs", getMyJobs);
router.patch("/my-jobs/:id", updateMyJobStatus);

export default router;

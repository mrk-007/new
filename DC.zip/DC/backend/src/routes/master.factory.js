/**
 * @file master.factory.js
 * @description Builds generic master CRUD routers with auth, permission, and validation.
 */
import { Router } from "express";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { createCrudController } from "../controllers/crud.controller.js";
import { PERMISSION } from "../constants/index.js";

/** Creates list/get/create/update/soft-delete routes for a master model. */
export const masterRouter = (Model, { searchFields = ["name", "code"], populate = "", createRules } = {}) => {
  const router = Router();
  const ctrl = createCrudController(Model, { searchFields, populate });
  router.use(authenticate);
  router.get("/", authorize(PERMISSION.READ), ctrl.list);
  router.get("/:id", authorize(PERMISSION.READ), ctrl.get);
  router.post("/", authorize(PERMISSION.WRITE), createRules ? validateBody(createRules) : (_req, _res, next) => next(), ctrl.create);
  router.put("/:id", authorize(PERMISSION.WRITE), createRules ? validateBody(createRules) : (_req, _res, next) => next(), ctrl.update);
  router.patch("/:id", authorize(PERMISSION.WRITE), createRules ? validateBody(createRules, { partial: true }) : (_req, _res, next) => next(), ctrl.update);
  router.delete("/:id", authorize(PERMISSION.DELETE), ctrl.remove);
  return router;
};

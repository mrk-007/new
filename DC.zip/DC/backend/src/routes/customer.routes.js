/**
 * @file customer.routes.js
 * @description Express routing definitions for customer directory and 360 profile views.
 */
import { Router } from "express";
import {
  getCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
} from "../controllers/customer.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();

router.use(authenticate);

router.get("/customers", getCustomers);
router.post("/customers", createCustomer);
router.get("/customers/:id", getCustomerById);
router.put("/customers/:id", updateCustomer);

export default router;

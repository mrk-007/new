/**
 * @file customer.routes.js
 * @description Customer CRUD and nested address routes.
 */
import { Router } from "express";
import * as customerController from "../controllers/customer.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { createCustomerRules, updateCustomerRules } from "../validators/customer.rules.js";
import { createAddressRules } from "../validators/address.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
router.use(authenticate);
router.get("/", authorize(PERMISSION.READ), customerController.list);
router.get("/:id", authorize(PERMISSION.READ), customerController.get);
router.post("/", authorize(PERMISSION.WRITE), validateBody(createCustomerRules), customerController.create);
router.put("/:id", authorize(PERMISSION.WRITE), validateBody(updateCustomerRules), customerController.update);
router.patch("/:id", authorize(PERMISSION.WRITE), validateBody(updateCustomerRules), customerController.update);
router.delete("/:id", authorize(PERMISSION.DELETE), customerController.remove);
router.get("/:id/addresses", authorize(PERMISSION.READ), customerController.listAddresses);
router.post("/:id/addresses", authorize(PERMISSION.WRITE), validateBody(createAddressRules), customerController.createAddress);

export default router;

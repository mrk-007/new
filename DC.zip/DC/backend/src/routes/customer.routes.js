import { Router } from "express";
import {
  getCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer,
  addProperty,
  getCustomer360,
  exportCustomerCsv,
} from "../controllers/customer.controller.js";
import { authenticate, authorize } from "../middlewares/auth.middleware.js";
import { validateRequest } from "../middlewares/validateRequest.js";
import {
  createCustomerSchema,
  updateCustomerSchema,
  addPropertySchema,
} from "../validators/customer.validator.js";

const router = Router();

router.get("/customers", authenticate, authorize("customers", "read"), getCustomers);
router.get("/customers/:id", authenticate, authorize("customers", "read"), getCustomerById);
router.get("/customers/:id/360", authenticate, authorize("customers", "read"), getCustomer360);
router.get("/customers/:id/export", authenticate, authorize("customers", "read"), exportCustomerCsv);

router.post(
  "/customers",
  authenticate,
  authorize("customers", "write"),
  validateRequest(createCustomerSchema),
  createCustomer
);

router.put(
  "/customers/:id",
  authenticate,
  authorize("customers", "write"),
  validateRequest(updateCustomerSchema),
  updateCustomer
);

router.delete(
  "/customers/:id",
  authenticate,
  authorize("customers", "delete"),
  deleteCustomer
);

router.post(
  "/customers/:id/properties",
  authenticate,
  authorize("customers", "write"),
  validateRequest(addPropertySchema),
  addProperty
);

export default router;

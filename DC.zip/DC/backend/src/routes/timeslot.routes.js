/**
 * @file timeslot.routes.js
 * @description Time-slot master CRUD plus available-slot generation.
 */
import { Router } from "express";
import { TimeSlot } from "../models/TimeSlot.model.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { createCrudController } from "../controllers/crud.controller.js";
import { available } from "../controllers/timeslot.controller.js";
import { timeSlotRules } from "../validators/masters.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
const ctrl = createCrudController(TimeSlot, { searchFields: ["name"] });

router.use(authenticate);
router.get("/available", authorize(PERMISSION.READ), available);
router.get("/", authorize(PERMISSION.READ), ctrl.list);
router.get("/:id", authorize(PERMISSION.READ), ctrl.get);
router.post("/", authorize(PERMISSION.WRITE), validateBody(timeSlotRules), ctrl.create);
router.put("/:id", authorize(PERMISSION.WRITE), validateBody(timeSlotRules), ctrl.update);
router.patch("/:id", authorize(PERMISSION.WRITE), validateBody(timeSlotRules, { partial: true }), ctrl.update);
router.delete("/:id", authorize(PERMISSION.DELETE), ctrl.remove);

export default router;

/**
 * @file technician.routes.js
 * @description Express routing definitions for technician roster management and availability.
 */
import { Router } from "express";
import {
  getTechnicians,
  getAvailableTechnicians,
  createTechnician,
  updateTechnician,
  toggleAvailability,
} from "../controllers/technician.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();

router.use(authenticate);

router.get("/technicians/available", getAvailableTechnicians);
router.get("/technicians", getTechnicians);
router.post("/technicians", createTechnician);
router.put("/technicians/:id", updateTechnician);
router.patch("/technicians/:id/availability", toggleAvailability);

export default router;

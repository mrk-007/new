/**
 * @file technician.routes.js
 * @description Technician CRUD, availability, and skill matrix routes.
 */
import { Router } from "express";
import * as technicianController from "../controllers/technician.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { createTechnicianRules, updateTechnicianRules, availabilityRules } from "../validators/technician.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
router.use(authenticate);
router.get("/", authorize(PERMISSION.READ), technicianController.list);
router.get("/:id", authorize(PERMISSION.READ), technicianController.get);
router.post("/", authorize(PERMISSION.WRITE), validateBody(createTechnicianRules), technicianController.create);
router.put("/:id", authorize(PERMISSION.WRITE), validateBody(updateTechnicianRules), technicianController.update);
router.patch("/:id", authorize(PERMISSION.WRITE), validateBody(updateTechnicianRules), technicianController.update);
router.delete("/:id", authorize(PERMISSION.DELETE), technicianController.remove);
router.patch("/:id/availability", authorize(PERMISSION.WRITE), validateBody(availabilityRules), technicianController.setAvailability);
router.get("/:id/skills", authorize(PERMISSION.READ), technicianController.getSkills);
router.put("/:id/skills", authorize(PERMISSION.WRITE), technicianController.putSkills);

export default router;

/**
 * @file product.routes.js
 * @description Express routing definitions for catalog products and subscription offerings.
 */
import { Router } from "express";
import {
  getProducts,
  createProduct,
  updateProduct,
  toggleActive,
} from "../controllers/product.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();

router.use(authenticate);

router.get("/products", getProducts);
router.post("/products", createProduct);
router.put("/products/:id", updateProduct);
router.patch("/products/:id/active", toggleActive);

export default router;

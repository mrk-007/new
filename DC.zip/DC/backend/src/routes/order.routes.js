/**
 * @file order.routes.js
 * @description Product order routes including confirm, cancel, and status.
 */
import { Router } from "express";
import * as orderController from "../controllers/order.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { createOrderRules, confirmOrderRules, cancelOrderRules, patchOrderStatusRules } from "../validators/order.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
router.use(authenticate);
router.post("/", authorize(PERMISSION.WRITE), validateBody(createOrderRules), orderController.create);
router.get("/", authorize(PERMISSION.READ), orderController.list);
router.get("/:id", authorize(PERMISSION.READ), orderController.get);
router.post("/:id/confirm", authorize(PERMISSION.WRITE), validateBody(confirmOrderRules), orderController.confirm);
router.post("/:id/cancel", authorize(PERMISSION.WRITE), validateBody(cancelOrderRules), orderController.cancel);
router.patch("/:id/status", authorize(PERMISSION.WRITE), validateBody(patchOrderStatusRules), orderController.patchStatus);

export default router;

/**
 * @file order.routes.js
 * @description Express routing definitions for order booking, status management, and cancellation.
 */
import { Router } from "express";
import {
  createOrder,
  getOrders,
  getOrderById,
  updateOrderStatus,
  rescheduleOrder,
  cancelOrder,
} from "../controllers/order.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();

router.use(authenticate);

router.post("/orders", createOrder);
router.get("/orders", getOrders);
router.get("/orders/:id", getOrderById);
router.patch("/orders/:id/status", updateOrderStatus);
router.patch("/orders/:id/reschedule", rescheduleOrder);
router.patch("/orders/:id/cancel", cancelOrder);

export default router;

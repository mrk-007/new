import { Router } from "express";
import {
  createOrder,
  getOrders,
  getOrderById,
  getSubscriptions,
  getSubscriptionById,
  updateSubscriptionStatus,
} from "../controllers/order.controller.js";
import { authenticate, authorize } from "../middlewares/auth.middleware.js";
import { validateRequest } from "../middlewares/validateRequest.js";
import {
  createOrderSchema,
  updateSubscriptionStatusSchema,
} from "../validators/order.validator.js";

const router = Router();

// ================= ORDERS =================
router.get("/orders", authenticate, authorize("orders", "read"), getOrders);
router.get("/orders/:id", authenticate, authorize("orders", "read"), getOrderById);
router.post(
  "/orders",
  authenticate,
  authorize("orders", "write"),
  validateRequest(createOrderSchema),
  createOrder
);

// ================= SUBSCRIPTIONS =================
router.get("/subscriptions", authenticate, authorize("subscriptions", "read"), getSubscriptions);
router.get("/subscriptions/:id", authenticate, authorize("subscriptions", "read"), getSubscriptionById);
router.patch(
  "/subscriptions/:id/status",
  authenticate,
  authorize("subscriptions", "write"),
  validateRequest(updateSubscriptionStatusSchema),
  updateSubscriptionStatus
);

export default router;

/**
 * @file jobOrder.routes.js
 * @description Route configurations for job order workflows and reassignment.
 */
import { Router } from "express";
import {
  getJobOrders,
  getJobOrderById,
  updateJobOrderStatus,
  reassignTechnician,
} from "../controllers/jobOrder.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();

router.use(authenticate);

router.get("/job-orders", getJobOrders);
router.get("/job-orders/:id", getJobOrderById);
router.patch("/job-orders/:id/status", updateJobOrderStatus);
router.patch("/job-orders/:id/reassign", reassignTechnician);

export default router;

/**
 * @file pricing.routes.js
 * @description Pricing master CRUD plus quote endpoint.
 */
import { Router } from "express";
import { Pricing } from "../models/Pricing.model.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { createCrudController } from "../controllers/crud.controller.js";
import { getQuote } from "../controllers/timeslot.controller.js";
import { pricingRules } from "../validators/masters.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
const ctrl = createCrudController(Pricing, {
  searchFields: [],
  populate: "serviceType product subscriptionPlan serviceFrequency subscriptionTerm bathroomCount propertySize",
});

router.use(authenticate);
router.get("/quote", authorize(PERMISSION.READ), getQuote);
router.get("/", authorize(PERMISSION.READ), ctrl.list);
router.get("/:id", authorize(PERMISSION.READ), ctrl.get);
router.post("/", authorize(PERMISSION.WRITE), validateBody(pricingRules), ctrl.create);
router.put("/:id", authorize(PERMISSION.WRITE), validateBody(pricingRules), ctrl.update);
router.patch("/:id", authorize(PERMISSION.WRITE), validateBody(pricingRules, { partial: true }), ctrl.update);
router.delete("/:id", authorize(PERMISSION.DELETE), ctrl.remove);

export default router;

import { Router } from "express";
import {
  getRoles,
  getRoleById,
  createRole,
  updateRole,
  deleteRole,
  getRolePermissions,
  updateRolePermissions,
  getModules,
  createModule,
  updateModule,
  getUsers,
  getUserById,
  createUser,
  updateUser,
  resetUserPassword,
  deleteUser,
} from "../controllers/rbac.controller.js";
import { authenticate, authorize } from "../middlewares/auth.middleware.js";
import { validateRequest } from "../middlewares/validateRequest.js";
import {
  createRoleSchema,
  updateRoleSchema,
  updateRolePermissionsSchema,
  createModuleSchema,
  updateModuleSchema,
  createUserSchema,
  updateUserSchema,
} from "../validators/rbac.validator.js";

const router = Router();

// ================= ROLES =================
router.get("/roles", authenticate, authorize("configuration", "read"), getRoles);
router.get("/roles/:id", authenticate, authorize("configuration", "read"), getRoleById);
router.post(
  "/roles",
  authenticate,
  authorize("configuration", "write"),
  validateRequest(createRoleSchema),
  createRole
);
router.put(
  "/roles/:id",
  authenticate,
  authorize("configuration", "write"),
  validateRequest(updateRoleSchema),
  updateRole
);
router.delete("/roles/:id", authenticate, authorize("configuration", "delete"), deleteRole);

router.get("/roles/:id/permissions", authenticate, authorize("configuration", "read"), getRolePermissions);
router.put(
  "/roles/:id/permissions",
  authenticate,
  authorize("configuration", "write"),
  validateRequest(updateRolePermissionsSchema),
  updateRolePermissions
);

// ================= MODULES =================
router.get("/modules", authenticate, authorize("configuration", "read"), getModules);
router.post(
  "/modules",
  authenticate,
  authorize("configuration", "write"),
  validateRequest(createModuleSchema),
  createModule
);
router.put(
  "/modules/:id",
  authenticate,
  authorize("configuration", "write"),
  validateRequest(updateModuleSchema),
  updateModule
);

// ================= USERS =================
router.get("/users", authenticate, authorize("configuration", "read"), getUsers);
router.get("/users/:id", authenticate, authorize("configuration", "read"), getUserById);
router.post(
  "/users",
  authenticate,
  authorize("configuration", "write"),
  validateRequest(createUserSchema),
  createUser
);
router.put(
  "/users/:id",
  authenticate,
  authorize("configuration", "write"),
  validateRequest(updateUserSchema),
  updateUser
);
router.post(
  "/users/:id/reset-password",
  authenticate,
  authorize("configuration", "write"),
  resetUserPassword
);
router.delete("/users/:id", authenticate, authorize("configuration", "delete"), deleteUser);

export default router;

/**
 * @file auth.routes.js
 * @description Authentication and user-creation routes.
 */
import { Router } from "express";
import { login, getMe, createUser } from "../controllers/auth.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { validateBody } from "../middlewares/validate.middleware.js";
import { loginRules, createUserRules } from "../validators/auth.rules.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();

router.post("/login", validateBody(loginRules), login);
router.get("/me", authenticate, getMe);
router.post("/users", authenticate, authorize(PERMISSION.WRITE), validateBody(createUserRules), createUser);

export default router;

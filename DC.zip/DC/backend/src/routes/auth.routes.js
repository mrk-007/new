/**
 * @file auth.routes.js
 * @description Express routing definitions for user authentication and session profile.
 */
import { Router } from "express";
import { login, getMe } from "../controllers/auth.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();

router.post("/login", login);
router.get("/me", authenticate, getMe);

export default router;

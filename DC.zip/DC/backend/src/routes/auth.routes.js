import { Router } from "express";
import { login, refresh, logout, getMe, changePassword } from "../controllers/auth.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { validateRequest } from "../middlewares/validateRequest.js";
import { authRateLimiter } from "../middlewares/rateLimiter.js";
import { loginSchema, refreshSchema, changePasswordSchema } from "../validators/auth.validator.js";

const router = Router();

router.post("/login", authRateLimiter, validateRequest(loginSchema), login);
router.post("/refresh", validateRequest(refreshSchema), refresh);
router.post("/logout", authenticate, logout);
router.get("/me", authenticate, getMe);
router.post("/change-password", authenticate, validateRequest(changePasswordSchema), changePassword);

export default router;

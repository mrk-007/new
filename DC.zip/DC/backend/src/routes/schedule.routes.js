/**
 * @file schedule.routes.js
 * @description Route configuration for schedule aggregation.
 */
import { Router } from "express";
import { getSchedule } from "../controllers/schedule.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();

router.use(authenticate);

router.get("/schedule", getSchedule);

export default router;

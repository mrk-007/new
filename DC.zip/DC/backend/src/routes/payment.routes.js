/**
 * @file payment.routes.js
 * @description Routes for payment listing and recording.
 */
import { Router } from "express";
import { getPayments, recordPayment } from "../controllers/payment.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";

const router = Router();
router.use(authenticate);

router.get("/payments", getPayments);
router.post("/orders/:orderId/payments", recordPayment);

export default router;

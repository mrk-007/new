/**
 * @file audit.routes.js
 * @description Read-only audit log route.
 */
import { Router } from "express";
import { list } from "../controllers/audit.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
router.get("/", authenticate, authorize(PERMISSION.READ), list);

export default router;

/**
 * @file dashboard.routes.js
 * @description Operations dashboard route.
 */
import { Router } from "express";
import { dashboard } from "../controllers/dashboard.controller.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { authorize } from "../middlewares/permission.middleware.js";
import { PERMISSION } from "../constants/index.js";

const router = Router();
router.get("/", authenticate, authorize(PERMISSION.READ), dashboard);

export default router;

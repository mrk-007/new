/**
 * @file dashboard.routes.js
 * @description Express routing definitions for operations dashboard queries.
 */
import { Router } from "express";
import { getDashboard } from "../controllers/dashboard.controller.js";

const router = Router();

router.get("/dashboard", getDashboard);

export default router;

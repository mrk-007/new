import { asyncHandler } from "../utils/asyncHandler.js";
import { sendSuccess } from "../utils/responseHelper.js";
import { CatalogService } from "../services/catalog.service.js";

export const getCatalog = asyncHandler(async (req, res) => {
  const products = await CatalogService.getCatalog(req.query);
  return sendSuccess(res, { data: products });
});

export const getProductById = asyncHandler(async (req, res) => {
  const product = await CatalogService.getProductById(req.params.id);
  return sendSuccess(res, { data: product });
});

export const calculateQuote = asyncHandler(async (req, res) => {
  const quote = await CatalogService.calculateQuote(req.body);
  return sendSuccess(res, {
    message: "Quote calculation generated.",
    data: quote,
  });
});

import { asyncHandler } from "../utils/asyncHandler.js";
import { sendSuccess } from "../utils/responseHelper.js";
import { MasterBootstrapService } from "../services/masterBootstrap.service.js";

/**
 * Controller to fetch all UI dropdowns and configurations in one call.
 */
export const getBootstrap = asyncHandler(async (_req, res) => {
  const data = await MasterBootstrapService.getBootstrapData();
  return sendSuccess(res, {
    message: "Master bootstrap dataset retrieved successfully.",
    data,
  });
});

/**
 * Controller to fetch individual master resource by its slug/name.
 */
export const getMasterByName = asyncHandler(async (req, res) => {
  const items = await MasterBootstrapService.getMasterByName(req.params.name);
  return sendSuccess(res, {
    message: `Master collection '${req.params.name}' retrieved.`,
    data: items,
  });
});

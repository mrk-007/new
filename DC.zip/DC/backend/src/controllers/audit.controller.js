/**
 * @file audit.controller.js
 * @description Read-only audit log listing.
 */
import { AuditLog } from "../models/AuditLog.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { parsePagination, buildMeta } from "../utils/pagination.js";
import { toDateTime, endOfDay } from "../utils/time.js";
import { ok } from "./crud.controller.js";

/** Lists audit rows with entity, actor, action, and date filters. */
export const list = asyncHandler(async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query);
  const filter = {};
  if (req.query.entity) filter.entity = req.query.entity;
  if (req.query.entityId) filter.entityId = req.query.entityId;
  if (req.query.action) filter.action = req.query.action;
  if (req.query.performedBy) filter.performedBy = req.query.performedBy;
  if (req.query.from || req.query.to) {
    filter.createdAt = {};
    if (req.query.from) filter.createdAt.$gte = toDateTime(req.query.from, "00:00");
    if (req.query.to) filter.createdAt.$lt = endOfDay(toDateTime(req.query.to, "00:00"));
  }
  const [items, total] = await Promise.all([
    AuditLog.find(filter).populate("performedBy", "email").sort({ createdAt: -1 }).skip(skip).limit(limit),
    AuditLog.countDocuments(filter),
  ]);
  ok(res, items, { meta: buildMeta(total, page, limit) });
});

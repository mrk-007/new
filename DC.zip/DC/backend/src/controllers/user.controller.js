/**
 * @file user.controller.js
 * @description HTTP handlers for user list/get/update/soft-delete.
 */
import { User } from "../models/User.model.js";
import { createCrudController } from "./crud.controller.js";

export const { list, get, update, remove } = createCrudController(User, {
  searchFields: ["email"],
  populate: "role",
});

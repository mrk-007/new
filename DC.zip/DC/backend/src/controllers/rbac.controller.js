import { asyncHandler } from "../utils/asyncHandler.js";
import { sendSuccess, sendCreated, sendPaginated } from "../utils/responseHelper.js";
import { RbacService } from "../services/rbac.service.js";

// ================= ROLES =================
export const getRoles = asyncHandler(async (_req, res) => {
  const roles = await RbacService.getRoles();
  return sendSuccess(res, { data: roles });
});

export const getRoleById = asyncHandler(async (req, res) => {
  const role = await RbacService.getRoleById(req.params.id);
  return sendSuccess(res, { data: role });
});

export const createRole = asyncHandler(async (req, res) => {
  const role = await RbacService.createRole(req.body, req.user._id);
  return sendCreated(res, { message: "Role created successfully.", data: role });
});

export const updateRole = asyncHandler(async (req, res) => {
  const role = await RbacService.updateRole(req.params.id, req.body, req.user._id);
  return sendSuccess(res, { message: "Role updated successfully.", data: role });
});

export const deleteRole = asyncHandler(async (req, res) => {
  await RbacService.deleteRole(req.params.id, req.user._id);
  return sendSuccess(res, { message: "Role deleted successfully." });
});

// ================= ROLE PERMISSIONS =================
export const getRolePermissions = asyncHandler(async (req, res) => {
  const result = await RbacService.getRolePermissions(req.params.id);
  return sendSuccess(res, { data: result });
});

export const updateRolePermissions = asyncHandler(async (req, res) => {
  const result = await RbacService.updateRolePermissions(
    req.params.id,
    req.body.permissions,
    req.user._id
  );
  return sendSuccess(res, { message: "Permissions updated successfully.", data: result });
});

// ================= MODULES =================
export const getModules = asyncHandler(async (_req, res) => {
  const modules = await RbacService.getModules();
  return sendSuccess(res, { data: modules });
});

export const createModule = asyncHandler(async (req, res) => {
  const moduleDoc = await RbacService.createModule(req.body, req.user._id);
  return sendCreated(res, { message: "Module registered successfully.", data: moduleDoc });
});

export const updateModule = asyncHandler(async (req, res) => {
  const moduleDoc = await RbacService.updateModule(req.params.id, req.body, req.user._id);
  return sendSuccess(res, { message: "Module updated successfully.", data: moduleDoc });
});

// ================= USERS =================
export const getUsers = asyncHandler(async (req, res) => {
  const { users, pagination } = await RbacService.getUsers(req.query);
  return sendPaginated(res, { data: users, pagination });
});

export const getUserById = asyncHandler(async (req, res) => {
  const user = await RbacService.getUserById(req.params.id);
  return sendSuccess(res, { data: user });
});

export const createUser = asyncHandler(async (req, res) => {
  const user = await RbacService.createUser(req.body, req.user._id);
  return sendCreated(res, { message: "User account created.", data: user });
});

export const updateUser = asyncHandler(async (req, res) => {
  const user = await RbacService.updateUser(req.params.id, req.body, req.user._id);
  return sendSuccess(res, { message: "User account updated.", data: user });
});

export const resetUserPassword = asyncHandler(async (req, res) => {
  const { newPassword } = req.body;
  await RbacService.resetUserPassword(req.params.id, newPassword, req.user._id);
  return sendSuccess(res, { message: "User password reset successfully." });
});

export const deleteUser = asyncHandler(async (req, res) => {
  await RbacService.deleteUser(req.params.id, req.user._id);
  return sendSuccess(res, { message: "User account deactivated." });
});

/**
 * @file timeslot.controller.js
 * @description HTTP handlers for generated available slots and pricing quotes.
 */
import { asyncHandler } from "../utils/asyncHandler.js";
import { listAvailableSlots } from "../services/timeslot.service.js";
import { quote } from "../services/pricing.service.js";
import { ok } from "./crud.controller.js";

/** Returns generated slots for a date and service combination. */
export const available = asyncHandler(async (req, res) => {
  const slots = await listAvailableSlots(req.query);
  ok(res, slots);
});

/** Returns a price plus tax breakdown. */
export const getQuote = asyncHandler(async (req, res) => {
  const result = await quote(req.query);
  ok(res, result);
});

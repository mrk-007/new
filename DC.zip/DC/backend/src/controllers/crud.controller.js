/**
 * @file crud.controller.js
 * @description Factory that builds list/get/create/update/soft-delete handlers for a model.
 */
import { asyncHandler } from "../utils/asyncHandler.js";
import * as crud from "../services/crud.service.js";

/** Sends a success envelope. */
export const ok = (res, data, { status = 200, message, meta } = {}) => {
  const body = { success: true, data };
  if (message) body.message = message;
  if (meta) body.meta = meta;
  return res.status(status).json(body);
};

/** Builds CRUD handlers for a Mongoose model. */
export const createCrudController = (Model, { searchFields = ["name"], populate = "" } = {}) => ({
  list: asyncHandler(async (req, res) => {
    const { items, meta } = await crud.list(Model, req, { searchFields, populate });
    ok(res, items, { meta });
  }),
  get: asyncHandler(async (req, res) => {
    const doc = await crud.getById(Model, req.params.id, populate);
    ok(res, doc);
  }),
  create: asyncHandler(async (req, res) => {
    const doc = await crud.create(Model, req.body, req);
    ok(res, doc, { status: 201, message: `${Model.modelName} created.` });
  }),
  update: asyncHandler(async (req, res) => {
    const doc = await crud.update(Model, req.params.id, req.body, req);
    ok(res, doc, { message: `${Model.modelName} updated.` });
  }),
  remove: asyncHandler(async (req, res) => {
    const doc = await crud.softDelete(Model, req.params.id, req);
    ok(res, doc, { message: `${Model.modelName} deactivated.` });
  }),
});

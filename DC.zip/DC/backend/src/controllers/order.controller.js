/**
 * @file order.controller.js
 * @description HTTP handlers for product orders.
 */
import { asyncHandler } from "../utils/asyncHandler.js";
import * as orderService from "../services/order.service.js";
import { ok } from "./crud.controller.js";

/** Creates an order and schedules its first visit. */
export const create = asyncHandler(async (req, res) => {
  const result = await orderService.createOrder(req.body, req);
  ok(res, result, { status: 201, message: "Order created." });
});

/** Lists orders. */
export const list = asyncHandler(async (req, res) => {
  const { items, meta } = await orderService.listOrders(req);
  ok(res, items, { meta });
});

/** Returns one order with visits. */
export const get = asyncHandler(async (req, res) => {
  const result = await orderService.getOrder(req.params.id);
  ok(res, result);
});

/** Confirms a quoted order and creates the service visit. */
export const confirm = asyncHandler(async (req, res) => {
  const result = await orderService.confirmOrder(req.params.id, req);
  ok(res, result, { message: "Order confirmed." });
});

/** Cancels an order. */
export const cancel = asyncHandler(async (req, res) => {
  const order = await orderService.cancelOrder(req.params.id, req);
  ok(res, order, { message: "Order cancelled." });
});

/** Patches order status. */
export const patchStatus = asyncHandler(async (req, res) => {
  const order = await orderService.patchStatus(req.params.id, req);
  ok(res, order, { message: "Order status updated." });
});

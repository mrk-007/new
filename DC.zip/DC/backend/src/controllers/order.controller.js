/**
 * @file order.controller.js
 * @description Controller managing order bookings, status updates, rescheduling, and cancellations.
 */
import { Order } from "../models/Order.model.js";
import { JobOrder } from "../models/JobOrder.model.js";
import { Product } from "../models/Product.model.js";
import { Technician } from "../models/Technician.model.js";
import { Subscription } from "../models/Subscription.model.js";
import { Payment } from "../models/Payment.model.js";
import { requireFields } from "../middlewares/validate.middleware.js";

/**
 * Creates a new order and corresponding job order from booking stepper submission.
 */
export const createOrder = async (req, res, next) => {
  try {
    requireFields(req.body, ["customer", "product", "technician", "serviceDate", "timeSlot"]);
    const { customer, product, technician, serviceDate, timeSlot, notes = "" } = req.body;

    const targetDate = new Date(serviceDate);
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);

    // Business Rule: No bookings in the past
    if (targetDate < todayStart) {
      return res.status(400).json({
        success: false,
        message: "Validation Error: Cannot schedule bookings for past dates.",
      });
    }

    const dayStart = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      0,
      0,
      0,
      0
    );
    const dayEnd = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      23,
      59,
      59,
      999
    );

    // Business Rule: Technician cannot hold two jobs in the same date and slot
    const conflictJob = await JobOrder.findOne({
      technician,
      serviceDate: { $gte: dayStart, $lte: dayEnd },
      timeSlot,
      workStatus: { $ne: "CLOSED" },
    });

    if (conflictJob) {
      return res.status(400).json({
        success: false,
        message: "Conflict: The chosen technician is already booked for this date and time slot.",
      });
    }

    const productDoc = await Product.findById(product);
    if (!productDoc) {
      return res.status(404).json({ success: false, message: "Product not found." });
    }

    // Business Rule: Auto-generate orderId as ORD-<running number>
    const orderCount = await Order.countDocuments();
    const orderId = `ORD-${String(1001 + orderCount).padStart(5, "0")}`;

    const order = await Order.create({
      orderId,
      customer,
      product,
      technician,
      serviceDate: targetDate,
      timeSlot,
      orderStatus: "CONFIRMED",
      paymentStatus: "UNPAID",
      amount: productDoc.price,
      paidAmount: 0,
      notes,
    });

    const jobOrder = await JobOrder.create({
      order: order._id,
      customer,
      work: productDoc.name,
      technician,
      serviceDate: targetDate,
      timeSlot,
      arrivalStatus: "ON_TIME",
      arrivalDelayMinutes: 0,
      workStatus: "ASSIGNED",
      followUpStatus: "NONE",
    });

    // If subscription service, register subscription record
    if (productDoc.group === "Subscription") {
      await Subscription.create({
        customer,
        product,
        status: "ACTIVE",
        startDate: targetDate,
      });
    }

    res.status(201).json({
      success: true,
      data: {
        order,
        jobOrder,
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Returns filtered and paginated orders with customer, product, and technician population.
 */
export const getOrders = async (req, res, next) => {
  try {
    const {
      search = "",
      status,
      paymentStatus,
      dateFrom,
      dateTo,
      technician,
      page = 1,
      limit = 10,
    } = req.query;

    const pageNum = Math.max(1, parseInt(page, 10));
    const limitNum = Math.max(1, parseInt(limit, 10));
    const skip = (pageNum - 1) * limitNum;

    const filter = {};

    if (status) {
      filter.orderStatus = status;
    }

    if (paymentStatus) {
      filter.paymentStatus = paymentStatus;
    }

    if (technician) {
      filter.technician = technician;
    }

    if (dateFrom || dateTo) {
      filter.serviceDate = {};
      if (dateFrom) filter.serviceDate.$gte = new Date(dateFrom);
      if (dateTo) filter.serviceDate.$lte = new Date(dateTo);
    }

    if (search) {
      filter.$or = [{ orderId: new RegExp(search, "i") }, { notes: new RegExp(search, "i") }];
    }

    const [orders, total] = await Promise.all([
      Order.find(filter)
        .populate("customer")
        .populate("product")
        .populate("technician")
        .sort({ serviceDate: -1, createdAt: -1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      Order.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: {
        orders,
        total,
        page: pageNum,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Returns complete order details including associated payments and job orders.
 */
export const getOrderById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const [order, payments, jobOrders] = await Promise.all([
      Order.findById(id)
        .populate("customer")
        .populate("product")
        .populate("technician")
        .lean(),
      Payment.find({ order: id }).sort({ paidAt: -1 }).lean(),
      JobOrder.find({ order: id }).populate("technician").lean(),
    ]);

    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found." });
    }

    res.status(200).json({
      success: true,
      data: {
        order,
        payments,
        jobOrders,
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Updates order operational status.
 */
export const updateOrderStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { orderStatus } = req.body;
    requireFields(req.body, ["orderStatus"]);

    const order = await Order.findByIdAndUpdate(
      id,
      { orderStatus },
      { new: true, runValidators: true }
    )
      .populate("customer")
      .populate("product")
      .populate("technician");

    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found." });
    }

    res.status(200).json({
      success: true,
      data: order,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Reschedules service visit date, time slot, and technician with conflict verification.
 */
export const rescheduleOrder = async (req, res, next) => {
  try {
    const { id } = req.params;
    requireFields(req.body, ["serviceDate", "timeSlot", "technician"]);
    const { serviceDate, timeSlot, technician } = req.body;

    const order = await Order.findById(id);
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found." });
    }

    // Business Rule: Cancelled orders cannot be rescheduled
    if (order.orderStatus === "CANCELLED") {
      return res.status(400).json({
        success: false,
        message: "Invalid Action: Cancelled orders cannot be rescheduled.",
      });
    }

    const targetDate = new Date(serviceDate);
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);

    // Business Rule: No past dates
    if (targetDate < todayStart) {
      return res.status(400).json({
        success: false,
        message: "Cannot reschedule to a past date.",
      });
    }

    const dayStart = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      0,
      0,
      0,
      0
    );
    const dayEnd = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      23,
      59,
      59,
      999
    );

    // Business Rule: Technician cannot hold two jobs in the same date and slot
    const conflict = await JobOrder.findOne({
      order: { $ne: order._id },
      technician,
      serviceDate: { $gte: dayStart, $lte: dayEnd },
      timeSlot,
      workStatus: { $ne: "CLOSED" },
    });

    if (conflict) {
      return res.status(400).json({
        success: false,
        message: "Technician is busy in that time slot. Please choose another technician or slot.",
      });
    }

    order.serviceDate = targetDate;
    order.timeSlot = timeSlot;
    order.technician = technician;
    order.orderStatus = "RESCHEDULED";
    await order.save();

    await JobOrder.findOneAndUpdate(
      { order: order._id },
      {
        serviceDate: targetDate,
        timeSlot,
        technician,
        arrivalStatus: "ON_TIME",
        arrivalDelayMinutes: 0,
      }
    );

    const updated = await Order.findById(id)
      .populate("customer")
      .populate("product")
      .populate("technician");

    res.status(200).json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Cancels an order with mandatory reason and closes associated job order.
 */
export const cancelOrder = async (req, res, next) => {
  try {
    const { id } = req.params;
    requireFields(req.body, ["cancelReason"]);
    const { cancelReason } = req.body;

    const order = await Order.findById(id);
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found." });
    }

    order.orderStatus = "CANCELLED";
    order.cancelReason = cancelReason;
    await order.save();

    await JobOrder.updateMany(
      { order: order._id },
      { workStatus: "CLOSED" }
    );

    const updated = await Order.findById(id)
      .populate("customer")
      .populate("product")
      .populate("technician");

    res.status(200).json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
};

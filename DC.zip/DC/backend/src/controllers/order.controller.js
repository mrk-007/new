import { asyncHandler } from "../utils/asyncHandler.js";
import { sendSuccess, sendCreated, sendPaginated } from "../utils/responseHelper.js";
import { OrderService } from "../services/order.service.js";

export const createOrder = asyncHandler(async (req, res) => {
  const result = await OrderService.createOrder(req.body, req.user?._id || null);
  return sendCreated(res, {
    message: "Order confirmed successfully. Invoice and Job Orders created.",
    data: result,
  });
});

export const getOrders = asyncHandler(async (req, res) => {
  const { orders, pagination } = await OrderService.getOrders(req.query);
  return sendPaginated(res, { data: orders, pagination });
});

export const getOrderById = asyncHandler(async (req, res) => {
  const order = await OrderService.getOrderById(req.params.id);
  return sendSuccess(res, { data: order });
});

export const getSubscriptions = asyncHandler(async (req, res) => {
  const { subscriptions, pagination } = await OrderService.getSubscriptions(req.query);
  return sendPaginated(res, { data: subscriptions, pagination });
});

export const getSubscriptionById = asyncHandler(async (req, res) => {
  const sub = await OrderService.getSubscriptionById(req.params.id);
  return sendSuccess(res, { data: sub });
});

export const updateSubscriptionStatus = asyncHandler(async (req, res) => {
  const sub = await OrderService.updateSubscriptionStatus(
    req.params.id,
    req.body.status,
    req.user?._id || null
  );
  return sendSuccess(res, {
    message: "Subscription status updated.",
    data: sub,
  });
});

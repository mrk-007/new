import { asyncHandler } from "../utils/asyncHandler.js";
import { sendSuccess, sendCreated, sendPaginated } from "../utils/responseHelper.js";

/**
 * Generic Controller Factory for Master Data resources.
 *
 * @param {object} service - Instantiated Master Data Service
 * @param {string} resourceName - Name of the resource for response messages
 */
export const createMasterController = (service, resourceName = "Resource") => {
  return {
    getAll: asyncHandler(async (req, res) => {
      // If page or limit query parameters are provided, return paginated results
      if (req.query.page || req.query.limit || req.query.search) {
        const { items, pagination } = await service.getPaginated(req.query);
        return sendPaginated(res, { data: items, pagination });
      }

      const items = await service.getAll(req.query);
      return sendSuccess(res, { data: items });
    }),

    getById: asyncHandler(async (req, res) => {
      const item = await service.getById(req.params.id);
      return sendSuccess(res, { data: item });
    }),

    create: asyncHandler(async (req, res) => {
      const item = await service.create(req.body, req.user?._id || null);
      return sendCreated(res, {
        message: `${resourceName} created successfully.`,
        data: item,
      });
    }),

    update: asyncHandler(async (req, res) => {
      const item = await service.update(req.params.id, req.body, req.user?._id || null);
      return sendSuccess(res, {
        message: `${resourceName} updated successfully.`,
        data: item,
      });
    }),

    toggleStatus: asyncHandler(async (req, res) => {
      const item = await service.toggleStatus(req.params.id, req.user?._id || null);
      return sendSuccess(res, {
        message: `${resourceName} status toggled successfully.`,
        data: item,
      });
    }),

    delete: asyncHandler(async (req, res) => {
      await service.delete(req.params.id, req.user?._id || null);
      return sendSuccess(res, {
        message: `${resourceName} deleted successfully.`,
      });
    }),
  };
};

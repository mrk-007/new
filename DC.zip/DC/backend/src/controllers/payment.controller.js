/**
 * @file payment.controller.js
 * @description Controller handling payment records and order payment updates.
 */
import { Payment } from "../models/Payment.model.js";
import { Order } from "../models/Order.model.js";
import { requireFields } from "../middlewares/validate.middleware.js";

/**
 * Retrieves payments with optional filters.
 */
export const getPayments = async (req, res, next) => {
  try {
    const { order, paymentStatus, page = 1, limit = 10 } = req.query;
    const pageNum = Math.max(1, parseInt(page, 10));
    const limitNum = Math.max(1, parseInt(limit, 10));
    const skip = (pageNum - 1) * limitNum;
    const filter = {};
    if (order) filter.order = order;
    if (paymentStatus) filter.paymentStatus = paymentStatus;

    const [payments, total] = await Promise.all([
      Payment.find(filter)
        .populate("order")
        .sort({ paidAt: -1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      Payment.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: { payments, total, page: pageNum, totalPages: Math.ceil(total / limitNum) },
    });
  } catch (e) {
    next(e);
  }
};

/**
 * Records a payment for an order, updates paidAmount and paymentStatus.
 */
export const recordPayment = async (req, res, next) => {
  try {
    requireFields(req.body, ["order", "amount", "method", "paidAt"]);
    const { order, amount, method, paidAt, notes = "" } = req.body;
    // Create payment record
    const payment = await Payment.create({ order, amount, method, paidAt, notes });
    // Update order aggregates
    const orderDoc = await Order.findById(order);
    if (orderDoc) {
      orderDoc.paidAmount = (orderDoc.paidAmount || 0) + amount;
      // Derive payment status
      if (orderDoc.paidAmount >= orderDoc.amount) {
        orderDoc.paymentStatus = "PAID";
      } else if (orderDoc.paidAmount > 0) {
        orderDoc.paymentStatus = "PARTIALLY_PAID";
      } else {
        orderDoc.paymentStatus = "UNPAID";
      }
      await orderDoc.save();
    }
    const populated = await Payment.findById(payment._id).populate("order");
    res.status(201).json({ success: true, data: populated });
  } catch (e) {
    next(e);
  }
};

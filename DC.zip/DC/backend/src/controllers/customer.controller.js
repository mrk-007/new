/**
 * @file customer.controller.js
 * @description HTTP handlers for customers and nested addresses.
 */
import { Customer } from "../models/Customer.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { createCrudController, ok } from "./crud.controller.js";
import * as customerService from "../services/customer.service.js";
const base = createCrudController(Customer, { searchFields: ["fullName", "mobile", "email"] });

export const list = base.list;
export const get = base.get;
export const create = base.create;
export const update = base.update;
export const remove = base.remove;

/** Lists addresses for a customer. */
export const listAddresses = asyncHandler(async (req, res) => {
  const items = await customerService.listAddresses(req.params.id, req.query);
  ok(res, items);
});

/** Creates an address for a customer. */
export const createAddress = asyncHandler(async (req, res) => {
  const address = await customerService.createAddress(req.params.id, req.body, req);
  ok(res, address, { status: 201, message: "Address created." });
});

/** Updates an address. */
export const updateAddress = asyncHandler(async (req, res) => {
  const address = await customerService.updateAddress(req.params.id, req.body, req);
  ok(res, address, { message: "Address updated." });
});

/** Soft-deletes an address. */
export const removeAddress = asyncHandler(async (req, res) => {
  const address = await customerService.softDeleteAddress(req.params.id, req);
  ok(res, address, { message: "Address deactivated." });
});

/** Marks an address as default. */
export const setDefault = asyncHandler(async (req, res) => {
  const address = await customerService.setDefaultAddress(req.params.id, req);
  ok(res, address, { message: "Default address updated." });
});

import { asyncHandler } from "../utils/asyncHandler.js";
import { sendSuccess, sendCreated, sendPaginated } from "../utils/responseHelper.js";
import { CustomerService } from "../services/customer.service.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";

export const getCustomers = asyncHandler(async (req, res) => {
  const { customers, pagination } = await CustomerService.getCustomers(req.query);
  return sendPaginated(res, { data: customers, pagination });
});

export const getCustomerById = asyncHandler(async (req, res) => {
  const customer = await CustomerService.getCustomerById(req.params.id);
  return sendSuccess(res, { data: customer });
});

export const createCustomer = asyncHandler(async (req, res) => {
  const customer = await CustomerService.createCustomer(req.body, req.user?._id || null);
  return sendCreated(res, {
    message: "Customer created successfully.",
    data: customer,
  });
});

export const updateCustomer = asyncHandler(async (req, res) => {
  const customer = await CustomerService.updateCustomer(req.params.id, req.body, req.user?._id || null);
  return sendSuccess(res, {
    message: "Customer updated successfully.",
    data: customer,
  });
});

export const deleteCustomer = asyncHandler(async (req, res) => {
  await CustomerService.deleteCustomer(req.params.id, req.user?._id || null);
  return sendSuccess(res, {
    message: "Customer deleted successfully.",
  });
});

export const addProperty = asyncHandler(async (req, res) => {
  const property = await CustomerService.addCustomerProperty(
    req.params.id,
    req.body,
    req.user?._id || null
  );
  return sendCreated(res, {
    message: "Property added successfully.",
    data: property,
  });
});

export const getCustomer360 = asyncHandler(async (req, res) => {
  const data = await CustomerService.getCustomer360(req.params.id);
  return sendSuccess(res, {
    message: "Customer 360 profile retrieved.",
    data,
  });
});

export const exportCustomerCsv = asyncHandler(async (req, res) => {
  const csvData = await CustomerService.exportCustomerCsv(req.params.id);
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="customer-${req.params.id}.csv"`);
  return res.status(HTTP_STATUS.OK).send(csvData);
});

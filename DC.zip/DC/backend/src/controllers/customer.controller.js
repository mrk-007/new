/**
 * @file customer.controller.js
 * @description Controller managing customer directory, search pagination, and 360 profile history.
 */
import { Customer } from "../models/Customer.model.js";
import { Order } from "../models/Order.model.js";
import { Subscription } from "../models/Subscription.model.js";
import { requireFields } from "../middlewares/validate.middleware.js";

/**
 * Returns paginated customer directory with text search across name, mobile, and property.
 */
export const getCustomers = async (req, res, next) => {
  try {
    const { search = "", page = 1, limit = 10 } = req.query;
    const pageNum = Math.max(1, parseInt(page, 10));
    const limitNum = Math.max(1, parseInt(limit, 10));
    const skip = (pageNum - 1) * limitNum;

    const filter = {};
    if (search) {
      const regex = new RegExp(search, "i");
      filter.$or = [
        { name: regex },
        { mobile: regex },
        { email: regex },
        { "property.name": regex },
      ];
    }

    const [customers, total] = await Promise.all([
      Customer.find(filter)
        .sort({ name: 1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      Customer.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: {
        customers,
        total,
        page: pageNum,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Returns detailed customer profile including past orders and active subscriptions.
 */
export const getCustomerById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const customer = await Customer.findById(id).lean();
    if (!customer) {
      return res.status(404).json({ success: false, message: "Customer not found." });
    }

    const [orders, subscriptions] = await Promise.all([
      Order.find({ customer: id })
        .populate("product")
        .populate("technician")
        .sort({ serviceDate: -1 })
        .lean(),
      Subscription.find({ customer: id })
        .populate("product")
        .sort({ startDate: -1 })
        .lean(),
    ]);

    res.status(200).json({
      success: true,
      data: {
        customer,
        orders,
        subscriptions,
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Creates a new customer record with property details.
 */
export const createCustomer = async (req, res, next) => {
  try {
    requireFields(req.body, ["name", "mobile", "property"]);
    const { name, mobile, email = "", property } = req.body;
    requireFields(property, ["name", "address"]);

    const customer = await Customer.create({
      name,
      mobile,
      email,
      property: {
        name: property.name,
        address: property.address,
      },
    });

    res.status(201).json({
      success: true,
      data: customer,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Updates an existing customer profile and address.
 */
export const updateCustomer = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { name, mobile, email, property } = req.body;

    const updateData = {};
    if (name) updateData.name = name;
    if (mobile) updateData.mobile = mobile;
    if (email !== undefined) updateData.email = email;
    if (property) {
      updateData.property = {
        name: property.name,
        address: property.address,
      };
    }

    const customer = await Customer.findByIdAndUpdate(id, updateData, {
      new: true,
      runValidators: true,
    });

    if (!customer) {
      return res.status(404).json({ success: false, message: "Customer not found." });
    }

    res.status(200).json({
      success: true,
      data: customer,
    });
  } catch (error) {
    next(error);
  }
};

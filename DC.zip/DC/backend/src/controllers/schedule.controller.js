/**
 * @file schedule.controller.js
 * @description Controller generating time-slot grouped schedules for date-specific operations.
 */
import { JobOrder } from "../models/JobOrder.model.js";
import { Master } from "../models/Master.model.js";

/**
 * Returns jobs for a selected day grouped by time slot.
 */
export const getSchedule = async (req, res, next) => {
  try {
    const { date } = req.query;
    const targetDate = date ? new Date(date) : new Date();

    const startOfDay = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      0,
      0,
      0,
      0
    );
    const endOfDay = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      23,
      59,
      59,
      999
    );

    const [slots, jobs] = await Promise.all([
      Master.find({ type: "time_slot" }).sort({ order: 1 }).lean(),
      JobOrder.find({
        serviceDate: { $gte: startOfDay, $lte: endOfDay },
      })
        .populate("order")
        .populate("customer")
        .populate("technician")
        .lean(),
    ]);

    const slotMap = {};
    slots.forEach((s) => {
      slotMap[s.label] = {
        slot: s,
        jobs: [],
      };
    });

    const unassignedSlotJobs = [];

    jobs.forEach((job) => {
      if (job.timeSlot && slotMap[job.timeSlot]) {
        slotMap[job.timeSlot].jobs.push(job);
      } else {
        unassignedSlotJobs.push(job);
      }
    });

    const schedule = slots.map((s) => ({
      slot: s.label,
      slotInfo: s,
      jobs: slotMap[s.label] ? slotMap[s.label].jobs : [],
    }));

    if (unassignedSlotJobs.length > 0) {
      schedule.push({
        slot: "Other / Unassigned Slot",
        slotInfo: { label: "Other", code: "OTHER" },
        jobs: unassignedSlotJobs,
      });
    }

    res.status(200).json({
      success: true,
      data: {
        date: targetDate.toISOString().split("T")[0],
        schedule,
      },
    });
  } catch (error) {
    next(error);
  }
};

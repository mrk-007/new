import mongoose from "mongoose";
import { asyncHandler } from "../utils/asyncHandler.js";
import { sendSuccess } from "../utils/responseHelper.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";
import { RESPONSE_MESSAGES } from "../constants/responseMessages.js";
import { env } from "../config/env.js";

/**
 * Health check controller to report system status, memory, uptime, and DB connectivity.
 */
export const checkHealth = asyncHandler(async (_req, res) => {
  const dbStateMap = {
    0: "Disconnected",
    1: "Connected",
    2: "Connecting",
    3: "Disconnecting",
  };

  const dbStatus = dbStateMap[mongoose.connection.readyState] || "Unknown";
  const isHealthy = mongoose.connection.readyState === 1;

  const memory = process.memoryUsage();
  const healthData = {
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    environment: env.NODE_ENV,
    database: {
      status: dbStatus,
      host: mongoose.connection.host || null,
      name: mongoose.connection.name || null,
    },
    memory: {
      rssMb: Math.round((memory.rss / 1024 / 1024) * 100) / 100,
      heapTotalMb: Math.round((memory.heapTotal / 1024 / 1024) * 100) / 100,
      heapUsedMb: Math.round((memory.heapUsed / 1024 / 1024) * 100) / 100,
    },
  };

  return sendSuccess(res, {
    statusCode: isHealthy ? HTTP_STATUS.OK : HTTP_STATUS.SERVICE_UNAVAILABLE,
    message: isHealthy ? RESPONSE_MESSAGES.HEALTH_OK : "System degraded: Database not connected",
    data: healthData,
  });
});

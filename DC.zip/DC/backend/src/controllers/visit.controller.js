/**
 * @file visit.controller.js
 * @description HTTP handlers for visit lifecycle and allocation.
 */
import { Visit } from "../models/Visit.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import * as visitService from "../services/visit.service.js";
import { getById } from "../services/crud.service.js";
import { ok } from "./crud.controller.js";

/** Lists visits with filters. */
export const list = asyncHandler(async (req, res) => {
  const { items, meta } = await visitService.listVisits(req);
  ok(res, items, { meta });
});

/** Lists visits for the logged-in technician. */
export const mine = asyncHandler(async (req, res) => {
  const { items, meta } = await visitService.listMine(req);
  ok(res, items, { meta });
});

/** Returns one visit. */
export const get = asyncHandler(async (req, res) => {
  const visit = await getById(Visit, req.params.id, "customer address order subscription");
  ok(res, visit);
});

/** Starts a visit. */
export const start = asyncHandler(async (req, res) => {
  const visit = await visitService.startVisit(req.params.id, req);
  ok(res, visit, { message: "Visit started." });
});

/** Completes a visit, optionally with a site report. */
export const complete = asyncHandler(async (req, res) => {
  const result = await visitService.completeVisit(req.params.id, req);
  ok(res, result, { message: "Visit completed." });
});

/** Cancels a visit. */
export const cancel = asyncHandler(async (req, res) => {
  const visit = await visitService.cancelVisit(req.params.id, req);
  ok(res, visit, { message: "Visit cancelled." });
});

/** Retries technician allocation. */
export const allocate = asyncHandler(async (req, res) => {
  const allocation = await visitService.retryAllocate(req.params.id, req);
  ok(res, allocation, { message: "Visit allocated." });
});

/** Reassigns the visit technician. */
export const reassign = asyncHandler(async (req, res) => {
  const allocation = await visitService.reassign(req.params.id, req);
  ok(res, allocation, { message: "Visit reassigned." });
});

/**
 * @file jobOrder.controller.js
 * @description Controller managing job orders, technician reassignment, status workflow, and delay tracking.
 */
import { JobOrder } from "../models/JobOrder.model.js";
import { Order } from "../models/Order.model.js";
import { requireFields } from "../middlewares/validate.middleware.js";

/**
 * Returns filtered and paginated job orders.
 */
export const getJobOrders = async (req, res, next) => {
  try {
    const {
      search = "",
      workStatus,
      arrivalStatus,
      technician,
      serviceDate,
      page = 1,
      limit = 10,
    } = req.query;

    const pageNum = Math.max(1, parseInt(page, 10));
    const limitNum = Math.max(1, parseInt(limit, 10));
    const skip = (pageNum - 1) * limitNum;

    const filter = {};

    if (workStatus) {
      filter.workStatus = workStatus;
    }

    if (arrivalStatus) {
      filter.arrivalStatus = arrivalStatus;
    }

    if (technician) {
      filter.technician = technician;
    }

    if (serviceDate) {
      const d = new Date(serviceDate);
      const start = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, 0, 0, 0);
      const end = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);
      filter.serviceDate = { $gte: start, $lte: end };
    }

    if (search) {
      filter.work = new RegExp(search, "i");
    }

    const [jobOrders, total] = await Promise.all([
      JobOrder.find(filter)
        .populate("order")
        .populate("customer")
        .populate("technician")
        .sort({ serviceDate: -1, createdAt: -1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      JobOrder.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: {
        jobOrders,
        total,
        page: pageNum,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Returns details for a specific job order.
 */
export const getJobOrderById = async (req, res, next) => {
  try {
    const { id } = req.params;
    const jobOrder = await JobOrder.findById(id)
      .populate("order")
      .populate("customer")
      .populate("technician")
      .lean();

    if (!jobOrder) {
      return res.status(404).json({ success: false, message: "Job order not found." });
    }

    res.status(200).json({
      success: true,
      data: jobOrder,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Updates status and handles lifecycle transitions for a job order.
 */
export const updateJobOrderStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { workStatus, arrivalStatus, arrivalDelayMinutes, followUpStatus } = req.body;

    const updates = {};
    if (workStatus !== undefined) updates.workStatus = workStatus;
    if (arrivalStatus !== undefined) updates.arrivalStatus = arrivalStatus;
    if (arrivalDelayMinutes !== undefined) updates.arrivalDelayMinutes = arrivalDelayMinutes;
    if (followUpStatus !== undefined) updates.followUpStatus = followUpStatus;

    if (workStatus === "COMPLETED" && !followUpStatus) {
      updates.followUpStatus = "PENDING";
    }

    const jobOrder = await JobOrder.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true,
    })
      .populate("order")
      .populate("customer")
      .populate("technician");

    if (!jobOrder) {
      return res.status(404).json({ success: false, message: "Job order not found." });
    }

    if (workStatus === "COMPLETED" && jobOrder.order) {
      await Order.findByIdAndUpdate(jobOrder.order._id || jobOrder.order, {
        orderStatus: "COMPLETED",
      });
    }

    res.status(200).json({
      success: true,
      data: jobOrder,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Reassigns a technician to a job order with conflict validation.
 */
export const reassignTechnician = async (req, res, next) => {
  try {
    const { id } = req.params;
    requireFields(req.body, ["technician"]);
    const { technician } = req.body;

    const job = await JobOrder.findById(id);
    if (!job) {
      return res.status(404).json({ success: false, message: "Job order not found." });
    }

    const targetDate = new Date(job.serviceDate);
    const dayStart = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      0,
      0,
      0,
      0
    );
    const dayEnd = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      23,
      59,
      59,
      999
    );

    const conflict = await JobOrder.findOne({
      _id: { $ne: job._id },
      technician,
      serviceDate: { $gte: dayStart, $lte: dayEnd },
      timeSlot: job.timeSlot,
      workStatus: { $ne: "CLOSED" },
    });

    if (conflict) {
      return res.status(400).json({
        success: false,
        message: "Technician is busy in this time slot. Please choose another technician.",
      });
    }

    job.technician = technician;
    await job.save();

    if (job.order) {
      await Order.findByIdAndUpdate(job.order, { technician });
    }

    const updated = await JobOrder.findById(id)
      .populate("order")
      .populate("customer")
      .populate("technician");

    res.status(200).json({
      success: true,
      data: updated,
    });
  } catch (error) {
    next(error);
  }
};

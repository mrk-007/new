import { asyncHandler } from "../utils/asyncHandler.js";
import { sendSuccess } from "../utils/responseHelper.js";
import { AuthService } from "../services/auth.service.js";
import { HTTP_STATUS } from "../constants/httpStatusCodes.js";

export const login = asyncHandler(async (req, res) => {
  const { username, password } = req.body;
  const ipAddress = req.ip || req.socket.remoteAddress;
  const userAgent = req.headers["user-agent"] || "";

  const result = await AuthService.login({
    username,
    password,
    ipAddress,
    userAgent,
  });

  return sendSuccess(res, {
    statusCode: HTTP_STATUS.OK,
    message: "Login successful.",
    data: result,
  });
});

export const refresh = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  const ipAddress = req.ip || req.socket.remoteAddress;
  const userAgent = req.headers["user-agent"] || "";

  const result = await AuthService.refresh({
    refreshToken,
    ipAddress,
    userAgent,
  });

  return sendSuccess(res, {
    statusCode: HTTP_STATUS.OK,
    message: "Token refreshed successfully.",
    data: result,
  });
});

export const logout = asyncHandler(async (req, res) => {
  const userId = req.user._id;
  const ipAddress = req.ip || req.socket.remoteAddress;
  const userAgent = req.headers["user-agent"] || "";

  await AuthService.logout({ userId, ipAddress, userAgent });

  return sendSuccess(res, {
    statusCode: HTTP_STATUS.OK,
    message: "Logged out successfully.",
  });
});

export const getMe = asyncHandler(async (req, res) => {
  const userId = req.user._id;
  const result = await AuthService.getMe(userId);

  return sendSuccess(res, {
    statusCode: HTTP_STATUS.OK,
    message: "User profile retrieved.",
    data: result,
  });
});

export const changePassword = asyncHandler(async (req, res) => {
  const userId = req.user._id;
  const { currentPassword, newPassword } = req.body;
  const ipAddress = req.ip || req.socket.remoteAddress;
  const userAgent = req.headers["user-agent"] || "";

  await AuthService.changePassword({
    userId,
    currentPassword,
    newPassword,
    ipAddress,
    userAgent,
  });

  return sendSuccess(res, {
    statusCode: HTTP_STATUS.OK,
    message: "Password changed successfully. Please log in with your new credentials.",
  });
});

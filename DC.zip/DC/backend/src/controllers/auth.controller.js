/**
 * @file auth.controller.js
 * @description Login, current session, and user creation.
 */
import jwt from "jsonwebtoken";
import { User } from "../models/User.model.js";
import { env } from "../config/env.js";
import { AppError } from "../utils/appError.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { create } from "../services/crud.service.js";
import { ok } from "./crud.controller.js";

/** Signs a JWT for a user id. */
const signToken = (user) =>
  jwt.sign({ id: user._id }, env.JWT_SECRET, { expiresIn: env.JWT_EXPIRES_IN });

/** Shapes a user for login/me responses expected by the existing frontend. */
const publicUser = (user) => ({
  id: user._id,
  email: user.email,
  role: user.role,
  isActive: user.isActive,
});

/** Authenticates credentials and returns a token plus user (top-level for the current frontend). */
export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: email.toLowerCase() }).select("+password").populate("role");
  if (!user || !user.isActive) throw new AppError(401, "Invalid email or password.");
  const match = await user.comparePassword(password);
  if (!match) throw new AppError(401, "Invalid email or password.");
  if (!user.role || user.role.isActive === false) throw new AppError(401, "User role is inactive.");

  user.lastLoginAt = new Date();
  await user.save();

  const token = signToken(user);
  const payload = publicUser(user);
  res.status(200).json({
    success: true,
    token,
    user: payload,
    data: { token, user: payload },
    message: "Logged in.",
  });
});

/** Returns the authenticated user. */
export const getMe = asyncHandler(async (req, res) => {
  const payload = publicUser(req.user);
  res.status(200).json({
    success: true,
    user: payload,
    data: payload,
  });
});

/** Creates a user (write permission). */
export const createUser = asyncHandler(async (req, res) => {
  const user = await create(User, req.body, req);
  const populated = await User.findById(user._id).populate("role");
  ok(res, populated, { status: 201, message: "User created." });
});

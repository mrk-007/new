import { DashboardService } from "../services/dashboard.service.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { sendSuccess } from "../utils/responseHelper.js";

export class DashboardController {
  static getOverview = asyncHandler(async (req, res) => {
    const data = await DashboardService.getDashboardOverview();
    return sendSuccess(res, data, "Dashboard metrics loaded successfully.");
  });
}

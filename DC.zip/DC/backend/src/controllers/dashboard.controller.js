/**
 * @file dashboard.controller.js
 * @description Operations dashboard controller aggregating live execution metrics, flow, and catalog.
 */
import { Order, JobOrder, Subscription, Technician, Product, Master } from "../models/index.js";
import { MASTER_TYPES, ARRIVAL_STATUSES } from "../constants/index.js";

/**
 * Returns end-to-end operations dashboard data from real database queries.
 */
export const getDashboard = async (req, res, next) => {
  try {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);

    // 1. Live KPI metrics
    const [ordersToday, jobsToday, activeSubscriptions, availableTechnicians, monthCollectionAgg] =
      await Promise.all([
        Order.countDocuments({ serviceDate: { $gte: todayStart, $lte: todayEnd } }),
        JobOrder.countDocuments({ serviceDate: { $gte: todayStart, $lte: todayEnd } }),
        Subscription.countDocuments({ status: "ACTIVE" }),
        Technician.countDocuments({ isAvailable: true }),
        Order.aggregate([
          { $match: { serviceDate: { $gte: monthStart, $lte: monthEnd } } },
          { $group: { _id: null, total: { $sum: "$paidAmount" } } },
        ]),
      ]);

    const totalMonthPaid = monthCollectionAgg[0]?.total || 0;
    const formattedMonthCollection =
      totalMonthPaid >= 100000
        ? `₹${(totalMonthPaid / 100000).toFixed(2).replace(/\.00$/, "")}L`
        : `₹${totalMonthPaid.toLocaleString("en-IN")}`;

    const kpis = {
      ordersToday,
      jobsToday,
      activeSubscriptions,
      availableTechnicians,
      monthCollection: formattedMonthCollection,
    };

    // 2. Today's Service Flow with Masters
    const [todayJobs, statusMasters] = await Promise.all([
      JobOrder.find({ serviceDate: { $gte: todayStart, $lte: todayEnd } })
        .populate("customer")
        .populate("technician")
        .sort({ createdAt: 1 })
        .lean(),
      Master.find({
        type: {
          $in: [
            MASTER_TYPES.ARRIVAL_STATUS,
            MASTER_TYPES.WORK_STATUS,
            MASTER_TYPES.FOLLOW_UP_STATUS,
          ],
        },
      }).lean(),
    ]);

    const masterMap = new Map();
    statusMasters.forEach((m) => masterMap.set(`${m.type}:${m.code}`, m));

    const todayFlow = todayJobs.map((job) => {
      const arrivalMaster = masterMap.get(`${MASTER_TYPES.ARRIVAL_STATUS}:${job.arrivalStatus}`);
      const workMaster = masterMap.get(`${MASTER_TYPES.WORK_STATUS}:${job.workStatus}`);
      const followUpMaster = masterMap.get(
        `${MASTER_TYPES.FOLLOW_UP_STATUS}:${job.followUpStatus}`
      );

      const isLate = job.arrivalStatus === ARRIVAL_STATUSES.LATE && job.arrivalDelayMinutes > 0;
      const arrivalLabel = isLate
        ? `${job.arrivalDelayMinutes} min late`
        : arrivalMaster?.label || job.arrivalStatus;

      return {
        id: job._id.toString(),
        property: job.customer?.property?.name || "Unknown Property",
        work: job.work,
        technician: job.technician?.name || "Unassigned",
        arrival: {
          code: job.arrivalStatus,
          label: arrivalLabel,
          tone: arrivalMaster?.tone || "default",
        },
        workStatus: {
          code: job.workStatus,
          label: workMaster?.label || job.workStatus,
          tone: workMaster?.tone || "default",
        },
        followUp: {
          code: job.followUpStatus,
          label:
            followUpMaster?.label || (job.followUpStatus === "NONE" ? "-" : job.followUpStatus),
          tone: followUpMaster?.tone || "default",
        },
      };
    });

    // 3. Urban-style Job Lifecycle read from Master
    const [lifecycleTitleDoc, lifecycleNoticeDoc, lifecycleStepDocs] = await Promise.all([
      Master.findOne({
        type: MASTER_TYPES.LIFECYCLE_META,
        code: "TITLE",
      }).lean(),
      Master.findOne({
        type: MASTER_TYPES.LIFECYCLE_META,
        code: "NOTICE",
      }).lean(),
      Master.find({ type: MASTER_TYPES.LIFECYCLE_STEP }).sort({ order: 1 }).lean(),
    ]);

    const lifecycle = {
      title: lifecycleTitleDoc?.label || "Job Lifecycle",
      steps: lifecycleStepDocs.map((step) => step.label),
      notice: lifecycleNoticeDoc?.label || "",
    };

    // 4. Products & Subscription Catalog Preview (first 4 products by displayOrder)
    const catalogDocs = await Product.find().sort({ displayOrder: 1 }).limit(4).lean();

    const catalogPreview = catalogDocs.map((prod) => ({
      id: prod._id.toString(),
      name: prod.name,
      iconKey: prod.iconKey,
      group: prod.group,
      description: prod.description,
      price: prod.price,
      displayOrder: prod.displayOrder,
    }));

    res.status(200).json({
      success: true,
      data: {
        kpis,
        todayFlow,
        lifecycle,
        catalogPreview,
      },
    });
  } catch (error) {
    next(error);
  }
};

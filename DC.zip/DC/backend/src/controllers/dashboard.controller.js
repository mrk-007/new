/**
 * @file dashboard.controller.js
 * @description Serves the operations dashboard contract used by the frontend.
 */
import { asyncHandler } from "../utils/asyncHandler.js";
import { getDashboard } from "../services/dashboard.service.js";

/** Returns KPIs, today's flow, lifecycle, and catalog preview. */
export const dashboard = asyncHandler(async (_req, res) => {
  const payload = await getDashboard();
  res.status(200).json({
    success: true,
    data: payload,
    ...payload,
  });
});

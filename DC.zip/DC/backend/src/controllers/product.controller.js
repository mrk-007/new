/**
 * @file product.controller.js
 * @description Controller managing products, service offerings, and recurring subscription plans.
 */
import { Product } from "../models/Product.model.js";
import { requireFields } from "../middlewares/validate.middleware.js";

/**
 * Returns all products and subscriptions sorted by displayOrder.
 */
export const getProducts = async (req, res, next) => {
  try {
    const { activeOnly } = req.query;
    const filter = activeOnly === "true" ? { isActive: true } : {};

    const products = await Product.find(filter)
      .sort({ displayOrder: 1, name: 1 })
      .lean();

    res.status(200).json({
      success: true,
      data: products,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Creates a new product or recurring subscription in the catalog.
 */
export const createProduct = async (req, res, next) => {
  try {
    requireFields(req.body, ["name", "iconKey", "group", "description", "price"]);
    const {
      name,
      iconKey,
      group,
      description,
      price,
      isActive = true,
      displayOrder = 0,
    } = req.body;

    const product = await Product.create({
      name,
      iconKey,
      group,
      description,
      price,
      isActive,
      displayOrder,
      createdBy: req.user?._id,
    });

    res.status(201).json({
      success: true,
      data: product,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Updates an existing catalog product entry.
 */
export const updateProduct = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { name, iconKey, group, description, price, isActive, displayOrder } = req.body;

    const product = await Product.findByIdAndUpdate(
      id,
      { name, iconKey, group, description, price, isActive, displayOrder },
      { new: true, runValidators: true }
    );

    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found." });
    }

    res.status(200).json({
      success: true,
      data: product,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Toggles active status flag for a specified catalog item.
 */
export const toggleActive = async (req, res, next) => {
  try {
    const { id } = req.params;
    const product = await Product.findById(id);
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found." });
    }

    product.isActive = !product.isActive;
    await product.save();

    res.status(200).json({
      success: true,
      data: product,
    });
  } catch (error) {
    next(error);
  }
};

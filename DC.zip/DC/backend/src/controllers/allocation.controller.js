/**
 * @file allocation.controller.js
 * @description Placeholder kept so allocation stays routed through visit handlers.
 */
export {};

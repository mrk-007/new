/**
 * @file myJobs.controller.js
 * @description Controller providing technicians with their assigned job orders.
 */
import { JobOrder } from "../models/JobOrder.model.js";
import { Order } from "../models/Order.model.js";
import { Techni
cian } from "../models/Technician.model.js";
import { authenticate } from "../middlewares/auth.middleware.js";
import { requireRole } from "../middlewares/role.middleware.js";

/**
 * Returns job orders for the logged‑in technician.
 */
export const getMyJobs = async (req, res, next) => {
  try {
    // Auth middleware puts user id on req.user
    const techId = req.user?.technician; // assume technician ref stored in user
    if (!techId) {
      return res.status(403).json({ success: false, message: "User is not a technician." });
    }

    const { page = 1, limit = 10, workStatus } = req.query;
    const pageNum = Math.max(1, parseInt(page, 10));
    const limitNum = Math.max(1, parseInt(limit, 10));
    const skip = (pageNum - 1) * limitNum;

    const filter = { technician: techId };
    if (workStatus) filter.workStatus = workStatus;

    const [jobs, total] = await Promise.all([
      JobOrder.find(filter)
        .populate("order")
        .populate("customer")
        .populate("technician")
        .sort({ serviceDate: -1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      JobOrder.countDocuments(filter),
    ]);

    res.status(200).json({
      success: true,
      data: { jobs, total, page: pageNum, totalPages: Math.ceil(total / limitNum) },
    });
  } catch (e) {
    next(e);
  }
};

/**
 * Allows a technician to update the status of their own job order.
 */
export const updateMyJobStatus = async (req, res, next) => {
  try {
    const techId = req.user?.technician;
    if (!techId) {
      return res.status(403).json({ success: false, message: "User is not a technician." });
    }
    const { id } = req.params;
    const { workStatus, arrivalStatus, arrivalDelayMinutes, followUpStatus } = req.body;

    const job = await JobOrder.findOne({ _id: id, technician: techId });
    if (!job) {
      return res.status(404).json({ success: false, message: "Job not found for this technician." });
    }

    if (workStatus !== undefined) job.workStatus = workStatus;
    if (arrivalStatus !== undefined) job.arrivalStatus = arrivalStatus;
    if (arrivalDelayMinutes !== undefined) job.arrivalDelayMinutes = arrivalDelayMinutes;
    if (followUpStatus !== undefined) job.followUpStatus = followUpStatus;

    // If completed, cascade to order status
    if (workStatus === "COMPLETED" && job.order) {
      await Order.findByIdAndUpdate(job.order, { orderStatus: "COMPLETED" });
    }

    await job.save();
    const populated = await JobOrder.findById(job._id)
      .populate("order")
      .populate("customer")
      .populate("technician");

    res.status(200).json({ success: true, data: populated });
  } catch (e) {
    next(e);
  }
};

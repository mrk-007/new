/**
 * @file technician.controller.js
 * @description Controller managing technician rosters, availability toggles, and slot conflict checks.
 */
import { Technician } from "../models/Technician.model.js";
import { JobOrder } from "../models/JobOrder.model.js";
import { requireFields } from "../middlewares/validate.middleware.js";

/**
 * Returns list of all technicians enriched with their active job order count for today.
 */
export const getTechnicians = async (_req, res, next) => {
  try {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

    const [technicians, todayJobs] = await Promise.all([
      Technician.find().sort({ name: 1 }).lean(),
      JobOrder.find({
        serviceDate: { $gte: todayStart, $lte: todayEnd },
        workStatus: { $ne: "CLOSED" },
      }).lean(),
    ]);

    const jobCountMap = new Map();
    todayJobs.forEach((job) => {
      const techId = job.technician?.toString();
      if (techId) {
        jobCountMap.set(techId, (jobCountMap.get(techId) || 0) + 1);
      }
    });

    const enriched = technicians.map((tech) => ({
      ...tech,
      todayJobsCount: jobCountMap.get(tech._id.toString()) || 0,
    }));

    res.status(200).json({
      success: true,
      data: enriched,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Returns available technicians free from conflicting bookings for a given date and time slot.
 */
export const getAvailableTechnicians = async (req, res, next) => {
  try {
    const { date, timeSlot } = req.query;
    if (!date || !timeSlot) {
      return res.status(400).json({
        success: false,
        message: "Query parameters 'date' and 'timeSlot' are required.",
      });
    }

    const targetDate = new Date(date);
    const dayStart = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      0,
      0,
      0,
      0
    );
    const dayEnd = new Date(
      targetDate.getFullYear(),
      targetDate.getMonth(),
      targetDate.getDate(),
      23,
      59,
      59,
      999
    );

    const busyJobs = await JobOrder.find({
      serviceDate: { $gte: dayStart, $lte: dayEnd },
      timeSlot,
      workStatus: { $ne: "CLOSED" },
    }).lean();

    const busyTechIdSet = new Set(busyJobs.map((j) => j.technician?.toString()));

    const availableTechs = await Technician.find({
      isAvailable: true,
      _id: { $nin: Array.from(busyTechIdSet) },
    })
      .sort({ name: 1 })
      .lean();

    res.status(200).json({
      success: true,
      data: availableTechs,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Creates a new technician in the staff directory.
 */
export const createTechnician = async (req, res, next) => {
  try {
    requireFields(req.body, ["name", "roleTitle", "mobile"]);
    const { name, roleTitle, mobile, isAvailable = true } = req.body;

    const technician = await Technician.create({
      name,
      roleTitle,
      mobile,
      isAvailable,
    });

    res.status(201).json({
      success: true,
      data: technician,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Updates details for an existing technician.
 */
export const updateTechnician = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { name, roleTitle, mobile, isAvailable } = req.body;

    const technician = await Technician.findByIdAndUpdate(
      id,
      { name, roleTitle, mobile, isAvailable },
      { new: true, runValidators: true }
    );

    if (!technician) {
      return res.status(404).json({ success: false, message: "Technician not found." });
    }

    res.status(200).json({
      success: true,
      data: technician,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * Toggles availability active flag for a specified technician.
 */
export const toggleAvailability = async (req, res, next) => {
  try {
    const { id } = req.params;
    const tech = await Technician.findById(id);
    if (!tech) {
      return res.status(404).json({ success: false, message: "Technician not found." });
    }

    tech.isAvailable = !tech.isAvailable;
    await tech.save();

    res.status(200).json({
      success: true,
      data: tech,
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @file technician.controller.js
 * @description HTTP handlers for technicians, availability, and skills.
 */
import { Technician } from "../models/Technician.model.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { createCrudController, ok } from "./crud.controller.js";
import * as technicianService from "../services/technician.service.js";

const base = createCrudController(Technician, { searchFields: ["name", "mobile", "email"] });

export const list = base.list;
export const get = base.get;
export const create = base.create;
export const update = base.update;
export const remove = base.remove;

/** Updates technician on-duty availability. */
export const setAvailability = asyncHandler(async (req, res) => {
  const technician = await technicianService.setAvailability(req.params.id, req.body.isAvailable, req);
  ok(res, technician, { message: "Availability updated." });
});

/** Returns the skill matrix. */
export const getSkills = asyncHandler(async (req, res) => {
  const matrix = await technicianService.getSkillMatrix(req.params.id);
  ok(res, matrix);
});

/** Replaces the skill matrix. */
export const putSkills = asyncHandler(async (req, res) => {
  const matrix = await technicianService.replaceSkillMatrix(req.params.id, req.body.skills || req.body, req);
  ok(res, matrix, { message: "Skills updated." });
});

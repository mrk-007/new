/**
 * @file subscription.controller.js
 * @description Controller for subscription CRUD and status updates.
 */
import { Subscription } from "../models/Subscription.model.js";
import { Customer } from "../models/Customer.model.js";
import { Product } from "../models/Product.model.js";
import { requireFields } from "../middlewares/validate.middleware.js";

/**
 * Lists subscriptions with optional filters.
 */
export const getSubscriptions = async (req, res, next) => {
  try {
    const { status, customer, product, page = 1, limit = 10 } = req.query;
    const pageNum = Math.max(1, parseInt(page, 10));
    const limitNum = Math.max(1, parseInt(limit, 10));
    const skip = (pageNum - 1) * limitNum;
    const filter = {};
    if (status) filter.status = status;
    if (customer) filter.customer = customer;
    if (product) filter.product = product;

    const [subs, total] = await Promise.all([
      Subscription.find(filter)
        .populate("customer")
        .populate("product")
        .sort({ startDate: -1 })
        .skip(skip)
        .limit(limitNum)
        .lean(),
      Subscription.countDocuments(filter),
    ]);
    res.status(200).json({ success: true, data: { subs, total, page: pageNum, totalPages: Math.ceil(total / limitNum) } });
  } catch (e) {
    next(e);
  }
};

/**
 * Creates a new subscription.
 */
export const createSubscription = async (req, res, next) => {
  try {
    requireFields(req.body, ["customer", "product", "status", "startDate"]);
    const { customer, product, status, startDate } = req.body;
    const sub = await Subscription.create({ customer, product, status, startDate });
    const populated = await Subscription.findById(sub._id).populate("customer").populate("product");
    res.status(201).json({ success: true, data: populated });
  } catch (e) {
    next(e);
  }
};

/**
 * Updates subscription status.
 */
export const updateSubscriptionStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    requireFields(req.body, ["status"]);
    const { status } = req.body;
    const sub = await Subscription.findByIdAndUpdate(id, { status }, { new: true, runValidators: true })
      .populate("customer")
      .populate("product");
    if (!sub) return res.status(404).json({ success: false, message: "Subscription not found." });
    res.status(200).json({ success: true, data: sub });
  } catch (e) {
    next(e);
  }
};

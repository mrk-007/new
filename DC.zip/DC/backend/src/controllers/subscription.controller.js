/**
 * @file subscription.controller.js
 * @description HTTP handlers for recurring subscriptions.
 */
import { asyncHandler } from "../utils/asyncHandler.js";
import * as subscriptionService from "../services/subscription.service.js";
import { ok } from "./crud.controller.js";

/** Creates a subscription and generates visits. */
export const create = asyncHandler(async (req, res) => {
  const result = await subscriptionService.createSubscription(req.body, req);
  ok(res, result, { status: 201, message: "Subscription created." });
});

/** Lists subscriptions. */
export const list = asyncHandler(async (req, res) => {
  const { items, meta } = await subscriptionService.listSubscriptions(req);
  ok(res, items, { meta });
});

/** Returns one subscription with visits. */
export const get = asyncHandler(async (req, res) => {
  const result = await subscriptionService.getSubscription(req.params.id);
  ok(res, result);
});

/** Cancels a subscription. */
export const cancel = asyncHandler(async (req, res) => {
  const subscription = await subscriptionService.cancelSubscription(req.params.id, req);
  ok(res, subscription, { message: "Subscription cancelled." });
});

/**
 * @file master.controller.js
 * @description Master lookup controller querying system status definitions, metadata, and dropdown choices.
 */
import { Master } from "../models/Master.model.js";

/**
 * Returns master lookup entries filtered optionally by master type.
 */
export const getMasters = async (req, res, next) => {
  try {
    const { type } = req.query;
    const filter = type ? { type } : {};
    const masters = await Master.find(filter).sort({ order: 1, label: 1 }).lean();

    res.status(200).json({
      success: true,
      data: masters,
    });
  } catch (error) {
    next(error);
  }
};

import express from "express";
import helmet from "helmet";
import cors from "cors";
import { env } from "./config/env.js";
import { requestLogger } from "./middlewares/requestLogger.js";
import { apiRateLimiter } from "./middlewares/rateLimiter.js";
import { notFoundHandler, globalErrorHandler } from "./middlewares/errorHandler.js";
import apiRouter from "./routes/index.js";

const app = express();

// Secure HTTP response headers
app.use(helmet());

// Cross-Origin Resource Sharing
app.use(
  cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (e.g., mobile apps, curl, postman) or matching frontend URL
      if (!origin || origin === env.CLIENT_URL || env.isDevelopment) {
        return callback(null, true);
      }
      return callback(new Error("CORS policy violation: origin not allowed"));
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
  })
);

// Body parsing middlewares
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// HTTP Request logging
app.use(requestLogger);

// Global API rate limiting
app.use("/api", apiRateLimiter);

// Mount Master API Router
app.use(env.API_PREFIX, apiRouter);

// Root route for sanity check
app.get("/", (_req, res) => {
  res.json({
    name: "Jolly Home Needs Operations API",
    version: "1.0.0",
    docs: `${env.API_PREFIX}/health`,
  });
});

// 404 Catch-all handler
app.use(notFoundHandler);

// Centralized error handling
app.use(globalErrorHandler);

export default app;

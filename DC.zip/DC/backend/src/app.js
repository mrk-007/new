/**
 * @file app.js
 * @description Express application setup with Helmet, CORS, body parsers, routes, and error handling.
 */
import express from "express";
import helmet from "helmet";
import cors from "cors";
import { env } from "./config/env.js";
import apiRouter from "./routes/index.js";
import { notFoundHandler, errorHandler } from "./middlewares/errorHandler.middleware.js";

const app = express();

// Security headers
app.use(helmet());

// Cross-Origin Resource Sharing
app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || origin === env.CLIENT_URL || env.NODE_ENV === "development") {
        return callback(null, true);
      }
      return callback(new Error("CORS policy violation: origin not allowed"));
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Root health check
app.get("/", (_req, res) => {
  res.status(200).json({
    status: "ok",
    service: "Jolly Home Needs API",
  });
});

// Mount primary API router under prefix /api/v1
app.use("/api/v1", apiRouter);

// 404 handler
app.use(notFoundHandler);

// Centralized error handler
app.use(errorHandler);

export default app;

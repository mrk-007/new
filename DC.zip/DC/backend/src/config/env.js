/**
 * @file env.js
 * @description Loads and validates required environment variables with fail-fast checks.
 */
import dotenv from "dotenv";

dotenv.config();

if (!process.env.JWT_SECRET) {
  throw new Error("Critical Configuration Error: JWT_SECRET environment variable is missing.");
}

if (!process.env.MONGODB_URI) {
  throw new Error("Critical Configuration Error: MONGODB_URI environment variable is missing.");
}

/** Validated application environment configuration. */
export const env = {
  NODE_ENV: process.env.NODE_ENV || "development",
  PORT: parseInt(process.env.PORT || "5000", 10),
  CLIENT_URL: process.env.CLIENT_URL || "http://localhost:5173",
  MONGODB_URI: process.env.MONGODB_URI,
  JWT_SECRET: process.env.JWT_SECRET,
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || "7d",
  ADMIN_EMAIL: process.env.ADMIN_EMAIL || "admin@example.com",
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD || "ChangeMe123!",
};

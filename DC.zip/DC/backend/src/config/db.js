/**
 * @file db.js
 * @description MongoDB connection lifecycle management via Mongoose.
 */
import mongoose from "mongoose";
import { env } from "./env.js";

/**
 * Connects to MongoDB database using configured connection URI.
 */
export const connectDB = async () => {
  try {
    await mongoose.connect(env.MONGODB_URI);
    // Connection successful
  } catch (error) {
    throw new Error(`Database connection failed: ${error.message}`);
  }
};

/**
 * Disconnects from MongoDB database during application shutdown.
 */
export const disconnectDB = async () => {
  try {
    await mongoose.disconnect();
  } catch (error) {
    throw new Error(`Database disconnection failed: ${error.message}`);
  }
};

/**
 * @file db.js
 * @description MongoDB connection lifecycle management via Mongoose.
 */
import mongoose from "mongoose";
import { env } from "./env.js";

/** Connects to MongoDB using the configured URI. */
export const connectDB = async () => {
  await mongoose.connect(env.MONGODB_URI);
};

/** Disconnects from MongoDB during shutdown. */
export const disconnectDB = async () => {
  await mongoose.disconnect();
};

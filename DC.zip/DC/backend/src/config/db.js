import mongoose from "mongoose";
import { env } from "./env.js";
import { logger } from "./logger.js";

let retryCount = 0;

/**
 * Connect to MongoDB with automated retry logic.
 */
export const connectDB = async () => {
  try {
    const conn = await mongoose.connect(env.MONGODB_URI, {
      serverSelectionTimeoutMS: 5000,
      autoIndex: env.isDevelopment,
    });

    retryCount = 0;
    logger.info(`MongoDB Connected: ${conn.connection.host} / ${conn.connection.name}`);
    return conn;
  } catch (error) {
    retryCount += 1;
    logger.error(
      `MongoDB Connection Failure (Attempt ${retryCount}/${env.DB_MAX_RETRIES}): ${error.message}`
    );

    if (retryCount < env.DB_MAX_RETRIES) {
      logger.info(`Retrying MongoDB connection in ${env.DB_RETRY_DELAY_MS / 1000} seconds...`);
      await new Promise((resolve) => setTimeout(resolve, env.DB_RETRY_DELAY_MS));
      return connectDB();
    } else {
      logger.error("Maximum MongoDB connection retries reached. Continuing in offline mode or exiting.");
      throw error;
    }
  }
};

/**
 * Gracefully disconnect Mongoose connection.
 */
export const disconnectDB = async () => {
  try {
    await mongoose.connection.close(false);
    logger.info("MongoDB connection closed cleanly.");
  } catch (error) {
    logger.error(`Error during MongoDB disconnection: ${error.message}`);
  }
};

mongoose.connection.on("disconnected", () => {
  logger.warn("MongoDB connection lost. Reconnect may be attempted by driver.");
});

mongoose.connection.on("reconnected", () => {
  logger.info("MongoDB connection successfully re-established.");
});

mongoose.connection.on("error", (err) => {
  logger.error(`MongoDB runtime connection error: ${err.message}`);
});

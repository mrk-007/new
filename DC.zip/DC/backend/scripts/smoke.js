/**
 * @file smoke.js
 * @description End-to-end API smoke: login → masters → quote → slots → hanger order → mosquito net site visit → confirm → bathroom subscription → complete visits → isCompleted.
 */
import { addDays, formatIstDate } from "../src/utils/time.js";

const BASE = process.env.BASE || "http://localhost:5000/api/v1";
const EMAIL = process.env.EMAIL || process.env.ADMIN_EMAIL || "admin@example.com";
const PASS = process.env.PASS || process.env.ADMIN_PASSWORD || "ChangeMe123!";

let token = "";

/** Throws when an HTTP envelope is unsuccessful. */
const fail = (step, body, status) => {
  const message = body?.message || JSON.stringify(body);
  throw new Error(`${step} failed (${status}): ${message}`);
};

/** Sends a JSON API request with the current Bearer token. */
const api = async (method, path, body, step, { allowStatuses = [] } = {}) => {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (err) {
    throw new Error(`${step || path}: cannot reach ${BASE} (${err.message}). Start the API with npm run dev.`);
  }
  const text = await res.text();
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = { message: text };
  }
  if (allowStatuses.includes(res.status)) return json;
  if (!res.ok || json.success === false) fail(step || `${method} ${path}`, json, res.status);
  return json;
};

/** Returns the first list item matching a predicate. */
const findItem = (items, predicate) => items.find(predicate);

/** Tomorrow's IST calendar date. */
const tomorrow = () => formatIstDate(addDays(new Date(), 1));

/** First generated slot that is currently available. */
const firstOpenSlot = (slots) => {
  const slot = slots.find((row) => row.available);
  if (!slot) throw new Error("No available technician slot was returned.");
  return slot;
};

/** Completes every SERVICE visit on a booking (start then complete). */
const completeServiceVisits = async (visits, stepPrefix) => {
  const serviceVisits = visits.filter((visit) => visit.visitType === "SERVICE");
  for (const visit of serviceVisits) {
    if (visit.status === "COMPLETED") continue;
    if (visit.status === "PENDING") {
      await api("PATCH", `/visits/${visit._id}/start`, {}, `${stepPrefix} start ${visit._id}`);
    }
    await api("PATCH", `/visits/${visit._id}/complete`, {}, `${stepPrefix} complete ${visit._id}`);
  }
};

/** Runs the smoke sequence against a live server and seeded database. */
const run = async () => {
  const login = await api("POST", "/auth/login", { email: EMAIL, password: PASS }, "login");
  token = login.token || login.data?.token;
  if (!token) throw new Error("Login did not return a token.");
  process.stdout.write("1. Logged in.\n");

  await api("GET", "/auth/me", undefined, "me");
  await api("GET", "/dashboard", undefined, "dashboard");

  const products = (await api("GET", "/products?limit=50", undefined, "products")).data;
  const hanger = findItem(products, (p) => p.code === "HANGER");
  const mosquito = findItem(products, (p) => p.code === "MOSQUITO_NET");
  if (!hanger || !mosquito) throw new Error("Seed products HANGER and MOSQUITO_NET are required.");

  const serviceTypes = (await api("GET", "/service-types?limit=20", undefined, "service-types")).data;
  const orderType = findItem(serviceTypes, (row) => row.code === "ORDER");
  const subType = findItem(serviceTypes, (row) => row.code === "SUBSCRIPTION");

  const plans = (await api("GET", "/subscription-plans?limit=20", undefined, "plans")).data;
  const bathroomPlan = findItem(plans, (p) => p.code === "BATHROOM_CLEANING");

  const terms = (await api("GET", "/subscription-terms?limit=20", undefined, "terms")).data;
  const twoMonths = findItem(terms, (row) => row.months === 2);

  const frequencies = (await api("GET", "/service-frequencies?limit=20", undefined, "frequencies")).data;
  const weekly = findItem(frequencies, (row) => row.intervalDays === 7);

  const bathrooms = (await api("GET", "/bathroom-counts?limit=20", undefined, "bathrooms")).data;
  const oneBath = findItem(bathrooms, (row) => row.count === 1);

  process.stdout.write("2. Masters loaded.\n");

  const stamp = Date.now().toString().slice(-8);
  const apartment = (
    await api("POST", "/apartments", { name: `Smoke Apt ${stamp}`, landmark: "Smoke" }, "create apartment")
  ).data;
  const customer = (
    await api(
      "POST",
      "/customers",
      {
        fullName: `Smoke Customer ${stamp}`,
        mobile: `9${stamp.padStart(9, "0").slice(-9)}`,
        email: `smoke.${stamp}@example.com`,
      },
      "create customer"
    )
  ).data;
  const address = (
    await api(
      "POST",
      `/customers/${customer._id}/addresses`,
      {
        label: "Home",
        apartment: apartment._id,
        doorNo: "101",
        street: "Smoke Street",
        area: "Koramangala",
        city: "Bengaluru",
        state: "Karnataka",
        pincode: "560034",
        isDefault: true,
      },
      "create address"
    )
  ).data;

  await api(
    "POST",
    "/pricing",
    { serviceType: orderType._id, product: hanger._id, price: 499 },
    "create hanger price",
    { allowStatuses: [409] }
  );
  await api(
    "POST",
    "/pricing",
    {
      serviceType: subType._id,
      subscriptionPlan: bathroomPlan._id,
      serviceFrequency: weekly._id,
      subscriptionTerm: twoMonths._id,
      bathroomCount: oneBath._id,
      price: 1999,
    },
    "create bathroom price",
    { allowStatuses: [409] }
  );

  const quote = await api(
    "GET",
    `/pricing/quote?productId=${hanger._id}&quantity=1&addressId=${address._id}`,
    undefined,
    "quote"
  );
  if (!quote.data?.totalAmount) throw new Error("Quote did not return a tax breakdown.");
  process.stdout.write(`3. Quote total ${quote.data.totalAmount}.\n`);

  const date = tomorrow();
  const hangerSlots = (
    await api("GET", `/time-slots/available?date=${date}&productId=${hanger._id}`, undefined, "hanger slots")
  ).data;
  const hangerSlot = firstOpenSlot(hangerSlots);
  process.stdout.write("4. Slots generated.\n");

  const hangerOrder = (
    await api(
      "POST",
      "/orders",
      {
        customer: customer._id,
        address: address._id,
        product: hanger._id,
        quantity: 1,
        date,
        startTime: hangerSlot.startTime,
      },
      "create hanger order"
    )
  ).data;
  if (hangerOrder.order.status !== "CONFIRMED") {
    throw new Error(`Hanger order should be CONFIRMED, got ${hangerOrder.order.status}.`);
  }
  process.stdout.write("5. Hanger order created.\n");

  const mosquitoSlots = (
    await api("GET", `/time-slots/available?date=${date}&productId=${mosquito._id}`, undefined, "mosquito slots")
  ).data;
  const mosquitoSlot = firstOpenSlot(mosquitoSlots);
  const mosquitoOrder = (
    await api(
      "POST",
      "/orders",
      {
        customer: customer._id,
        address: address._id,
        product: mosquito._id,
        quantity: 1,
        date,
        startTime: mosquitoSlot.startTime,
      },
      "create mosquito order"
    )
  ).data;
  if (mosquitoOrder.order.status !== "SITE_VISIT_PENDING") {
    throw new Error("Mosquito net order must start in SITE_VISIT_PENDING.");
  }

  const siteVisit = mosquitoOrder.unallocatedVisits?.[0]
    ? mosquitoOrder.unallocatedVisits[0]
    : (await api("GET", `/orders/${mosquitoOrder.order._id}`, undefined, "get mosquito order")).data.visits.find(
        (visit) => visit.visitType === "SITE_VISIT"
      );
  if (!siteVisit) throw new Error("Mosquito net order did not create a site visit.");
  if (siteVisit.status === "PENDING") {
    await api("PATCH", `/visits/${siteVisit._id}/start`, {}, "start site visit");
  }
  await api(
    "PATCH",
    `/visits/${siteVisit._id}/complete`,
    { notes: "Measured", width: 4, height: 5, unit: "ft", quotedAmount: 2500 },
    "complete site visit"
  );

  const quoted = (await api("GET", `/orders/${mosquitoOrder.order._id}`, undefined, "quoted order")).data;
  if (quoted.order.status !== "QUOTED") throw new Error("Order should be QUOTED after site visit.");

  const installSlots = (
    await api(
      "GET",
      `/time-slots/available?date=${date}&productId=${mosquito._id}&visitType=SERVICE`,
      undefined,
      "install slots"
    )
  ).data;
  const installSlot = firstOpenSlot(installSlots);
  await api(
    "POST",
    `/orders/${mosquitoOrder.order._id}/confirm`,
    { date, startTime: installSlot.startTime },
    "confirm mosquito order"
  );
  process.stdout.write("6. Mosquito net site visit → quoted → confirmed.\n");

  const subSlots = (
    await api(
      "GET",
      `/time-slots/available?date=${date}&subscriptionPlanId=${bathroomPlan._id}&bathroomCountId=${oneBath._id}`,
      undefined,
      "bathroom slots"
    )
  ).data;
  const subSlot = firstOpenSlot(subSlots);
  const createdSub = (
    await api(
      "POST",
      "/subscriptions",
      {
        customer: customer._id,
        address: address._id,
        subscriptionPlan: bathroomPlan._id,
        subscriptionTerm: twoMonths._id,
        serviceFrequency: weekly._id,
        bathroomCount: oneBath._id,
        startDate: date,
        preferredStartTime: subSlot.startTime,
      },
      "create subscription"
    )
  ).data;
  process.stdout.write("7. Bathroom subscription created.\n");

  const subDetail = (await api("GET", `/subscriptions/${createdSub.subscription._id}`, undefined, "get subscription"))
    .data;
  await completeServiceVisits(subDetail.visits, "subscription visit");

  const done = (await api("GET", `/subscriptions/${createdSub.subscription._id}`, undefined, "verify subscription"))
    .data;
  if (!done.subscription.isCompleted || done.subscription.status !== "COMPLETED") {
    throw new Error("Subscription should be COMPLETED with isCompleted=true after all service visits.");
  }

  await api("GET", "/audit-logs?limit=5", undefined, "audit logs");
  process.stdout.write("8. Subscription completed. Smoke passed.\n");
};

run().catch((err) => {
  process.stderr.write(`${err.message}\n`);
  process.exit(1);
});

#!/usr/bin/env bash
# Smoke sequence wrapper for Unix shells. Prefer: npm run smoke
set -euo pipefail
cd "$(dirname "$0")/.."
node scripts/smoke.js

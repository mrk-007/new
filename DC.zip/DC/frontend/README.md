# DC Operations Frontend

React 18 + Vite + MUI 6 client for the Deep Cleaning operations API.

## Setup

```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

The Vite dev server proxies `/api` to `http://localhost:5000`. Start the backend first.

## Env

- `VITE_API_BASE_URL` — API prefix. Default `/api/v1`.

## Scripts

- `npm run dev` — local dev
- `npm run build` — production bundle
- `npm run preview` — serve the bundle

## Deploy

Push the `frontend/` folder to Vercel. `vercel.json` rewrites all routes to `index.html`. Set `VITE_API_BASE_URL` to the public API origin (for example `https://api.example.com/api/v1`).

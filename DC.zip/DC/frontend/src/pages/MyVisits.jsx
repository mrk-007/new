/**
 * @file MyVisits.jsx
 * @description Route entry for technician visits.
 */
import { MyVisits as MyVisitsFeature } from "../components/visits/Visits.jsx";

/** Renders the technician visit screen. */
const MyVisits = () => <MyVisitsFeature />;

export default MyVisits;

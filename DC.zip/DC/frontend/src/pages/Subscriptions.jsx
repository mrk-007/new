/**
 * @file Subscriptions.jsx
 * @description Route entry for the subscriptions feature.
 */
import SubscriptionsFeature from "../components/subscriptions/Subscriptions.jsx";

/** Renders the subscriptions screen. */
const Subscriptions = () => <SubscriptionsFeature />;

export default Subscriptions;

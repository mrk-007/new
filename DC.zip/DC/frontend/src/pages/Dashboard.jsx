/**
 * @file Dashboard.jsx
 * @description Operations Dashboard page - composition and component imports only.
 */
import DashboardView from "../components/dashboard/DashboardView.jsx";

/**
 * Renders the Operations Dashboard page view.
 */
export const Dashboard = () => {
  return <DashboardView />;
};

export default Dashboard;

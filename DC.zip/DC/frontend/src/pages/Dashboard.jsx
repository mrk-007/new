/**
 * @file Dashboard.jsx
 * @description Route entry for the dashboard feature.
 */
import DashboardFeature from "../components/dashboard/Dashboard.jsx";

/** Renders the dashboard screen. */
const Dashboard = () => <DashboardFeature />;

export default Dashboard;

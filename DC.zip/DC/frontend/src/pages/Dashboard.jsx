import KpiCards from "../components/dashboard/KpiCards";
import TodayServiceFlow from "../components/dashboard/TodayServiceFlow";
import JobLifecycleNotice from "../components/dashboard/JobLifecycleNotice";
import HomeCatalogSection from "../components/dashboard/HomeCatalogSection";
import useDashboardData from "../components/dashboard/useDashboardData";

export default function Dashboard() {
  const { data, loading } = useDashboardData();

  if (loading) {
    return <div className="empty">Loading dashboard...</div>;
  }

  return (
    <section className="page active" id="dashboard">
      <KpiCards kpis={data.kpis} />
      <div className="grid two">
        <TodayServiceFlow items={data.todayFlow} />
        <JobLifecycleNotice lifecycle={data.lifecycle} />
      </div>
      <HomeCatalogSection items={data.catalogPreview} />
    </section>
  );
}

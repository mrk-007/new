/**
 * @file Customers.jsx
 * @description Route entry for the customers feature.
 */
import CustomersFeature from "../components/customers/Customers.jsx";

/** Renders the customers screen. */
const Customers = () => <CustomersFeature />;

export default Customers;

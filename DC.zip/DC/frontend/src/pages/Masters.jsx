/**
 * @file Masters.jsx
 * @description Route entry for config-driven master screens.
 */
import MastersFeature from "../components/masters/Masters.jsx";

/** Renders the selected master screen. */
const Masters = () => <MastersFeature />;

export default Masters;

/**
 * @file OrderNew.jsx
 * @description Route entry for the order booking feature.
 */
import OrderBooking from "../components/orders/OrderBooking.jsx";

/** Renders the order booking screen. */
const OrderNew = () => <OrderBooking />;

export default OrderNew;

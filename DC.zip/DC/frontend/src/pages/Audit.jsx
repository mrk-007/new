/**
 * @file Audit.jsx
 * @description Route entry for the audit feature.
 */
import AuditFeature from "../components/audit/Audit.jsx";

/** Renders the audit screen. */
const Audit = () => <AuditFeature />;

export default Audit;

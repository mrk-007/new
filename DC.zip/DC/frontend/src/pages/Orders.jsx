/**
 * @file Orders.jsx
 * @description Route entry for the orders feature.
 */
import OrdersFeature from "../components/orders/Orders.jsx";

/** Renders the orders screen. */
const Orders = () => <OrdersFeature />;

export default Orders;

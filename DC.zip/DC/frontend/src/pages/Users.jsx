/**
 * @file Users.jsx
 * @description Route entry for the users feature.
 */
import UsersFeature from "../components/users/Users.jsx";

/** Renders the users screen. */
const Users = () => <UsersFeature />;

export default Users;

/**
 * @file Visits.jsx
 * @description Route entry for the visits feature.
 */
import VisitsFeature from "../components/visits/Visits.jsx";

/** Renders the visits screen. */
const Visits = () => <VisitsFeature />;

export default Visits;

/**
 * @file Login.jsx
 * @description Route entry for the login feature.
 */
import LoginFeature from "../components/login/Login.jsx";

/** Renders the login screen. */
const Login = () => <LoginFeature />;

export default Login;

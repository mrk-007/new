/**
 * @file Login.jsx
 * @description Authentication Login page - composition and component imports only.
 */
import LoginForm from "../components/common/LoginForm.jsx";

/**
 * Renders the Authentication Login page view.
 */
export const Login = () => {
  return <LoginForm />;
};

export default Login;

/**
 * @file SubscriptionNew.jsx
 * @description Route entry for the subscription booking feature.
 */
import SubscriptionBooking from "../components/subscriptions/SubscriptionBooking.jsx";

/** Renders the subscription booking screen. */
const SubscriptionNew = () => <SubscriptionBooking />;

export default SubscriptionNew;

/**
 * @file Technicians.jsx
 * @description Route entry for the technicians feature.
 */
import TechniciansFeature from "../components/technicians/Technicians.jsx";

/** Renders the technicians screen. */
const Technicians = () => <TechniciansFeature />;

export default Technicians;

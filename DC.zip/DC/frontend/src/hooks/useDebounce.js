/**
 * @file useDebounce.js
 * @description Delays a value so search queries do not fire on every keystroke.
 */
import { useEffect, useState } from "react";

/** Returns the value after it has stayed unchanged for delayMs. */
export const useDebounce = (value, delayMs = 300) => {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(timer);
  }, [value, delayMs]);
  return debounced;
};

export default useDebounce;

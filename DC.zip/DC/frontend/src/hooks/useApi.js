/**
 * @file useApi.js
 * @description Loads data through an api.js function with loading, error, and reload.
 */
import { useCallback, useEffect, useState } from "react";

/** Runs an api function whenever dependencies change. */
export const useApi = (fetcher, deps = []) => {
  const [data, setData] = useState(null);
  const [meta, setMeta] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const reload = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await fetcher();
      setData(result?.data ?? result ?? null);
      setMeta(result?.meta ?? null);
    } catch (err) {
      setError(err);
    } finally {
      setIsLoading(false);
    }
  }, deps);

  useEffect(() => {
    reload();
  }, [reload]);

  return { data, meta, isLoading, error, reload, setData };
};

export default useApi;

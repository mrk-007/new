import { useAuth } from "./useAuth";

export const usePermission = (moduleKey) => {
  const { permissions, role } = useAuth();

  // Super admin has full access across all modules
  if (role === "admin") {
    return {
      isRead: true,
      isWrite: true,
      isDelete: true,
      canAccess: true,
    };
  }

  const modulePerm = permissions?.find(
    (p) => p.moduleKey?.toLowerCase() === moduleKey?.toLowerCase()
  );

  return {
    isRead: Boolean(modulePerm?.isRead),
    isWrite: Boolean(modulePerm?.isWrite),
    isDelete: Boolean(modulePerm?.isDelete),
    canAccess: Boolean(modulePerm?.isRead),
  };
};

export default usePermission;

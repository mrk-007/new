/**
 * @file usePermission.js
 * @description Role flags from the authenticated user.
 */
import { useAuth } from "../context/AuthContext.jsx";
import { APP } from "../constants/Content.js";

/** Exposes canRead / canWrite / canDelete and technician landing. */
export const usePermission = () => {
  const { user } = useAuth();
  const role = user?.role || {};
  const roleName = role.roleName || "";
  return {
    canRead: Boolean(role.isRead),
    canWrite: Boolean(role.isWrite),
    canDelete: Boolean(role.isDelete),
    isTechnician: roleName === APP.TECHNICIAN_ROLE_NAME,
    roleName,
  };
};

export default usePermission;

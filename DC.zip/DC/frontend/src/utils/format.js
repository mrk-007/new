/**
 * @file format.js
 * @description Currency, date/time, path reads, and humanized enum labels.
 */
import { APP } from "../constants/Content.js";

const INR = new Intl.NumberFormat(APP.LOCALE, {
  style: "currency",
  currency: APP.CURRENCY,
  maximumFractionDigits: 2,
});

/** Formats a number as Indian rupees. */
export const formatCurrency = (value) => {
  if (value === null || value === undefined || value === "") return "—";
  return INR.format(Number(value));
};

/** Returns today's calendar date in Asia/Kolkata as YYYY-MM-DD. */
export const todayIstDate = () =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: APP.TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());

/** Formats an instant in Asia/Kolkata as a date. */
export const formatDate = (value) => {
  if (!value) return "—";
  return new Intl.DateTimeFormat(APP.LOCALE, {
    timeZone: APP.TIMEZONE,
    year: "numeric",
    month: "short",
    day: "2-digit",
  }).format(new Date(value));
};

/** Formats an instant in Asia/Kolkata as a time. */
export const formatTime = (value) => {
  if (!value) return "—";
  return new Intl.DateTimeFormat(APP.LOCALE, {
    timeZone: APP.TIMEZONE,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(new Date(value));
};

/** Formats an instant in Asia/Kolkata as date and time. */
export const formatDateTime = (value) => {
  if (!value) return "—";
  return `${formatDate(value)} ${formatTime(value)}`;
};

/** Turns SITE_VISIT_PENDING into "Site Visit Pending". */
export const humanize = (code) => {
  if (code === true) return "Yes";
  if (code === false) return "No";
  if (code === null || code === undefined || code === "") return "—";
  return String(code)
    .split("_")
    .map((part) => part.charAt(0) + part.slice(1).toLowerCase())
    .join(" ");
};

/** Reads a dotted path from an object. */
export const getByPath = (row, path) => {
  if (!path) return row;
  return path.split(".").reduce((acc, key) => (acc == null ? acc : acc[key]), row);
};

/** Extracts a document id from a ref or populated object. */
export const idOf = (value) => {
  if (!value) return "";
  if (typeof value === "string") return value;
  return value._id || value.id || "";
};

/** Maps API rows to select options. */
export const toOptions = (rows = [], labelKey = "name") =>
  rows.map((row) => ({
    value: String(row._id || row.id || row.value),
    label: row[labelKey] || row.roleName || row.name || row.code || String(row._id),
    code: row.code,
    pricingBasis: row.pricingBasis,
    requiresSiteVisit: row.requiresSiteVisit,
    ...row,
  }));

export default {
  formatCurrency,
  formatDate,
  formatTime,
  formatDateTime,
  humanize,
  getByPath,
  idOf,
  toOptions,
};

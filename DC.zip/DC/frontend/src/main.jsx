/**
 * @file main.jsx
 * @description Application bootstrap: router, theme, auth, and notifier providers.
 */
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import ThemeModeProvider from "./context/ThemeModeContext.jsx";
import AuthProvider from "./context/AuthContext.jsx";
import NotifierProvider from "./context/NotifierContext.jsx";
import App from "./App.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <BrowserRouter>
      <ThemeModeProvider>
        <AuthProvider>
          <NotifierProvider>
            <App />
          </NotifierProvider>
        </AuthProvider>
      </ThemeModeProvider>
    </BrowserRouter>
  </StrictMode>
);

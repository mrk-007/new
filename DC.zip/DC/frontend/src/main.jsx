import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import AuthProvider from "./context/AuthContext";
import MasterDataProvider from "./context/MasterDataContext";
import ToastProvider from "./context/ToastContext";
import AppLayout from "./components/layout/AppLayout";
import "./styles/index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <MasterDataProvider>
          <ToastProvider>
            <AppLayout>
              <App />
            </AppLayout>
          </ToastProvider>
        </MasterDataProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);

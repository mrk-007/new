import { createContext, useState, useEffect, useCallback } from "react";
import apiClient from "../services/apiClient";
import { API_ENDPOINTS } from "../constants/apiEndpoints";

export const MasterDataContext = createContext(null);

export const MasterDataProvider = ({ children }) => {
  const [masters, setMasters] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchBootstrapData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await apiClient.get(API_ENDPOINTS.MASTERS.BOOTSTRAP);
      if (response?.data) {
        setMasters(response.data);
      }
    } catch (err) {
      console.warn("Could not load masters from backend bootstrap API:", err);
      setError(err?.message || "Failed to load master metadata");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBootstrapData();
  }, [fetchBootstrapData]);

  return (
    <MasterDataContext.Provider
      value={{
        masters,
        loading,
        error,
        reloadMasters: fetchBootstrapData,
      }}
    >
      {children}
    </MasterDataContext.Provider>
  );
};

export default MasterDataProvider;

/**
 * @file NotifierContext.jsx
 * @description Global success/error snackbar.
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import { setNotifyHandler } from "../services/api.js";

const NotifierContext = createContext(null);

/** Provides notify({ severity, message }) to the tree. */
export const NotifierProvider = ({ children }) => {
  const [toast, setToast] = useState(null);

  const notify = useCallback((payload) => {
    setToast({ severity: "info", ...payload });
  }, []);

  const handleClose = () => setToast(null);

  useEffect(() => {
    setNotifyHandler(notify);
    return () => setNotifyHandler(null);
  }, [notify]);

  const value = useMemo(() => ({ notify }), [notify]);

  return (
    <NotifierContext.Provider value={value}>
      {children}
      <Snackbar open={Boolean(toast)} autoHideDuration={4000} onClose={handleClose} anchorOrigin={{ vertical: "bottom", horizontal: "right" }}>
        <Alert onClose={handleClose} severity={toast?.severity || "info"} variant="filled">
          {toast?.message}
        </Alert>
      </Snackbar>
    </NotifierContext.Provider>
  );
};

/** Reads the notifier. */
export const useNotifier = () => {
  const ctx = useContext(NotifierContext);
  if (!ctx) throw new Error("useNotifier must be used within NotifierProvider");
  return ctx;
};

export default NotifierProvider;

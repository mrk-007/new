import { createContext, useState, useEffect, useCallback } from "react";
import apiClient from "../services/apiClient";
import { API_ENDPOINTS } from "../constants/apiEndpoints";

export const AuthContext = createContext(null);

const DEFAULT_PERMISSIONS = {
  admin: [
    { moduleKey: "dashboard", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "customers", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "orders", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "subscriptions", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "jobs", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "schedule", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "technicians", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "catalog", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "invoices", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "configuration", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "techHome", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "techCalendar", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "techHistory", isRead: true, isWrite: true, isDelete: true },
    { moduleKey: "techProfile", isRead: true, isWrite: true, isDelete: true },
  ],
  telecaller: [
    { moduleKey: "dashboard", isRead: true, isWrite: false, isDelete: false },
    { moduleKey: "customers", isRead: true, isWrite: true, isDelete: false },
    { moduleKey: "orders", isRead: true, isWrite: true, isDelete: false },
    { moduleKey: "subscriptions", isRead: true, isWrite: true, isDelete: false },
    { moduleKey: "jobs", isRead: true, isWrite: true, isDelete: false },
    { moduleKey: "schedule", isRead: true, isWrite: true, isDelete: false },
    { moduleKey: "technicians", isRead: true, isWrite: false, isDelete: false },
    { moduleKey: "catalog", isRead: true, isWrite: false, isDelete: false },
    { moduleKey: "invoices", isRead: true, isWrite: true, isDelete: false },
    { moduleKey: "configuration", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "techHome", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "techCalendar", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "techHistory", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "techProfile", isRead: false, isWrite: false, isDelete: false },
  ],
  technician: [
    { moduleKey: "dashboard", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "customers", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "orders", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "subscriptions", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "jobs", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "schedule", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "technicians", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "catalog", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "invoices", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "configuration", isRead: false, isWrite: false, isDelete: false },
    { moduleKey: "techHome", isRead: true, isWrite: true, isDelete: false },
    { moduleKey: "techCalendar", isRead: true, isWrite: true, isDelete: false },
    { moduleKey: "techHistory", isRead: true, isWrite: false, isDelete: false },
    { moduleKey: "techProfile", isRead: true, isWrite: true, isDelete: false },
  ],
};

export const AuthProvider = ({ children }) => {
  const [role, setRole] = useState("admin"); // 'admin' | 'telecaller' | 'technician'
  const [activeTech, setActiveTech] = useState("Arun S.");
  const [user, setUser] = useState({
    name: "Operations Admin",
    email: "admin@jollyhomeneeds.com",
    role: "Super Admin",
  });
  const [permissions, setPermissions] = useState(DEFAULT_PERMISSIONS.admin);
  const [loading, setLoading] = useState(false);

  // Sync permissions when role changes
  const switchRole = useCallback((newRole) => {
    setRole(newRole);
    if (newRole === "admin") {
      setUser({ name: "Operations Admin", email: "admin@jollyhomeneeds.com", role: "Super Admin" });
      setPermissions(DEFAULT_PERMISSIONS.admin);
    } else if (newRole === "telecaller") {
      setUser({ name: "Priya Sharma", email: "priya@jollyhomeneeds.com", role: "Telecaller" });
      setPermissions(DEFAULT_PERMISSIONS.telecaller);
    } else if (newRole === "technician") {
      setUser({ name: activeTech, email: "tech@jollyhomeneeds.com", role: "Technician" });
      setPermissions(DEFAULT_PERMISSIONS.technician);
    }
  }, [activeTech]);

  const switchTechnician = useCallback((techName) => {
    setActiveTech(techName);
    if (role === "technician") {
      setUser((prev) => ({ ...prev, name: techName }));
    }
  }, [role]);

  // Attempt backend me query on initial mount if token exists
  useEffect(() => {
    const fetchMe = async () => {
      const token = localStorage.getItem("jhn_access_token");
      if (!token) return;

      try {
        setLoading(true);
        const res = await apiClient.get(API_ENDPOINTS.AUTH.ME);
        if (res.data?.user) {
          setUser(res.data.user);
          if (res.data.permissions) {
            setPermissions(res.data.permissions);
          }
        }
      } catch {
        // Fall back gracefully to active role state
      } finally {
        setLoading(false);
      }
    };

    fetchMe();
  }, []);

  const login = useCallback(async (email, password) => {
    const res = await apiClient.post(API_ENDPOINTS.AUTH.LOGIN, { email, password });
    if (res.data?.accessToken) {
      localStorage.setItem("jhn_access_token", res.data.accessToken);
      localStorage.setItem("jhn_refresh_token", res.data.refreshToken);
      setUser(res.data.user);
      if (res.data.permissions) {
        setPermissions(res.data.permissions);
      }
    }
    return res;
  }, []);

  const logout = useCallback(async () => {
    try {
      await apiClient.post(API_ENDPOINTS.AUTH.LOGOUT);
    } catch {
      // Ignore error on logout
    } finally {
      localStorage.removeItem("jhn_access_token");
      localStorage.removeItem("jhn_refresh_token");
      setUser(null);
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        activeTech,
        permissions,
        loading,
        switchRole,
        switchTechnician,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;

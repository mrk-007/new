/**
 * @file AuthContext.jsx
 * @description Authentication context providing JWT token storage, user state, and session validation.
 */
import { createContext, useContext, useState, useEffect, useCallback } from "react";
import authService from "../services/authService.js";

export const AuthContext = createContext(null);

/**
 * Authentication context provider managing user session persistence and credentials flow.
 */
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(() => localStorage.getItem("token"));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  /**
   * Restores user session if a valid JWT token exists in localStorage.
   */
  const loadUser = useCallback(async () => {
    const storedToken = localStorage.getItem("token");
    if (!storedToken) {
      setLoading(false);
      return;
    }

    try {
      const res = await authService.getMe();
      if (res?.user) {
        setUser(res.user);
        setToken(storedToken);
      }
    } catch (_err) {
      localStorage.removeItem("token");
      setUser(null);
      setToken(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadUser();
  }, [loadUser]);

  /**
   * Logs in user with email and password, saving JWT access token to localStorage.
   */
  const login = useCallback(async (email, password) => {
    setError(null);
    try {
      const res = await authService.login(email, password);
      if (res?.token) {
        localStorage.setItem("token", res.token);
        setToken(res.token);
        setUser(res.user);
        return res.user;
      }
      throw new Error("Invalid response format from login endpoint.");
    } catch (err) {
      const message = err?.message || "Login failed. Please check credentials.";
      setError(message);
      throw new Error(message);
    }
  }, []);

  /**
   * Clears user session and removes JWT access token from localStorage.
   */
  const logout = useCallback(() => {
    localStorage.removeItem("token");
    setToken(null);
    setUser(null);
    setError(null);
  }, []);

  const value = {
    user,
    token,
    loading,
    error,
    isAuthenticated: Boolean(user && token),
    login,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

/**
 * Custom React hook for accessing active authentication context.
 */
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export default AuthProvider;

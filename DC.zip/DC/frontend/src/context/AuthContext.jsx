/**
 * @file AuthContext.jsx
 * @description JWT session restore, login, and logout.
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { APP } from "../constants/Content.js";
import { getMe, login as loginRequest, setUnauthorizedHandler } from "../services/api.js";

const AuthContext = createContext(null);

/** Provides the authenticated user and session actions. */
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isReady, setIsReady] = useState(false);

  const logout = useCallback(() => {
    localStorage.removeItem(APP.TOKEN_KEY);
    setUser(null);
  }, []);

  const restore = useCallback(async () => {
    const token = localStorage.getItem(APP.TOKEN_KEY);
    if (!token) {
      setIsReady(true);
      return;
    }
    try {
      const me = await getMe();
      setUser(me);
    } catch {
      localStorage.removeItem(APP.TOKEN_KEY);
      setUser(null);
    } finally {
      setIsReady(true);
    }
  }, []);

  useEffect(() => {
    restore();
  }, [restore]);

  useEffect(() => {
    setUnauthorizedHandler(() => {
      logout();
      window.location.assign("/login");
    });
    return () => setUnauthorizedHandler(null);
  }, [logout]);

  const login = async (email, password) => {
    const result = await loginRequest(email, password);
    localStorage.setItem(APP.TOKEN_KEY, result.token);
    setUser(result.user);
    return result.user;
  };

  const value = useMemo(
    () => ({ user, isReady, isAuthenticated: Boolean(user), login, logout }),
    [user, isReady, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

/** Reads auth state. */
export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

export default AuthProvider;

/**
 * @file OrderBooking.jsx
 * @description New-order wizard: customer, address, product, slot, quote, create.
 */
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import Typography from "@mui/material/Typography";
import Alert from "@mui/material/Alert";
import { COMMON, ORDERS } from "../../constants/Content.js";
import { ROUTES } from "../../constants/routes.js";
import {
  createOrder,
  getAvailableSlots,
  getQuote,
  listAddresses,
  listCustomers,
  listMaster,
} from "../../services/api.js";
import { useNotifier } from "../../context/NotifierContext.jsx";
import { formatCurrency, idOf, todayIstDate } from "../../utils/format.js";
import PageHeader from "../common/PageHeader.jsx";
import { FilterRow, PageStack } from "../../theme/styles/common.styles.js";
import { SnapshotBox, WizardCard } from "../../theme/styles/feature.styles.js";

/** Loads customers, products, then dependent addresses, slots, and quote. */
export const OrderBooking = () => {
  const navigate = useNavigate();
  const { notify } = useNotifier();
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [addresses, setAddresses] = useState([]);
  const [slots, setSlots] = useState([]);
  const [quote, setQuote] = useState(null);
  const [isBusy, setIsBusy] = useState(false);
  const [values, setValues] = useState({
    customer: "",
    address: "",
    product: "",
    quantity: 1,
    date: todayIstDate(),
    startTime: "",
  });

  const product = products.find((row) => idOf(row) === values.product);
  const needsSiteVisit = Boolean(product?.requiresSiteVisit);

  useEffect(() => {
    const load = async () => {
      const [customerRes, productRes] = await Promise.all([
        listCustomers({ limit: 100 }),
        listMaster("products", { limit: 100 }),
      ]);
      setCustomers(customerRes.data || []);
      setProducts(productRes.data || []);
    };
    load();
  }, []);

  useEffect(() => {
    if (!values.customer) {
      setAddresses([]);
      return;
    }
    listAddresses(values.customer).then((result) => setAddresses(result.data || []));
  }, [values.customer]);

  useEffect(() => {
    if (!values.product || !values.date) return;
    getAvailableSlots({ date: values.date, productId: values.product })
      .then((result) => setSlots((result.data || []).filter((slot) => slot.available)))
      .catch(() => setSlots([]));
  }, [values.product, values.date]);

  useEffect(() => {
    if (needsSiteVisit || !values.product || !values.address) {
      setQuote(null);
      return;
    }
    getQuote({ productId: values.product, quantity: values.quantity, addressId: values.address })
      .then((result) => setQuote(result.data))
      .catch(() => setQuote(null));
  }, [needsSiteVisit, values.product, values.quantity, values.address]);

  const handleChange = (name, value) => setValues((current) => ({ ...current, [name]: value }));

  const handleCreate = async () => {
    setIsBusy(true);
    try {
      await createOrder({
        customer: values.customer,
        address: values.address,
        product: values.product,
        quantity: Number(values.quantity) || 1,
        date: values.date,
        startTime: values.startTime,
      });
      notify({ severity: "success", message: COMMON.SUCCESS });
      navigate(ROUTES.ORDERS);
    } catch (err) {
      notify({ severity: "error", message: err.message });
    } finally {
      setIsBusy(false);
    }
  };

  const canSubmit = values.customer && values.address && values.product && values.date && values.startTime;

  return (
    <PageStack>
      <PageHeader title={ORDERS.WIZARD.TITLE} />
      <WizardCard elevation={1}>
        <TextField
          select
          label={ORDERS.WIZARD.CUSTOMER}
          value={values.customer}
          onChange={(event) => handleChange("customer", event.target.value)}
        >
          {customers.map((row) => (
            <MenuItem key={row._id} value={row._id}>
              {row.fullName}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          select
          label={ORDERS.WIZARD.ADDRESS}
          value={values.address}
          onChange={(event) => handleChange("address", event.target.value)}
        >
          {addresses.map((row) => (
            <MenuItem key={row._id} value={row._id}>
              {row.label} — {row.city}
            </MenuItem>
          ))}
        </TextField>
        {!addresses.length && values.customer ? (
          <Typography variant="body2">{ORDERS.WIZARD.NO_ADDRESSES}</Typography>
        ) : null}
        <TextField
          select
          label={ORDERS.WIZARD.PRODUCT}
          value={values.product}
          onChange={(event) => handleChange("product", event.target.value)}
        >
          {products.map((row) => (
            <MenuItem key={row._id} value={row._id}>
              {row.name}
            </MenuItem>
          ))}
        </TextField>
        <TextField
          type="number"
          label={ORDERS.WIZARD.QUANTITY}
          value={values.quantity}
          onChange={(event) => handleChange("quantity", event.target.value)}
        />
        <TextField
          type="date"
          label={ORDERS.WIZARD.DATE}
          value={values.date}
          onChange={(event) => handleChange("date", event.target.value)}
          InputLabelProps={{ shrink: true }}
        />
        <TextField
          select
          label={ORDERS.WIZARD.SLOT}
          value={values.startTime}
          onChange={(event) => handleChange("startTime", event.target.value)}
        >
          {slots.map((slot) => (
            <MenuItem key={slot.startTime} value={slot.startTime}>
              {slot.startTime} – {slot.endTime}
            </MenuItem>
          ))}
        </TextField>
        {!slots.length ? <Typography variant="body2">{ORDERS.WIZARD.NO_SLOTS}</Typography> : null}
        {needsSiteVisit ? <Alert severity="info">{ORDERS.SITE_VISIT_HINT}</Alert> : null}
        {quote ? (
          <SnapshotBox elevation={0}>
            <Typography>{ORDERS.UNIT_PRICE}: {formatCurrency(quote.unitPrice)}</Typography>
            <Typography>{ORDERS.CGST}: {formatCurrency(quote.cgstAmount)}</Typography>
            <Typography>{ORDERS.SGST}: {formatCurrency(quote.sgstAmount)}</Typography>
            <Typography>{ORDERS.TOTAL}: {formatCurrency(quote.totalAmount)}</Typography>
          </SnapshotBox>
        ) : null}
        <FilterRow>
          <Button onClick={() => navigate(ROUTES.ORDERS)}>{COMMON.CANCEL}</Button>
          <Button variant="contained" onClick={handleCreate} disabled={!canSubmit || isBusy}>
            {ORDERS.WIZARD.SUBMIT}
          </Button>
        </FilterRow>
      </WizardCard>
    </PageStack>
  );
};

export default OrderBooking;

/**
 * @file Orders.jsx
 * @description Order list, detail drawer, confirm, cancel, and status change.
 */
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import Typography from "@mui/material/Typography";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import { COMMON, CONFIRM, ORDER_STATUSES, ORDERS } from "../../constants/Content.js";
import { ROUTES } from "../../constants/routes.js";
import {
  cancelOrder,
  confirmOrder,
  getAvailableSlots,
  getOrder,
  listOrders,
  patchOrderStatus,
} from "../../services/api.js";
import { useApi } from "../../hooks/useApi.js";
import { useDebounce } from "../../hooks/useDebounce.js";
import { usePermission } from "../../hooks/usePermission.js";
import { useNotifier } from "../../context/NotifierContext.jsx";
import { formatCurrency, humanize, todayIstDate } from "../../utils/format.js";
import PageHeader from "../common/PageHeader.jsx";
import DataTable from "../common/DataTable.jsx";
import Loader from "../common/Loader.jsx";
import EmptyState from "../common/EmptyState.jsx";
import ConfirmDialog from "../common/ConfirmDialog.jsx";
import StatusChip from "../common/StatusChip.jsx";
import { ErrorBanner, FilterRow, GrowBox, PageStack } from "../../theme/styles/common.styles.js";
import { DrawerPaper, SideDrawer, SnapshotBox } from "../../theme/styles/feature.styles.js";

/** Retryable error strip. */
const ErrorPanel = ({ error, onRetry }) => (
  <ErrorBanner elevation={0}>
    <Typography color="error">{error?.message}</Typography>
    <Button onClick={onRetry}>{COMMON.RETRY}</Button>
  </ErrorBanner>
);

/** Order list with a detail drawer. */
export const Orders = () => {
  const navigate = useNavigate();
  const { canWrite } = usePermission();
  const { notify } = useNotifier();
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [detail, setDetail] = useState(null);
  const [cancelRow, setCancelRow] = useState(null);
  const [reason, setReason] = useState("");
  const [nextStatus, setNextStatus] = useState("");
  const [confirmValues, setConfirmValues] = useState({ date: todayIstDate(), startTime: "" });
  const [slots, setSlots] = useState([]);
  const debounced = useDebounce(search);
  const { data, meta, isLoading, error, reload } = useApi(
    () => listOrders({ page, limit, search: debounced, status }),
    [page, limit, debounced, status]
  );

  const handleOpen = async (row) => {
    const result = await getOrder(row._id);
    setDetail(result.data);
    setNextStatus("");
    setConfirmValues({ date: todayIstDate(), startTime: "" });
    const productId = result.data?.order?.product?._id || result.data?.order?.product;
    if (result.data?.order?.status === "QUOTED" && productId) {
      const slotRes = await getAvailableSlots({
        date: todayIstDate(),
        productId,
        visitType: "SERVICE",
      });
      setSlots((slotRes.data || []).filter((slot) => slot.available));
    }
  };

  const handleConfirm = async () => {
    try {
      await confirmOrder(detail.order._id, confirmValues);
      notify({ severity: "success", message: COMMON.SUCCESS });
      setDetail(null);
      reload();
    } catch (err) {
      notify({ severity: "error", message: err.message });
    }
  };

  const handleCancel = async () => {
    try {
      await cancelOrder(cancelRow._id, { cancelReason: reason });
      notify({ severity: "success", message: COMMON.SUCCESS });
      setCancelRow(null);
      setDetail(null);
      reload();
    } catch (err) {
      notify({ severity: "error", message: err.message });
    }
  };

  const handleStatus = async () => {
    try {
      await patchOrderStatus(detail.order._id, { status: nextStatus });
      notify({ severity: "success", message: COMMON.SUCCESS });
      handleOpen(detail.order);
      reload();
    } catch (err) {
      notify({ severity: "error", message: err.message });
    }
  };

  return (
    <PageStack>
      <PageHeader
        title={ORDERS.TITLE}
        actions={
          canWrite ? (
            <Button variant="contained" onClick={() => navigate(ROUTES.ORDER_NEW)}>
              {ORDERS.NEW}
            </Button>
          ) : null
        }
      />
      <FilterRow>
        <GrowBox>
          <TextField label={ORDERS.SEARCH} value={search} onChange={(event) => setSearch(event.target.value)} />
        </GrowBox>
        <TextField select label={ORDERS.STATUS} value={status} onChange={(event) => setStatus(event.target.value)}>
          <MenuItem value="">{ORDERS.ALL_STATUSES}</MenuItem>
          {ORDER_STATUSES.map((code) => (
            <MenuItem key={code} value={code}>
              {humanize(code)}
            </MenuItem>
          ))}
        </TextField>
      </FilterRow>
      {error ? <ErrorPanel error={error} onRetry={reload} /> : null}
      {isLoading ? <Loader /> : null}
      {!isLoading && !error && !(data || []).length ? <EmptyState message={ORDERS.EMPTY} /> : null}
      {!isLoading && (data || []).length ? (
        <DataTable
          columns={ORDERS.COLUMNS}
          rows={data || []}
          meta={meta}
          onPageChange={(nextPage, nextLimit) => {
            setPage(nextPage);
            setLimit(nextLimit);
          }}
          onRowClick={handleOpen}
          canWrite={canWrite}
          actions={[
            { id: "open", label: "View", onClick: handleOpen },
            { id: "cancel", label: ORDERS.CANCEL, require: "write", onClick: setCancelRow, hidden: (row) => row.status === "CANCELLED" || row.status === "COMPLETED" },
          ]}
        />
      ) : null}

      <SideDrawer anchor="right" open={Boolean(detail)} onClose={() => setDetail(null)}>
        {detail ? (
          <DrawerPaper>
            <Typography variant="h2">{detail.order.orderNumber}</Typography>
            <StatusChip code={detail.order.status} />
            <Typography variant="h4">{ORDERS.DETAIL.PRICE}</Typography>
            <SnapshotBox elevation={0}>
              <Typography>{ORDERS.UNIT_PRICE}: {formatCurrency(detail.order.unitPrice)}</Typography>
              <Typography>{ORDERS.CGST}: {formatCurrency(detail.order.cgstAmount)}</Typography>
              <Typography>{ORDERS.SGST}: {formatCurrency(detail.order.sgstAmount)}</Typography>
              <Typography>{ORDERS.TOTAL}: {formatCurrency(detail.order.totalAmount)}</Typography>
            </SnapshotBox>
            <Typography variant="h4">{ORDERS.DETAIL.HISTORY}</Typography>
            <Stepper orientation="vertical" activeStep={(detail.order.statusHistory || []).length - 1}>
              {(detail.order.statusHistory || []).map((item, index) => (
                <Step key={`${item.status}-${index}`}>
                  <StepLabel>{humanize(item.status)}</StepLabel>
                </Step>
              ))}
            </Stepper>
            <Typography variant="h4">{ORDERS.DETAIL.VISITS}</Typography>
            {(detail.visits || []).map((visit) => (
              <Typography key={visit._id} variant="body2">
                {humanize(visit.visitType)} · {humanize(visit.status)}
                {visit.technician ? "" : ` · ${ORDERS.DETAIL.UNALLOCATED}`}
              </Typography>
            ))}
            {canWrite && detail.order.status === "QUOTED" ? (
              <>
                <TextField
                  type="date"
                  label={ORDERS.SERVICE_DATE}
                  value={confirmValues.date}
                  onChange={(event) => setConfirmValues((current) => ({ ...current, date: event.target.value }))}
                  InputLabelProps={{ shrink: true }}
                />
                <TextField
                  select
                  label={ORDERS.SERVICE_TIME}
                  value={confirmValues.startTime}
                  onChange={(event) => setConfirmValues((current) => ({ ...current, startTime: event.target.value }))}
                >
                  {slots.map((slot) => (
                    <MenuItem key={slot.startTime} value={slot.startTime}>
                      {slot.startTime} – {slot.endTime}
                    </MenuItem>
                  ))}
                </TextField>
                <Button variant="contained" onClick={handleConfirm} disabled={!confirmValues.startTime}>
                  {ORDERS.CONFIRM}
                </Button>
              </>
            ) : null}
            {canWrite && detail.order.status !== "COMPLETED" && detail.order.status !== "CANCELLED" ? (
              <>
                <TextField
                  select
                  label={ORDERS.CHANGE_STATUS}
                  value={nextStatus}
                  onChange={(event) => setNextStatus(event.target.value)}
                >
                  {ORDER_STATUSES.map((code) => (
                    <MenuItem key={code} value={code}>
                      {humanize(code)}
                    </MenuItem>
                  ))}
                </TextField>
                <Button onClick={handleStatus} disabled={!nextStatus}>
                  {ORDERS.CHANGE_STATUS}
                </Button>
              </>
            ) : null}
          </DrawerPaper>
        ) : null}
      </SideDrawer>

      <ConfirmDialog
        open={Boolean(cancelRow)}
        title={CONFIRM.CANCEL_TITLE}
        body={CONFIRM.CANCEL_BODY}
        onClose={() => setCancelRow(null)}
        onConfirm={handleCancel}
      >
        <TextField label={ORDERS.CANCEL_REASON} value={reason} onChange={(event) => setReason(event.target.value)} />
      </ConfirmDialog>
    </PageStack>
  );
};

export default Orders;

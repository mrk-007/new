/**
 * @file Login.jsx
 * @description Sign-in screen wired to POST /auth/login.
 */
import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { APP, LOGIN } from "../../constants/Content.js";
import { ROUTES } from "../../constants/routes.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { usePermission } from "../../hooks/usePermission.js";
import { LoginShell, LoginCard, LoginForm } from "../../theme/styles/login.styles.js";

/** Authenticates and lands on the role home screen. */
export const Login = () => {
  const { login, isAuthenticated, isReady } = useAuth();
  const { isTechnician } = usePermission();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isBusy, setIsBusy] = useState(false);
  const [error, setError] = useState("");

  if (isReady && isAuthenticated) {
    return <Navigate to={isTechnician ? ROUTES.MY_VISITS : ROUTES.DASHBOARD} replace />;
  }

  const handleSubmit = async () => {
    setIsBusy(true);
    setError("");
    try {
      const user = await login(email, password);
      const isTech = user?.role?.roleName === APP.TECHNICIAN_ROLE_NAME;
      navigate(isTech ? ROUTES.MY_VISITS : ROUTES.DASHBOARD, { replace: true });
    } catch {
      setError(LOGIN.ERROR);
    } finally {
      setIsBusy(false);
    }
  };

  return (
    <LoginShell>
      <LoginCard elevation={1}>
        <Typography variant="h1">{LOGIN.TITLE}</Typography>
        <Typography variant="body2" color="text.secondary">
          {LOGIN.SUBTITLE}
        </Typography>
        <LoginForm>
          <TextField
            label={LOGIN.EMAIL}
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            required
          />
          <TextField
            label={LOGIN.PASSWORD}
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            required
          />
          {error ? (
            <Typography color="error" variant="body2">
              {error}
            </Typography>
          ) : null}
          <Button variant="contained" onClick={handleSubmit} disabled={isBusy || !email || !password}>
            {LOGIN.SUBMIT}
          </Button>
        </LoginForm>
      </LoginCard>
    </LoginShell>
  );
};

export default Login;

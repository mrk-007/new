export const Badge = ({ children, variant = "", className = "" }) => {
  const classes = ["badge", variant, className].filter(Boolean).join(" ");
  return <span className={classes}>{children}</span>;
};

export default Badge;

export const Drawer = ({
  isOpen,
  onClose,
  title,
  children,
  wide = false,
}) => {
  if (!isOpen) return null;

  return (
    <div className={`drawer ${isOpen ? "open" : ""}`} onClick={onClose}>
      <div
        className={`panel ${wide ? "wide" : ""}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="panel-head">
          <h2>{title}</h2>
          <button
            type="button"
            className="close"
            onClick={onClose}
            aria-label="Close"
          >
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
};

export default Drawer;

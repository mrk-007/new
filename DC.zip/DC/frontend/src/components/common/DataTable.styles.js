/**
 * @file DataTable.styles.js
 * @description Styled components for standardized tabular data presentation.
 */
import { styled } from "@mui/material/styles";
import TableContainer from "@mui/material/TableContainer";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableBody from "@mui/material/TableBody";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";

export const StyledTableContainer = styled(TableContainer)(() => ({
  overflowX: "auto",
  width: "100%",
}));

export const StyledTable = styled(Table)(() => ({
  width: "100%",
  borderCollapse: "collapse",
}));

export const StyledTableHead = styled(TableHead)(() => ({}));

export const StyledTableBody = styled(TableBody)(() => ({}));

export const StyledTableRow = styled(TableRow)(() => ({}));

export const StyledHeaderCell = styled(TableCell)(({ theme }) => ({
  backgroundColor: theme.palette.background.subtle,
  color: theme.palette.text.secondary,
  fontWeight: 700,
  fontSize: theme.typography.body2.fontSize,
  padding: theme.spacing(1.375),
  borderBottom: `${theme.shape.borderWidth} solid ${theme.palette.divider}`,
  whiteSpace: "nowrap",
  textAlign: "left",
  fontFamily: theme.typography.fontFamily,
}));

export const StyledBodyCell = styled(TableCell)(({ theme }) => ({
  color: theme.palette.text.primary,
  fontSize: theme.typography.body2.fontSize,
  padding: theme.spacing(1.375),
  borderBottom: `${theme.shape.borderWidth} solid ${theme.palette.divider}`,
  whiteSpace: "nowrap",
  verticalAlign: "middle",
  textAlign: "left",
  fontFamily: theme.typography.fontFamily,
}));

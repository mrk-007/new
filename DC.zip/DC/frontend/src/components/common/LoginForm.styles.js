/**
 * @file LoginForm.styles.js
 * @description Styled components for user credentials login form.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Alert from "@mui/material/Alert";

export const StyledLoginRoot = styled(Box)(({ theme }) => ({
  minHeight: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  backgroundColor: theme.palette.background.default,
  padding: theme.spacing(2),
}));

export const StyledLoginCard = styled(Card)(({ theme }) => ({
  width: "100%",
  maxWidth: theme.spacing(52),
  padding: theme.spacing(4),
  borderRadius: theme.shape.borderRadiusCard,
  backgroundColor: theme.palette.background.paper,
  border: `${theme.shape.borderWidth} solid ${theme.palette.divider}`,
  boxShadow: theme.palette.shadows.card,
}));

export const StyledLoginStack = styled(Stack)(({ theme }) => ({
  gap: theme.spacing(2.5),
  alignItems: "stretch",
}));

export const StyledBrandHeader = styled(Box)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  gap: theme.spacing(1),
  marginBottom: theme.spacing(1),
}));

export const StyledBrandLogo = styled(Box)(({ theme }) => ({
  width: theme.shape.logoSize,
  height: theme.shape.logoSize,
  borderRadius: theme.shape.borderRadiusLogo,
  background: theme.palette.background.brandGradient,
  display: "grid",
  placeItems: "center",
  color: theme.palette.primary.contrastText,
  fontWeight: 900,
  fontSize: theme.typography.h2.fontSize,
}));

export const StyledBrandTitle = styled(Typography)(({ theme }) => ({
  fontFamily: theme.typography.headingFont,
  fontWeight: theme.typography.h1.fontWeight,
  fontSize: theme.typography.h1.fontSize,
  color: theme.palette.text.primary,
}));

export const StyledBrandSubtitle = styled(Typography)(({ theme }) => ({
  fontFamily: theme.typography.fontFamily,
  fontSize: theme.typography.body2.fontSize,
  color: theme.palette.text.secondary,
}));

export const StyledSubmitButton = styled(Button)(({ theme }) => ({
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  padding: theme.spacing(1.25, 2),
  borderRadius: theme.shape.borderRadiusMd,
  fontWeight: theme.typography.button.fontWeight,
  fontSize: theme.typography.body1.fontSize,
  "&:hover": {
    backgroundColor: theme.palette.primary.dark,
  },
}));

export const StyledErrorAlert = styled(Alert)(({ theme }) => ({
  borderRadius: theme.shape.borderRadiusSm,
  fontSize: theme.typography.body2.fontSize,
}));

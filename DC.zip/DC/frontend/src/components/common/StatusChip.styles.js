/**
 * @file StatusChip.styles.js
 * @description Styled components mapping semantic status tones to palette background and text colors.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";

export const StyledStatusChip = styled(Box, {
  shouldForwardProp: (prop) => prop !== "tone",
})(({ theme, tone = "default" }) => {
  const tonePalette = theme.palette.tones[tone] || theme.palette.tones.default;

  return {
    display: "inline-block",
    padding: theme.spacing(0.625, 1),
    borderRadius: theme.shape.borderRadiusPill,
    fontSize: theme.typography.caption.fontSize,
    fontWeight: theme.typography.caption.fontWeight,
    backgroundColor: tonePalette.bg,
    color: tonePalette.color,
    border: `${theme.shape.borderWidth} solid ${tonePalette.border}`,
    lineHeight: 1.2,
    whiteSpace: "nowrap",
  };
});

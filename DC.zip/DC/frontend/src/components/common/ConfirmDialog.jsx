/**
 * @file ConfirmDialog.jsx
 * @description Destructive-action confirmation.
 */
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { COMMON } from "../../constants/Content.js";

/** Asks the user to confirm a destructive action. */
export const ConfirmDialog = ({ open, title, body, confirmLabel = COMMON.CONFIRM, onClose, onConfirm, isBusy, children }) => (
  <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
    <DialogTitle>{title}</DialogTitle>
    <DialogContent>
      <Typography variant="body2">{body}</Typography>
      {children}
    </DialogContent>
    <DialogActions>
      <Button onClick={onClose}>{COMMON.CANCEL}</Button>
      <Button color="error" variant="contained" onClick={onConfirm} disabled={isBusy}>
        {confirmLabel}
      </Button>
    </DialogActions>
  </Dialog>
);

export default ConfirmDialog;

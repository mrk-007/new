/**
 * @file SectionCard.styles.js
 * @description Styled components for SectionCard container with header and action controls.
 */
import { styled } from "@mui/material/styles";
import Card from "@mui/material/Card";
import Stack from "@mui/material/Stack";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";

export const StyledSectionCard = styled(Card)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  border: `${theme.shape.borderWidth} solid ${theme.palette.divider}`,
  borderRadius: theme.shape.borderRadiusCard,
  boxShadow: theme.palette.shadows.card,
  padding: theme.spacing(2.125),
  marginTop: theme.spacing(1.75),
}));

export const StyledSectionInner = styled(Stack)(({ theme }) => ({
  gap: theme.spacing(1.625),
}));

export const StyledSectionHead = styled(Box)(({ theme }) => ({
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  gap: theme.spacing(1.25),
}));

export const StyledSectionTitle = styled(Typography)(({ theme }) => ({
  color: theme.palette.text.primary,
  fontSize: theme.typography.h2.fontSize,
  fontWeight: theme.typography.h2.fontWeight,
  lineHeight: theme.typography.h2.lineHeight,
  fontFamily: theme.typography.headingFont,
}));

export const StyledSectionAction = styled(Button)(({ theme }) => ({
  border: `${theme.shape.borderWidth} solid ${theme.palette.divider}`,
  borderRadius: theme.shape.borderRadiusMd,
  padding: theme.spacing(1.125, 1.5),
  fontSize: theme.typography.body2.fontSize,
  fontWeight: theme.typography.button.fontWeight,
  color: theme.palette.text.primary,
  backgroundColor: theme.palette.background.paper,
  "&:hover": {
    borderColor: theme.palette.primary.light,
    backgroundColor: theme.palette.background.subtle,
  },
}));

export const StyledSectionBody = styled(Box)(() => ({
  width: "100%",
}));

/**
 * @file FormDialog.jsx
 * @description Config-driven create/edit dialog used by every master and entity form.
 */
import { useEffect, useMemo, useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import { COMMON, STATIC_OPTIONS } from "../../constants/Content.js";
import { listMaster } from "../../services/api.js";
import { idOf, toOptions } from "../../utils/format.js";
import { FormStack } from "../../theme/styles/common.styles.js";

/** Returns true when a field should render for the current values. */
const isVisible = (field, values, optionMap) => {
  const rule = field.visibleWhen;
  if (!rule) return true;
  const selected = values[rule.field];
  if (rule.equals && !rule.optionAttr) return selected === rule.equals;
  const options = optionMap[field.visibleWhen.field] || optionMap[`${rule.field}Options`] || [];
  const match = options.find((opt) => String(opt.value) === String(selected));
  if (!match) return false;
  return match[rule.optionAttr] === rule.equals;
};

/** Coerces form values to API types. */
const serialize = (fields, values, optionMap) => {
  const body = {};
  fields.forEach((field) => {
    if (!isVisible(field, values, optionMap)) return;
    let value = values[field.name];
    if (field.type === "number") value = value === "" || value === undefined ? undefined : Number(value);
    if (field.type === "switch") value = Boolean(value);
    if (field.type === "select" && value === "") value = undefined;
    if (value !== undefined) body[field.name] = value;
  });
  return body;
};

/** Maps API field errors onto a name->message object. */
const mapErrors = (errors = []) => {
  const next = {};
  errors.forEach((item) => {
    if (item?.field) next[item.field] = item.message;
  });
  return next;
};

/** Config-driven form dialog. */
export const FormDialog = ({
  open,
  title,
  fields,
  initialValues,
  onClose,
  onSubmit,
  isBusy,
  extraOptions,
}) => {
  const [values, setValues] = useState({});
  const [fieldErrors, setFieldErrors] = useState({});
  const [optionMap, setOptionMap] = useState({});

  const refs = useMemo(
    () => [...new Set(fields.filter((field) => field.ref).map((field) => field.ref))],
    [fields]
  );

  useEffect(() => {
    if (!open) return;
    const seed = {};
    fields.forEach((field) => {
      const raw = initialValues?.[field.name];
      if (field.type === "switch") seed[field.name] = Boolean(raw);
      else if (field.type === "select") seed[field.name] = idOf(raw);
      else if (raw === null || raw === undefined) seed[field.name] = "";
      else seed[field.name] = raw;
    });
    setValues(seed);
    setFieldErrors({});
  }, [open, fields, initialValues]);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const load = async () => {
      const next = { ...extraOptions };
      for (const endpoint of refs) {
        const result = await listMaster(endpoint, { limit: 100 });
        const rows = result.data || [];
        const labelKey = endpoint === "roles" ? "roleName" : "name";
        next[endpoint] = toOptions(rows, labelKey);
        next[`${endpoint}Options`] = next[endpoint];
      }
      fields.forEach((field) => {
        if (field.visibleWhen?.field) {
          const source = field.visibleWhen.field;
          const refField = fields.find((item) => item.name === source);
          if (refField?.ref) next[source] = next[refField.ref];
        }
      });
      if (!cancelled) setOptionMap(next);
    };
    load();
    return () => {
      cancelled = true;
    };
  }, [open, refs, extraOptions, fields]);

  const handleChange = (name, value) => {
    setValues((current) => ({ ...current, [name]: value }));
  };

  const handleSubmit = async () => {
    const local = {};
    fields.forEach((field) => {
      const required = field.required || (field.requiredOnCreate && !initialValues);
      if (required && isVisible(field, values, optionMap) && !values[field.name] && values[field.name] !== 0) {
        local[field.name] = COMMON.REQUIRED;
      }
    });
    if (Object.keys(local).length) {
      setFieldErrors(local);
      return;
    }
    try {
      await onSubmit(serialize(fields, values, optionMap));
    } catch (err) {
      setFieldErrors(mapErrors(err.errors));
    }
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{title}</DialogTitle>
      <DialogContent>
        <FormStack>
          {fields.map((field) => {
            if (!isVisible(field, values, optionMap)) return null;
            if (field.type === "switch") {
              return (
                <FormControlLabel
                  key={field.name}
                  control={
                    <Switch
                      checked={Boolean(values[field.name])}
                      onChange={(event) => handleChange(field.name, event.target.checked)}
                    />
                  }
                  label={field.label}
                />
              );
            }
            const options =
              (field.ref && optionMap[field.ref]) ||
              (field.optionsKey && (optionMap[field.optionsKey] || STATIC_OPTIONS[field.optionsKey])) ||
              [];
            return (
              <TextField
                key={field.name}
                label={field.label}
                type={field.type === "number" ? "number" : field.type === "password" ? "password" : field.type === "time" ? "time" : field.type === "date" ? "date" : "text"}
                value={values[field.name] ?? ""}
                onChange={(event) => handleChange(field.name, event.target.value)}
                required={field.required}
                error={Boolean(fieldErrors[field.name])}
                helperText={fieldErrors[field.name]}
                select={field.type === "select"}
                InputLabelProps={field.type === "date" || field.type === "time" ? { shrink: true } : undefined}
              >
                {field.type === "select"
                  ? [
                      <MenuItem key="empty" value="">
                        —
                      </MenuItem>,
                      ...options.map((opt) => (
                        <MenuItem key={opt.value} value={opt.value}>
                          {opt.label}
                        </MenuItem>
                      )),
                    ]
                  : null}
              </TextField>
            );
          })}
        </FormStack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{COMMON.CANCEL}</Button>
        <Button variant="contained" onClick={handleSubmit} disabled={isBusy}>
          {COMMON.SAVE}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FormDialog;

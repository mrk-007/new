/**
 * @file LoginForm.jsx
 * @description Credentials authentication login form with JWT token dispatch and routing.
 */
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import TextField from "@mui/material/TextField";
import { useAuth } from "../../context/AuthContext.jsx";
import { ROUTES } from "../../constants/routes.js";
import {
  StyledLoginRoot,
  StyledLoginCard,
  StyledLoginStack,
  StyledBrandHeader,
  StyledBrandLogo,
  StyledBrandTitle,
  StyledBrandSubtitle,
  StyledSubmitButton,
  StyledErrorAlert,
} from "./LoginForm.styles.js";

/**
 * Renders the user login form view and handles submission.
 */
export const LoginForm = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [submitting, setSubmitting] = useState(false);

  /**
   * Dispatches login credentials to backend API and navigates to dashboard.
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg("");
    setSubmitting(true);
    try {
      await login(email, password);
      navigate(ROUTES.DASHBOARD, { replace: true });
    } catch (err) {
      setErrorMsg(err.message || "Failed to sign in. Please verify credentials.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <StyledLoginRoot>
      <StyledLoginCard>
        <form onSubmit={handleSubmit}>
          <StyledLoginStack>
            <StyledBrandHeader>
              <StyledBrandLogo>JH</StyledBrandLogo>
              <StyledBrandTitle>Jolly Home Needs</StyledBrandTitle>
              <StyledBrandSubtitle>Operations &amp; Dispatch Portal</StyledBrandSubtitle>
            </StyledBrandHeader>

            {errorMsg && <StyledErrorAlert severity="error">{errorMsg}</StyledErrorAlert>}

            <TextField
              label="Email Address"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              fullWidth
              autoComplete="email"
              autoFocus
            />

            <TextField
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              fullWidth
              autoComplete="current-password"
            />

            <StyledSubmitButton type="submit" variant="contained" disabled={submitting} fullWidth>
              {submitting ? "Signing in..." : "Sign In"}
            </StyledSubmitButton>
          </StyledLoginStack>
        </form>
      </StyledLoginCard>
    </StyledLoginRoot>
  );
};

export default LoginForm;

/**
 * @file SectionCard.jsx
 * @description Card section wrapper with standardized header, title, and action button.
 */
import {
  StyledSectionCard,
  StyledSectionInner,
  StyledSectionHead,
  StyledSectionTitle,
  StyledSectionAction,
  StyledSectionBody,
} from "./SectionCard.styles.js";

/**
 * Renders a structured dashboard section card with optional header action.
 */
export const SectionCard = ({ title, actionLabel, onActionClick, children }) => {
  return (
    <StyledSectionCard>
      <StyledSectionInner>
        <StyledSectionHead>
          <StyledSectionTitle>{title}</StyledSectionTitle>
          {actionLabel && (
            <StyledSectionAction onClick={onActionClick}>{actionLabel}</StyledSectionAction>
          )}
        </StyledSectionHead>
        <StyledSectionBody>{children}</StyledSectionBody>
      </StyledSectionInner>
    </StyledSectionCard>
  );
};

export default SectionCard;

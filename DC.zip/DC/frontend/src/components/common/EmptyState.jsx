/**
 * @file EmptyState.jsx
 * @description Empty list placeholder.
 */
import Typography from "@mui/material/Typography";
import InboxOutlined from "@mui/icons-material/InboxOutlined";
import { COMMON } from "../../constants/Content.js";
import { EmptyBox } from "../../theme/styles/common.styles.js";

/** Renders an empty-state message. */
export const EmptyState = ({ message = COMMON.EMPTY }) => (
  <EmptyBox>
    <InboxOutlined color="disabled" fontSize="large" />
    <Typography variant="body2">{message}</Typography>
  </EmptyBox>
);

export default EmptyState;

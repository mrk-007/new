/**
 * @file EmptyState.jsx
 * @description Standardized empty state feedback view when no data records are found.
 */
import { StyledEmptyRoot, StyledEmptyInner, StyledEmptyMessage } from "./EmptyState.styles.js";

/**
 * Renders an empty data placeholder state.
 */
export const EmptyState = ({ message = "No records found." }) => {
  return (
    <StyledEmptyRoot>
      <StyledEmptyInner>
        <StyledEmptyMessage>{message}</StyledEmptyMessage>
      </StyledEmptyInner>
    </StyledEmptyRoot>
  );
};

export default EmptyState;

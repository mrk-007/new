/**
 * @file Loader.styles.js
 * @description Styled components for loading indicator placeholder.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import CircularProgress from "@mui/material/CircularProgress";

export const StyledLoaderRoot = styled(Box)(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  padding: theme.spacing(4.375),
  width: "100%",
}));

export const StyledLoaderInner = styled(Stack)(({ theme }) => ({
  alignItems: "center",
  gap: theme.spacing(1.5),
}));

export const StyledSpinner = styled(CircularProgress)(({ theme }) => ({
  color: theme.palette.primary.main,
}));

export const StyledLoaderMessage = styled(Typography)(({ theme }) => ({
  color: theme.palette.text.secondary,
  fontSize: theme.typography.body2.fontSize,
  fontFamily: theme.typography.fontFamily,
}));

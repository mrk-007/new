/**
 * @file PageHeader.jsx
 * @description Page title plus optional actions.
 */
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import { HeaderRow } from "../../theme/styles/common.styles.js";

/** Renders a screen heading and action slot. */
export const PageHeader = ({ title, subtitle, actions }) => (
  <HeaderRow>
    <Stack>
      <Typography variant="h1">{title}</Typography>
      {subtitle ? (
        <Typography variant="body2" color="text.secondary">
          {subtitle}
        </Typography>
      ) : null}
    </Stack>
    {actions}
  </HeaderRow>
);

export default PageHeader;

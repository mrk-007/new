/**
 * @file PageHeader.jsx
 * @description Standardized page header component presenting title, contextual subtitle, and actions.
 */
import {
  StyledHeaderRoot,
  StyledHeaderStack,
  StyledHeaderTitle,
  StyledHeaderSubtitle,
  StyledHeaderActions,
} from "./PageHeader.styles.js";

/**
 * Renders a standardized page header.
 */
export const PageHeader = ({ title, subtitle, actions }) => {
  return (
    <StyledHeaderRoot>
      <StyledHeaderStack>
        <StyledHeaderTitle>{title}</StyledHeaderTitle>
        {subtitle && <StyledHeaderSubtitle>{subtitle}</StyledHeaderSubtitle>}
      </StyledHeaderStack>
      {actions && <StyledHeaderActions>{actions}</StyledHeaderActions>}
    </StyledHeaderRoot>
  );
};

export default PageHeader;

/**
 * @file StatCard.styles.js
 * @description Styled components for the KPI StatCard component.
 */
import { styled } from "@mui/material/styles";
import Card from "@mui/material/Card";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";

export const StyledStatCard = styled(Card)(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
  border: `${theme.shape.borderWidth} solid ${theme.palette.divider}`,
  borderRadius: theme.shape.borderRadiusCard,
  boxShadow: theme.palette.shadows.card,
  padding: theme.spacing(2),
}));

export const StyledStatInner = styled(Stack)(({ theme }) => ({
  gap: theme.spacing(1),
}));

export const StyledStatLabel = styled(Typography)(({ theme }) => ({
  color: theme.palette.text.secondary,
  fontSize: theme.typography.body2.fontSize,
  lineHeight: theme.typography.body2.lineHeight,
  fontFamily: theme.typography.fontFamily,
}));

export const StyledStatValue = styled(Typography)(({ theme }) => ({
  color: theme.palette.text.primary,
  fontSize: theme.typography.h1.fontSize,
  fontWeight: theme.typography.h1.fontWeight,
  lineHeight: theme.typography.h1.lineHeight,
  fontFamily: theme.typography.headingFont,
}));

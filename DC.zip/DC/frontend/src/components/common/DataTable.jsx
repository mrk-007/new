/**
 * @file DataTable.jsx
 * @description Standardized table layout receiving column definitions and row child nodes.
 */
import {
  StyledTableContainer,
  StyledTable,
  StyledTableHead,
  StyledTableBody,
  StyledTableRow,
  StyledHeaderCell,
  StyledBodyCell,
} from "./DataTable.styles.js";

/**
 * Renders an accessible data table with styled header and rows.
 */
export const DataTable = ({ columns = [], children }) => {
  return (
    <StyledTableContainer>
      <StyledTable>
        <StyledTableHead>
          <StyledTableRow>
            {columns.map((col, idx) => (
              <StyledHeaderCell key={typeof col === "string" ? col : idx}>
                {typeof col === "string" ? col : col.header}
              </StyledHeaderCell>
            ))}
          </StyledTableRow>
        </StyledTableHead>
        <StyledTableBody>{children}</StyledTableBody>
      </StyledTable>
    </StyledTableContainer>
  );
};

export { StyledTableRow as DataTableRow, StyledBodyCell as DataTableCell };
export default DataTable;

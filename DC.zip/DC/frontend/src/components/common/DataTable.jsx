/**
 * @file DataTable.jsx
 * @description Server-paginated table that collapses to cards on small screens.
 */
import { useState } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TablePagination from "@mui/material/TablePagination";
import IconButton from "@mui/material/IconButton";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import MoreVert from "@mui/icons-material/MoreVert";
import { COMMON } from "../../constants/Content.js";
import { formatCurrency, formatDate, formatDateTime, formatTime, getByPath, humanize } from "../../utils/format.js";
import StatusChip from "./StatusChip.jsx";
import {
  DesktopTable,
  MobileCard,
  MobileCardList,
  TablePaper,
} from "../../theme/styles/common.styles.js";

/** Formats a cell from column flags. */
const renderValue = (row, column) => {
  const value = getByPath(row, column.key);
  if (column.status) return <StatusChip code={value} />;
  if (column.currency) return formatCurrency(value);
  if (column.datetime) return formatDateTime(value);
  if (column.date) return formatDate(value);
  if (column.time) return formatTime(value);
  if (column.boolean) return humanize(Boolean(value));
  if (value === null || value === undefined || value === "") return "—";
  return String(value);
};

/** Compact row-action menu. */
const RowMenu = ({ row, actions, canWrite, canDelete }) => {
  const [anchor, setAnchor] = useState(null);
  const visible = (actions || []).filter((action) => {
    if (action.require === "write" && !canWrite) return false;
    if (action.require === "delete" && !canDelete) return false;
    if (action.hidden?.(row)) return false;
    return true;
  });
  if (!visible.length) return null;
  return (
    <>
      <IconButton aria-label={COMMON.ACTIONS} onClick={(event) => setAnchor(event.currentTarget)}>
        <MoreVert />
      </IconButton>
      <Menu open={Boolean(anchor)} anchorEl={anchor} onClose={() => setAnchor(null)}>
        {visible.map((action) => (
          <MenuItem
            key={action.id}
            onClick={() => {
              setAnchor(null);
              action.onClick(row);
            }}
          >
            {action.label}
          </MenuItem>
        ))}
      </Menu>
    </>
  );
};

/** Renders a paginated data table with mobile cards. */
export const DataTable = ({
  columns,
  rows = [],
  meta,
  onPageChange,
  onRowClick,
  actions,
  canWrite,
  canDelete,
}) => {
  const page = (meta?.page || 1) - 1;
  const limit = meta?.limit || 20;
  const total = meta?.total || rows.length;

  return (
    <>
      <TablePaper elevation={1}>
        <DesktopTable>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell key={column.key}>{column.label}</TableCell>
                ))}
                {actions?.length ? <TableCell>{COMMON.ACTIONS}</TableCell> : null}
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.map((row) => (
                <TableRow key={row._id || row.id} hover onClick={() => onRowClick?.(row)}>
                  {columns.map((column) => (
                    <TableCell key={column.key}>{renderValue(row, column)}</TableCell>
                  ))}
                  {actions?.length ? (
                    <TableCell onClick={(event) => event.stopPropagation()}>
                      <RowMenu row={row} actions={actions} canWrite={canWrite} canDelete={canDelete} />
                    </TableCell>
                  ) : null}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DesktopTable>
        <TablePagination
          component="div"
          count={total}
          page={page}
          rowsPerPage={limit}
          onPageChange={(_e, next) => onPageChange?.(next + 1, limit)}
          onRowsPerPageChange={(event) => onPageChange?.(1, Number(event.target.value))}
          rowsPerPageOptions={[10, 20, 50]}
        />
      </TablePaper>
      <MobileCardList>
        {rows.map((row) => (
          <MobileCard key={row._id || row.id} elevation={1} onClick={() => onRowClick?.(row)}>
            <Stack>
              {columns.slice(0, 4).map((column) => (
                <Typography key={column.key} variant="body2">
                  {column.label}: {column.status || column.currency || column.boolean ? null : renderValue(row, column)}
                </Typography>
              ))}
              {columns.some((column) => column.status) ? renderValue(row, columns.find((column) => column.status)) : null}
              <RowMenu row={row} actions={actions} canWrite={canWrite} canDelete={canDelete} />
            </Stack>
          </MobileCard>
        ))}
      </MobileCardList>
    </>
  );
};

export default DataTable;

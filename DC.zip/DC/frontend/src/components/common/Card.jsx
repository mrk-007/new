export const Card = ({ children, className = "", onClick }) => {
  const classes = ["card", className].filter(Boolean).join(" ");
  return (
    <div className={classes} onClick={onClick}>
      {children}
    </div>
  );
};

export default Card;

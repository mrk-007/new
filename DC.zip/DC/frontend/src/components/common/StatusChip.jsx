/**
 * @file StatusChip.jsx
 * @description Status indicator badge mapping semantic backend tone to theme palette styles.
 */
import { StyledStatusChip } from "./StatusChip.styles.js";

/**
 * Renders a semantic status chip corresponding to backend tone.
 */
export const StatusChip = ({ label, tone = "default" }) => {
  return <StyledStatusChip tone={tone}>{label}</StyledStatusChip>;
};

export default StatusChip;

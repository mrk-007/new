/**
 * @file StatusChip.jsx
 * @description Status chip whose tone comes from the theme map.
 */
import { humanize } from "../../utils/format.js";
import { StatusToneChip } from "../../theme/styles/common.styles.js";

/** Renders a backend status code with the matching tone. */
export const StatusChip = ({ code, label }) => {
  const tone = code || "DEFAULT";
  return <StatusToneChip size="small" tone={tone} label={label || humanize(code)} />;
};

export default StatusChip;

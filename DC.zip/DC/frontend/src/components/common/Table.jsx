export const Table = ({ children, className = "" }) => {
  const classes = ["table", className].filter(Boolean).join(" ");
  return (
    <div className={classes}>
      <table>{children}</table>
    </div>
  );
};

export default Table;

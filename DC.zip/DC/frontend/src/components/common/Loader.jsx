/**
 * @file Loader.jsx
 * @description Centralized loading spinner component with customizable text message.
 */
import {
  StyledLoaderRoot,
  StyledLoaderInner,
  StyledSpinner,
  StyledLoaderMessage,
} from "./Loader.styles.js";

/**
 * Renders an accessible loading spinner indicator.
 */
export const Loader = ({ message = "Loading data..." }) => {
  return (
    <StyledLoaderRoot>
      <StyledLoaderInner>
        <StyledSpinner size={32} />
        <StyledLoaderMessage>{message}</StyledLoaderMessage>
      </StyledLoaderInner>
    </StyledLoaderRoot>
  );
};

export default Loader;

/**
 * @file Loader.jsx
 * @description Centered loading skeleton/spinner block.
 */
import CircularProgress from "@mui/material/CircularProgress";
import Typography from "@mui/material/Typography";
import { COMMON } from "../../constants/Content.js";
import { LoaderBox } from "../../theme/styles/common.styles.js";

/** Renders a blocking loading state. */
export const Loader = ({ message = COMMON.LOADING }) => (
  <LoaderBox>
    <CircularProgress />
    <Typography variant="body2">{message}</Typography>
  </LoaderBox>
);

export default Loader;

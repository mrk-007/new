export const Loader = ({ message = "Loading..." }) => {
  return (
    <div className="empty">
      <div className="sub">{message}</div>
    </div>
  );
};

export default Loader;

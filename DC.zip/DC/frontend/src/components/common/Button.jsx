export const Button = ({
  children,
  variant = "",
  type = "button",
  onClick,
  disabled = false,
  className = "",
  title,
}) => {
  const classes = ["btn", variant, className].filter(Boolean).join(" ");
  return (
    <button
      type={type}
      className={classes}
      onClick={onClick}
      disabled={disabled}
      title={title}
    >
      {children}
    </button>
  );
};

export default Button;

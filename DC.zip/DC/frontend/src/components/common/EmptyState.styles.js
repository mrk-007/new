/**
 * @file EmptyState.styles.js
 * @description Styled components for empty state placeholder view.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";

export const StyledEmptyRoot = styled(Box)(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  padding: theme.spacing(4.375),
  width: "100%",
}));

export const StyledEmptyInner = styled(Stack)(({ theme }) => ({
  alignItems: "center",
  gap: theme.spacing(1),
}));

export const StyledEmptyMessage = styled(Typography)(({ theme }) => ({
  color: theme.palette.text.secondary,
  fontSize: theme.typography.body1.fontSize,
  fontFamily: theme.typography.fontFamily,
}));

/**
 * @file StatCard.jsx
 * @description KPI metric stat card displaying label and bold primary numerical value.
 */
import {
  StyledStatCard,
  StyledStatInner,
  StyledStatLabel,
  StyledStatValue,
} from "./StatCard.styles.js";

/**
 * Renders an operational KPI stat card.
 */
export const StatCard = ({ label, value }) => {
  return (
    <StyledStatCard>
      <StyledStatInner>
        <StyledStatLabel>{label}</StyledStatLabel>
        <StyledStatValue>{value}</StyledStatValue>
      </StyledStatInner>
    </StyledStatCard>
  );
};

export default StatCard;

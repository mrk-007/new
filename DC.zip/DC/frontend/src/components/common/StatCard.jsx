/**
 * @file StatCard.jsx
 * @description KPI tile used on the dashboard.
 */
import Typography from "@mui/material/Typography";
import { StatRoot, StatValue } from "../../theme/styles/common.styles.js";

/** Renders a labelled metric. */
export const StatCard = ({ label, value }) => (
  <StatRoot elevation={1}>
    <Typography variant="caption" color="text.secondary">
      {label}
    </Typography>
    <StatValue>{value ?? "—"}</StatValue>
  </StatRoot>
);

export default StatCard;

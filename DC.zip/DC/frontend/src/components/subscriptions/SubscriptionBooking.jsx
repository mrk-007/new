/**
 * @file SubscriptionBooking.jsx
 * @description New-subscription wizard using plan pricingBasis for bathroom vs property.
 */
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import Typography from "@mui/material/Typography";
import { COMMON, ORDERS, SUBSCRIPTIONS } from "../../constants/Content.js";
import { ROUTES } from "../../constants/routes.js";
import {
  createSubscription,
  getAvailableSlots,
  getQuote,
  listAddresses,
  listCustomers,
  listMaster,
} from "../../services/api.js";
import { useNotifier } from "../../context/NotifierContext.jsx";
import { formatCurrency, idOf, todayIstDate } from "../../utils/format.js";
import PageHeader from "../common/PageHeader.jsx";
import { FilterRow, PageStack } from "../../theme/styles/common.styles.js";
import { SnapshotBox, WizardCard } from "../../theme/styles/feature.styles.js";

/** Creates a subscription from customer, plan, term, frequency, slot, and quote. */
export const SubscriptionBooking = () => {
  const navigate = useNavigate();
  const { notify } = useNotifier();
  const [customers, setCustomers] = useState([]);
  const [addresses, setAddresses] = useState([]);
  const [plans, setPlans] = useState([]);
  const [terms, setTerms] = useState([]);
  const [frequencies, setFrequencies] = useState([]);
  const [bathrooms, setBathrooms] = useState([]);
  const [sizes, setSizes] = useState([]);
  const [slots, setSlots] = useState([]);
  const [quote, setQuote] = useState(null);
  const [isBusy, setIsBusy] = useState(false);
  const [values, setValues] = useState({
    customer: "",
    address: "",
    subscriptionPlan: "",
    subscriptionTerm: "",
    serviceFrequency: "",
    bathroomCount: "",
    propertySize: "",
    startDate: todayIstDate(),
    preferredStartTime: "",
  });

  const plan = plans.find((row) => idOf(row) === values.subscriptionPlan);
  const isBathroom = plan?.pricingBasis === "BATHROOM_COUNT";

  useEffect(() => {
    const load = async () => {
      const [c, p, t, f, b, s] = await Promise.all([
        listCustomers({ limit: 100 }),
        listMaster("subscription-plans", { limit: 100 }),
        listMaster("subscription-terms", { limit: 100 }),
        listMaster("service-frequencies", { limit: 100 }),
        listMaster("bathroom-counts", { limit: 100 }),
        listMaster("property-sizes", { limit: 100 }),
      ]);
      setCustomers(c.data || []);
      setPlans(p.data || []);
      setTerms(t.data || []);
      setFrequencies(f.data || []);
      setBathrooms(b.data || []);
      setSizes(s.data || []);
    };
    load();
  }, []);

  useEffect(() => {
    if (!values.customer) return;
    listAddresses(values.customer).then((result) => setAddresses(result.data || []));
  }, [values.customer]);

  useEffect(() => {
    if (!values.subscriptionPlan || !values.startDate) return;
    const params = { date: values.startDate, subscriptionPlanId: values.subscriptionPlan };
    if (values.bathroomCount) params.bathroomCountId = values.bathroomCount;
    if (values.propertySize) params.propertySizeId = values.propertySize;
    getAvailableSlots(params)
      .then((result) => setSlots((result.data || []).filter((slot) => slot.available)))
      .catch(() => setSlots([]));
  }, [values.subscriptionPlan, values.startDate, values.bathroomCount, values.propertySize]);

  useEffect(() => {
    if (!values.subscriptionPlan || !values.address || !values.subscriptionTerm || !values.serviceFrequency) {
      setQuote(null);
      return;
    }
    const params = {
      subscriptionPlanId: values.subscriptionPlan,
      subscriptionTermId: values.subscriptionTerm,
      serviceFrequencyId: values.serviceFrequency,
      addressId: values.address,
    };
    if (values.bathroomCount) params.bathroomCountId = values.bathroomCount;
    if (values.propertySize) params.propertySizeId = values.propertySize;
    getQuote(params)
      .then((result) => setQuote(result.data))
      .catch(() => setQuote(null));
  }, [
    values.subscriptionPlan,
    values.address,
    values.subscriptionTerm,
    values.serviceFrequency,
    values.bathroomCount,
    values.propertySize,
  ]);

  const handleChange = (name, value) => setValues((current) => ({ ...current, [name]: value }));

  const handleCreate = async () => {
    setIsBusy(true);
    try {
      const body = {
        customer: values.customer,
        address: values.address,
        subscriptionPlan: values.subscriptionPlan,
        subscriptionTerm: values.subscriptionTerm,
        serviceFrequency: values.serviceFrequency,
        startDate: values.startDate,
        preferredStartTime: values.preferredStartTime,
      };
      if (isBathroom) body.bathroomCount = values.bathroomCount;
      else body.propertySize = values.propertySize;
      await createSubscription(body);
      notify({ severity: "success", message: COMMON.SUCCESS });
      navigate(ROUTES.SUBSCRIPTIONS);
    } catch (err) {
      notify({ severity: "error", message: err.message });
    } finally {
      setIsBusy(false);
    }
  };

  return (
    <PageStack>
      <PageHeader title={SUBSCRIPTIONS.WIZARD.TITLE} />
      <WizardCard elevation={1}>
        <TextField select label={ORDERS.WIZARD.CUSTOMER} value={values.customer} onChange={(event) => handleChange("customer", event.target.value)}>
          {customers.map((row) => (
            <MenuItem key={row._id} value={row._id}>{row.fullName}</MenuItem>
          ))}
        </TextField>
        <TextField select label={ORDERS.WIZARD.ADDRESS} value={values.address} onChange={(event) => handleChange("address", event.target.value)}>
          {addresses.map((row) => (
            <MenuItem key={row._id} value={row._id}>{row.label} — {row.city}</MenuItem>
          ))}
        </TextField>
        <TextField select label={SUBSCRIPTIONS.WIZARD.PLAN} value={values.subscriptionPlan} onChange={(event) => handleChange("subscriptionPlan", event.target.value)}>
          {plans.map((row) => (
            <MenuItem key={row._id} value={row._id}>{row.name}</MenuItem>
          ))}
        </TextField>
        {isBathroom ? (
          <TextField select label={SUBSCRIPTIONS.WIZARD.BATHROOM} value={values.bathroomCount} onChange={(event) => handleChange("bathroomCount", event.target.value)}>
            {bathrooms.map((row) => (
              <MenuItem key={row._id} value={row._id}>{row.name}</MenuItem>
            ))}
          </TextField>
        ) : (
          <TextField select label={SUBSCRIPTIONS.WIZARD.PROPERTY} value={values.propertySize} onChange={(event) => handleChange("propertySize", event.target.value)}>
            {sizes.map((row) => (
              <MenuItem key={row._id} value={row._id}>{row.name}</MenuItem>
            ))}
          </TextField>
        )}
        <TextField select label={SUBSCRIPTIONS.WIZARD.TERM} value={values.subscriptionTerm} onChange={(event) => handleChange("subscriptionTerm", event.target.value)}>
          {terms.map((row) => (
            <MenuItem key={row._id} value={row._id}>{row.name}</MenuItem>
          ))}
        </TextField>
        <TextField select label={SUBSCRIPTIONS.WIZARD.FREQUENCY} value={values.serviceFrequency} onChange={(event) => handleChange("serviceFrequency", event.target.value)}>
          {frequencies.map((row) => (
            <MenuItem key={row._id} value={row._id}>{row.name}</MenuItem>
          ))}
        </TextField>
        <TextField type="date" label={SUBSCRIPTIONS.WIZARD.START} value={values.startDate} onChange={(event) => handleChange("startDate", event.target.value)} InputLabelProps={{ shrink: true }} />
        <TextField select label={SUBSCRIPTIONS.WIZARD.SLOT} value={values.preferredStartTime} onChange={(event) => handleChange("preferredStartTime", event.target.value)}>
          {slots.map((slot) => (
            <MenuItem key={slot.startTime} value={slot.startTime}>{slot.startTime} – {slot.endTime}</MenuItem>
          ))}
        </TextField>
        {quote ? (
          <SnapshotBox elevation={0}>
            <Typography>{ORDERS.TOTAL}: {formatCurrency(quote.totalAmount)}</Typography>
            <Typography>{ORDERS.CGST}: {formatCurrency(quote.cgstAmount)}</Typography>
          </SnapshotBox>
        ) : null}
        <FilterRow>
          <Button onClick={() => navigate(ROUTES.SUBSCRIPTIONS)}>{COMMON.CANCEL}</Button>
          <Button variant="contained" disabled={isBusy || !values.preferredStartTime} onClick={handleCreate}>
            {SUBSCRIPTIONS.WIZARD.SUBMIT}
          </Button>
        </FilterRow>
      </WizardCard>
    </PageStack>
  );
};

export default SubscriptionBooking;

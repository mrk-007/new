/**
 * @file Subscriptions.jsx
 * @description Subscription list, visit progress drawer, and cancel.
 */
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import LinearProgress from "@mui/material/LinearProgress";
import { COMMON, CONFIRM, ORDERS, SUBSCRIPTIONS, VISITS } from "../../constants/Content.js";
import { ROUTES } from "../../constants/routes.js";
import { cancelSubscription, getSubscription, listSubscriptions } from "../../services/api.js";
import { useApi } from "../../hooks/useApi.js";
import { useDebounce } from "../../hooks/useDebounce.js";
import { usePermission } from "../../hooks/usePermission.js";
import { useNotifier } from "../../context/NotifierContext.jsx";
import { formatCurrency, humanize } from "../../utils/format.js";
import PageHeader from "../common/PageHeader.jsx";
import DataTable from "../common/DataTable.jsx";
import Loader from "../common/Loader.jsx";
import EmptyState from "../common/EmptyState.jsx";
import ConfirmDialog from "../common/ConfirmDialog.jsx";
import StatusChip from "../common/StatusChip.jsx";
import { ErrorBanner, FilterRow, GrowBox, PageStack } from "../../theme/styles/common.styles.js";
import { DrawerPaper, SideDrawer, SnapshotBox } from "../../theme/styles/feature.styles.js";

/** Retryable error strip. */
const ErrorPanel = ({ error, onRetry }) => (
  <ErrorBanner elevation={0}>
    <Typography color="error">{error?.message}</Typography>
    <Button onClick={onRetry}>{COMMON.RETRY}</Button>
  </ErrorBanner>
);

/** Subscription list and detail. */
export const Subscriptions = () => {
  const navigate = useNavigate();
  const { canWrite } = usePermission();
  const { notify } = useNotifier();
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [search, setSearch] = useState("");
  const [detail, setDetail] = useState(null);
  const [cancelRow, setCancelRow] = useState(null);
  const [reason, setReason] = useState("");
  const debounced = useDebounce(search);
  const { data, meta, isLoading, error, reload } = useApi(
    () => listSubscriptions({ page, limit, search: debounced }),
    [page, limit, debounced]
  );

  const handleOpen = async (row) => {
    const result = await getSubscription(row._id);
    setDetail(result.data);
  };

  const handleCancel = async () => {
    try {
      await cancelSubscription(cancelRow._id, { cancelReason: reason });
      notify({ severity: "success", message: COMMON.SUCCESS });
      setCancelRow(null);
      setDetail(null);
      reload();
    } catch (err) {
      notify({ severity: "error", message: err.message });
    }
  };

  const visits = detail?.visits || [];
  const serviceVisits = visits.filter((visit) => visit.visitType === "SERVICE");
  const done = serviceVisits.filter((visit) => visit.status === "COMPLETED").length;
  const progress = serviceVisits.length ? Math.round((done / serviceVisits.length) * 100) : 0;

  return (
    <PageStack>
      <PageHeader
        title={SUBSCRIPTIONS.TITLE}
        actions={
          canWrite ? (
            <Button variant="contained" onClick={() => navigate(ROUTES.SUBSCRIPTION_NEW)}>
              {SUBSCRIPTIONS.NEW}
            </Button>
          ) : null
        }
      />
      <FilterRow>
        <GrowBox>
          <TextField label={SUBSCRIPTIONS.SEARCH} value={search} onChange={(event) => setSearch(event.target.value)} />
        </GrowBox>
      </FilterRow>
      {error ? <ErrorPanel error={error} onRetry={reload} /> : null}
      {isLoading ? <Loader /> : null}
      {!isLoading && !error && !(data || []).length ? <EmptyState message={SUBSCRIPTIONS.EMPTY} /> : null}
      {!isLoading && (data || []).length ? (
        <DataTable
          columns={SUBSCRIPTIONS.COLUMNS}
          rows={data || []}
          meta={meta}
          onPageChange={(nextPage, nextLimit) => {
            setPage(nextPage);
            setLimit(nextLimit);
          }}
          onRowClick={handleOpen}
          canWrite={canWrite}
          actions={[
            { id: "open", label: "View", onClick: handleOpen },
            {
              id: "cancel",
              label: SUBSCRIPTIONS.CANCEL,
              require: "write",
              onClick: setCancelRow,
              hidden: (row) => row.status === "CANCELLED" || row.isCompleted,
            },
          ]}
        />
      ) : null}

      <SideDrawer anchor="right" open={Boolean(detail)} onClose={() => setDetail(null)}>
        {detail ? (
          <DrawerPaper>
            <Typography variant="h2">{detail.subscription.subscriptionNumber}</Typography>
            <StatusChip code={detail.subscription.status} />
            <SnapshotBox elevation={0}>
              <Typography>{ORDERS.TOTAL}: {formatCurrency(detail.subscription.totalAmount)}</Typography>
            </SnapshotBox>
            <Typography variant="body2">{progress}%</Typography>
            <LinearProgress variant="determinate" value={progress} />
            {visits.map((visit) => (
              <Typography key={visit._id} variant="body2">
                #{visit.sequenceNo} {humanize(visit.visitType)} · {humanize(visit.status)}
                {visit.isAllocated === false ? ` · ${VISITS.UNALLOCATED}` : ""}
              </Typography>
            ))}
          </DrawerPaper>
        ) : null}
      </SideDrawer>

      <ConfirmDialog
        open={Boolean(cancelRow)}
        title={CONFIRM.CANCEL_TITLE}
        body={CONFIRM.CANCEL_BODY}
        onClose={() => setCancelRow(null)}
        onConfirm={handleCancel}
      >
        <TextField label={VISITS.REASON} value={reason} onChange={(event) => setReason(event.target.value)} />
      </ConfirmDialog>
    </PageStack>
  );
};

export default Subscriptions;

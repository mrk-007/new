/**
 * @file Dashboard.jsx
 * @description KPI, today's flow, lifecycle, and catalog from GET /dashboard.
 */
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Skeleton from "@mui/material/Skeleton";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Table from "@mui/material/Table";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import TableBody from "@mui/material/TableBody";
import { COMMON, DASHBOARD } from "../../constants/Content.js";
import { resolveIcon } from "../../constants/iconMap.js";
import { getDashboard } from "../../services/api.js";
import { useApi } from "../../hooks/useApi.js";
import { formatCurrency } from "../../utils/format.js";
import PageHeader from "../common/PageHeader.jsx";
import StatCard from "../common/StatCard.jsx";
import StatusChip from "../common/StatusChip.jsx";
import EmptyState from "../common/EmptyState.jsx";
import { ErrorBanner, PageStack, TablePaper } from "../../theme/styles/common.styles.js";
import {
  KpiGrid,
  SplitGrid,
  SectionCard,
  CatalogGrid,
  CatalogCard,
  CatalogArt,
} from "../../theme/styles/dashboard.styles.js";

/** Retryable error strip. */
const ErrorPanel = ({ error, onRetry }) => (
  <ErrorBanner elevation={0}>
    <Typography color="error">{error?.message || "Request failed."}</Typography>
    <Button onClick={onRetry}>{COMMON.RETRY}</Button>
  </ErrorBanner>
);

/** Today's flow table using backend chip objects. */
const TodayFlow = ({ rows }) => {
  if (!rows?.length) return <EmptyState message={DASHBOARD.FLOW_EMPTY} />;
  return (
    <TablePaper elevation={0}>
      <Table size="small">
        <TableHead>
          <TableRow>
            {DASHBOARD.FLOW_COLUMNS.map((column) => (
              <TableCell key={column.key}>{column.label}</TableCell>
            ))}
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.id}>
              <TableCell>{row.property}</TableCell>
              <TableCell>{row.work}</TableCell>
              <TableCell>{row.technician}</TableCell>
              <TableCell>
                <StatusChip code={row.arrival?.code} label={row.arrival?.label} />
              </TableCell>
              <TableCell>
                <StatusChip code={row.workStatus?.code} label={row.workStatus?.label} />
              </TableCell>
              <TableCell>
                <StatusChip code={row.followUp?.code} label={row.followUp?.label} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TablePaper>
  );
};

/** Operations dashboard. */
export const Dashboard = () => {
  const { data, isLoading, error, reload } = useApi(() => getDashboard(), []);
  const kpis = data?.kpis || {};
  const lifecycle = data?.lifecycle || {};
  const catalog = data?.catalogPreview || [];

  if (isLoading) {
    return (
      <PageStack>
        <Skeleton variant="text" width={240} height={40} />
        <KpiGrid>
          {[1, 2, 3, 4, 5].map((key) => (
            <Skeleton key={key} variant="rounded" height={110} />
          ))}
        </KpiGrid>
      </PageStack>
    );
  }

  if (error) return <ErrorPanel error={error} onRetry={reload} />;

  return (
    <PageStack>
      <PageHeader title={DASHBOARD.TITLE} />
      <KpiGrid>
        <StatCard label={DASHBOARD.KPI.ordersToday} value={kpis.ordersToday} />
        <StatCard label={DASHBOARD.KPI.jobsToday} value={kpis.jobsToday} />
        <StatCard label={DASHBOARD.KPI.activeSubscriptions} value={kpis.activeSubscriptions} />
        <StatCard label={DASHBOARD.KPI.availableTechnicians} value={kpis.availableTechnicians} />
        <StatCard label={DASHBOARD.KPI.monthCollection} value={kpis.monthCollection} />
      </KpiGrid>
      <SplitGrid>
        <SectionCard elevation={1}>
          <Typography variant="h3">{DASHBOARD.FLOW_TITLE}</Typography>
          <TodayFlow rows={data?.todayFlow} />
        </SectionCard>
        <SectionCard elevation={1}>
          <Typography variant="h3">{lifecycle.title || DASHBOARD.LIFECYCLE_FALLBACK}</Typography>
          <Typography variant="body2" color="text.secondary">
            {lifecycle.notice}
          </Typography>
          <Stepper orientation="vertical" activeStep={-1}>
            {(lifecycle.steps || []).map((step) => (
              <Step key={step} completed={false}>
                <StepLabel>{step}</StepLabel>
              </Step>
            ))}
          </Stepper>
        </SectionCard>
      </SplitGrid>
      <SectionCard elevation={1}>
        <Typography variant="h3">{DASHBOARD.CATALOG_TITLE}</Typography>
        {!catalog.length ? (
          <EmptyState message={DASHBOARD.CATALOG_EMPTY} />
        ) : (
          <CatalogGrid>
            {catalog.map((item) => {
              const Icon = resolveIcon(item.iconKey);
              return (
                <CatalogCard key={item.id} elevation={0}>
                  <CatalogArt>
                    <Icon color="primary" />
                  </CatalogArt>
                  <Typography variant="overline">{item.group}</Typography>
                  <Typography variant="h4">{item.name}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    {item.description}
                  </Typography>
                  {item.price != null ? (
                    <Typography variant="body2">{formatCurrency(item.price)}</Typography>
                  ) : null}
                </CatalogCard>
              );
            })}
          </CatalogGrid>
        )}
      </SectionCard>
    </PageStack>
  );
};

export default Dashboard;

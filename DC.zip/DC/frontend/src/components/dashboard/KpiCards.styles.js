/**
 * @file KpiCards.styles.js
 * @description Styled components for top operational KPI metrics responsive grid.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";

export const StyledKpiGrid = styled(Box)(({ theme }) => ({
  display: "grid",
  gridTemplateColumns: "repeat(5, 1fr)",
  gap: theme.spacing(1.75),
  width: "100%",
  boxSizing: "border-box",
  [theme.breakpoints.down("lg")]: {
    gridTemplateColumns: "repeat(3, 1fr)",
  },
  [theme.breakpoints.down("md")]: {
    gridTemplateColumns: "repeat(2, 1fr)",
  },
  [theme.breakpoints.down("sm")]: {
    gridTemplateColumns: "1fr",
  },
}));

/**
 * @file JobLifecycleNotice.styles.js
 * @description Styled components for Urban-style Job Lifecycle flow steps and execution notice.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";

export const StyledLifecycleInner = styled(Stack)(({ theme }) => ({
  gap: theme.spacing(1.5),
}));

export const StyledFlowContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  gap: theme.spacing(0.75),
  flexWrap: "wrap",
  alignItems: "center",
}));

export const StyledStepChip = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.step,
  color: theme.palette.text.primary,
  borderRadius: theme.shape.borderRadiusPill,
  padding: theme.spacing(0.875, 1.125),
  fontSize: theme.typography.caption.fontSize,
  fontWeight: theme.typography.caption.fontWeight,
  lineHeight: 1.2,
  fontFamily: theme.typography.fontFamily,
}));

export const StyledFlowArrow = styled(Typography)(({ theme }) => ({
  color: theme.palette.text.secondary,
  fontSize: theme.typography.body2.fontSize,
  userSelect: "none",
}));

export const StyledNoticeBox = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.notice,
  color: theme.palette.text.notice,
  padding: theme.spacing(1.375),
  borderRadius: theme.shape.borderRadiusMd,
  fontSize: theme.typography.body2.fontSize,
  lineHeight: theme.typography.body2.lineHeight,
  fontFamily: theme.typography.fontFamily,
}));

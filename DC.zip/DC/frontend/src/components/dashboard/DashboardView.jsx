/**
 * @file DashboardView.jsx
 * @description Operations dashboard view organizing KPI metrics, today's service flow, lifecycle, and catalog.
 */
import useDashboardData from "./useDashboardData.js";
import KpiCards from "./KpiCards.jsx";
import TodayServiceFlow from "./TodayServiceFlow.jsx";
import JobLifecycleNotice from "./JobLifecycleNotice.jsx";
import HomeCatalogSection from "./HomeCatalogSection.jsx";
import Loader from "../common/Loader.jsx";
import EmptyState from "../common/EmptyState.jsx";
import {
  StyledDashboardRoot,
  StyledTwoColumnGrid,
  StyledErrorContainer,
  StyledErrorMessage,
  StyledRetryButton,
} from "./DashboardView.styles.js";

/**
 * Main dashboard container managing live fetch state and rendering dashboard sections.
 */
export const DashboardView = () => {
  const { data, loading, error, reload } = useDashboardData();

  if (loading) {
    return <Loader message="Loading operations dashboard metrics..." />;
  }

  if (error) {
    return (
      <StyledErrorContainer>
        <StyledErrorMessage>{error}</StyledErrorMessage>
        <StyledRetryButton onClick={reload}>Retry</StyledRetryButton>
      </StyledErrorContainer>
    );
  }

  if (!data) {
    return <EmptyState message="No operations data available." />;
  }

  return (
    <StyledDashboardRoot>
      <KpiCards kpis={data.kpis} />
      <StyledTwoColumnGrid>
        <TodayServiceFlow items={data.todayFlow} />
        <JobLifecycleNotice lifecycle={data.lifecycle} />
      </StyledTwoColumnGrid>
      <HomeCatalogSection items={data.catalogPreview} />
    </StyledDashboardRoot>
  );
};

export default DashboardView;

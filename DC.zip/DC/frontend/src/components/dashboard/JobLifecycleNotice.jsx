/**
 * @file JobLifecycleNotice.jsx
 * @description Urban-style Job Lifecycle visualization displaying dynamic steps and execution notice from Master data.
 */
import { Fragment } from "react";
import SectionCard from "../common/SectionCard.jsx";
import {
  StyledLifecycleInner,
  StyledFlowContainer,
  StyledStepChip,
  StyledFlowArrow,
  StyledNoticeBox,
} from "./JobLifecycleNotice.styles.js";

/**
 * Renders the urban-style job lifecycle execution pipeline.
 */
export const JobLifecycleNotice = ({ lifecycle = {} }) => {
  const title = lifecycle.title || "Job Lifecycle";
  const steps = lifecycle.steps || [];
  const notice = lifecycle.notice || "";

  return (
    <SectionCard title={title}>
      <StyledLifecycleInner>
        <StyledFlowContainer>
          {steps.map((step, idx) => (
            <Fragment key={step}>
              <StyledStepChip>{step}</StyledStepChip>
              {idx < steps.length - 1 && <StyledFlowArrow>→</StyledFlowArrow>}
            </Fragment>
          ))}
        </StyledFlowContainer>

        {notice && <StyledNoticeBox>{notice}</StyledNoticeBox>}
      </StyledLifecycleInner>
    </SectionCard>
  );
};

export default JobLifecycleNotice;

import { Fragment } from "react";

export const JobLifecycleNotice = ({ lifecycle = {} }) => {
  const title = lifecycle.title || "Urban-style Job Lifecycle";
  const steps = lifecycle.steps || [
    "Booking Confirmed",
    "Professional Assigned",
    "On the Way",
    "Reached",
    "Work Started",
    "Completed",
    "Customer Follow-up",
    "Closed",
  ];
  const notice =
    lifecycle.notice ||
    "Installation and cleaning use the same execution controls: date and slot, assignment, reach tracking, work start/completion, customer confirmation and closure.";

  return (
    <div className="card section">
      <div className="head">
        <h2>{title}</h2>
      </div>
      <div className="flow">
        {steps.map((step, idx) => (
          <Fragment key={step}>
            <span className="step">{step}</span>
            {idx < steps.length - 1 ? "→" : null}
          </Fragment>
        ))}
      </div>
      <div className="notice">{notice}</div>
    </div>
  );
};

export default JobLifecycleNotice;

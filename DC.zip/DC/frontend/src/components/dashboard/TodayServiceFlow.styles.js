/**
 * @file TodayServiceFlow.styles.js
 * @description Styled components for Today's Service Flow table and status presentation.
 */
import { styled } from "@mui/material/styles";
import Typography from "@mui/material/Typography";

export const StyledMutedDash = styled(Typography)(({ theme }) => ({
  color: theme.palette.text.secondary,
  fontSize: theme.typography.body2.fontSize,
  fontFamily: theme.typography.fontFamily,
}));

/**
 * @file HomeCatalogSection.styles.js
 * @description Styled components for Products & Subscriptions catalog preview cards.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Typography from "@mui/material/Typography";

export const StyledCatalogGrid = styled(Box)(({ theme }) => ({
  display: "grid",
  gridTemplateColumns: "repeat(4, 1fr)",
  gap: theme.spacing(1.75),
  width: "100%",
  boxSizing: "border-box",
  [theme.breakpoints.down("lg")]: {
    gridTemplateColumns: "repeat(2, 1fr)",
  },
  [theme.breakpoints.down("sm")]: {
    gridTemplateColumns: "1fr",
  },
}));

export const StyledProductCard = styled(Card)(({ theme }) => ({
  padding: theme.spacing(1.75),
  cursor: "pointer",
  backgroundColor: theme.palette.background.paper,
  border: `${theme.shape.borderWidth} solid ${theme.palette.divider}`,
  borderRadius: theme.shape.borderRadiusCard,
  boxShadow: theme.palette.shadows.card,
  transition: "transform 0.15s ease",
  display: "flex",
  flexDirection: "column",
  "&:hover": {
    transform: "translateY(-1px)",
    borderColor: theme.palette.primary.light,
  },
}));

export const StyledArtBox = styled(Box)(({ theme }) => ({
  height: theme.shape.catalogArtHeight,
  borderRadius: theme.shape.borderRadiusLg,
  background: theme.palette.background.productArtGradient,
  display: "grid",
  placeItems: "center",
  color: theme.palette.primary.main,
  "& .MuiSvgIcon-root": {
    fontSize: theme.spacing(5.75),
  },
}));

export const StyledProductTitle = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.h3.fontSize,
  fontWeight: theme.typography.h3.fontWeight,
  color: theme.palette.text.primary,
  margin: theme.spacing(1.375, 0, 0.75),
  fontFamily: theme.typography.headingFont,
}));

export const StyledProductDescription = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.body2.fontSize,
  color: theme.palette.text.secondary,
  lineHeight: theme.typography.body2.lineHeight,
  minHeight: theme.spacing(4.25),
  marginBottom: theme.spacing(1.25),
  fontFamily: theme.typography.fontFamily,
}));

export const StyledBadgeContainer = styled(Box)(() => ({
  marginTop: "auto",
}));

/**
 * @file useDashboardData.js
 * @description Feature data hook querying live operations metrics and lifecycle state.
 */
import { useState, useEffect, useCallback } from "react";
import dashboardService from "../../services/dashboardService.js";

/**
 * Custom hook fetching live operations dashboard dataset with reload capability.
 */
export const useDashboardData = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  /**
   * Dispatches network request to fetch real-time dashboard data.
   */
  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await dashboardService.getDashboard();
      setData(response);
    } catch (err) {
      setError(err?.message || "Failed to load dashboard metrics from server.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  return {
    data,
    loading,
    error,
    reload: loadDashboard,
  };
};

export default useDashboardData;

import { useState, useEffect, useCallback } from "react";
import dashboardService from "../../services/dashboardService";

export const useDashboardData = () => {
  const [data, setData] = useState({
    kpis: {
      ordersToday: 19,
      jobsToday: 24,
      activeSubscriptions: 74,
      availableTechnicians: 12,
      monthCollection: "₹5.48L",
    },
    todayFlow: [],
    lifecycle: {},
    catalogPreview: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      const res = await dashboardService.getOverview();
      if (res) {
        setData(res);
      }
    } catch (err) {
      setError(err?.message || "Failed to load dashboard data");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  return { data, loading, error, reload: loadData };
};

export default useDashboardData;

import { useNavigate } from "react-router-dom";
import { ROUTES } from "../../constants/routes";
import Button from "../common/Button";
import Badge from "../common/Badge";
import Table from "../common/Table";

export const TodayServiceFlow = ({ items = [] }) => {
  const navigate = useNavigate();

  return (
    <div className="card section">
      <div className="head">
        <h2>Today&apos;s Service Flow</h2>
        <Button onClick={() => navigate(ROUTES.SCHEDULE)}>
          Open Schedule
        </Button>
      </div>

      <Table>
        <thead>
          <tr>
            <th>Property</th>
            <th>Work</th>
            <th>Technician</th>
            <th>Arrival</th>
            <th>Work</th>
            <th>Follow-up</th>
          </tr>
        </thead>
        <tbody>
          {items.map((row) => (
            <tr key={row.id}>
              <td>{row.property}</td>
              <td>{row.work}</td>
              <td>{row.technician}</td>
              <td>
                <Badge variant={row.arrival.badgeClass}>
                  {row.arrival.label}
                </Badge>
              </td>
              <td>
                <Badge variant={row.workStatus.badgeClass}>
                  {row.workStatus.label}
                </Badge>
              </td>
              <td>
                {row.followUp.badgeClass === "muted" ? (
                  <span>-</span>
                ) : (
                  <Badge variant={row.followUp.badgeClass}>
                    {row.followUp.label}
                  </Badge>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default TodayServiceFlow;

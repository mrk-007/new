/**
 * @file TodayServiceFlow.jsx
 * @description Service dispatch table displaying active job orders and live arrival/work statuses.
 */
import { useNavigate } from "react-router-dom";
import { ROUTES } from "../../constants/routes.js";
import SectionCard from "../common/SectionCard.jsx";
import DataTable, { DataTableRow, DataTableCell } from "../common/DataTable.jsx";
import StatusChip from "../common/StatusChip.jsx";
import { StyledMutedDash } from "./TodayServiceFlow.styles.js";

const TABLE_COLUMNS = ["Property", "Work", "Technician", "Arrival", "Work", "Follow-up"];

/**
 * Renders Today's Service Flow section with detailed visit execution table.
 */
export const TodayServiceFlow = ({ items = [] }) => {
  const navigate = useNavigate();

  /**
   * Navigates to schedule and calendar view.
   */
  const handleOpenSchedule = () => {
    navigate(ROUTES.SCHEDULE);
  };

  return (
    <SectionCard
      title="Today's Service Flow"
      actionLabel="Open Schedule"
      onActionClick={handleOpenSchedule}
    >
      <DataTable columns={TABLE_COLUMNS}>
        {items.map((row) => (
          <DataTableRow key={row.id}>
            <DataTableCell>{row.property}</DataTableCell>
            <DataTableCell>{row.work}</DataTableCell>
            <DataTableCell>{row.technician}</DataTableCell>
            <DataTableCell>
              <StatusChip label={row.arrival.label} tone={row.arrival.tone} />
            </DataTableCell>
            <DataTableCell>
              <StatusChip label={row.workStatus.label} tone={row.workStatus.tone} />
            </DataTableCell>
            <DataTableCell>
              {row.followUp.code === "NONE" || row.followUp.label === "-" ? (
                <StyledMutedDash>-</StyledMutedDash>
              ) : (
                <StatusChip label={row.followUp.label} tone={row.followUp.tone} />
              )}
            </DataTableCell>
          </DataTableRow>
        ))}
      </DataTable>
    </SectionCard>
  );
};

export default TodayServiceFlow;

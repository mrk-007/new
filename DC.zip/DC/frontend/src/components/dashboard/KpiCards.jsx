/**
 * @file KpiCards.jsx
 * @description KPI metrics grid presenting live operational counters fetched from backend.
 */
import StatCard from "../common/StatCard.jsx";
import { StyledKpiGrid } from "./KpiCards.styles.js";

/**
 * Renders the top operational KPI metric cards.
 */
export const KpiCards = ({ kpis = {} }) => {
  const cards = [
    { label: "Orders Today", value: kpis.ordersToday ?? 0 },
    { label: "Jobs Today", value: kpis.jobsToday ?? 0 },
    { label: "Active Subscriptions", value: kpis.activeSubscriptions ?? 0 },
    { label: "Available Technicians", value: kpis.availableTechnicians ?? 0 },
    { label: "Month Collection", value: kpis.monthCollection ?? "₹0" },
  ];

  return (
    <StyledKpiGrid>
      {cards.map((card) => (
        <StatCard key={card.label} label={card.label} value={card.value} />
      ))}
    </StyledKpiGrid>
  );
};

export default KpiCards;

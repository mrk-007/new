export const KpiCards = ({ kpis = {} }) => {
  const cards = [
    { label: "Orders Today", value: kpis.ordersToday ?? 19 },
    { label: "Jobs Today", value: kpis.jobsToday ?? 24 },
    { label: "Active Subscriptions", value: kpis.activeSubscriptions ?? 74 },
    { label: "Available Technicians", value: kpis.availableTechnicians ?? 12 },
    { label: "Month Collection", value: kpis.monthCollection ?? "₹5.48L" },
  ];

  return (
    <div className="grid kpis">
      {cards.map((card) => (
        <div key={card.label} className="card kpi">
          <span>{card.label}</span>
          <b>{card.value}</b>
        </div>
      ))}
    </div>
  );
};

export default KpiCards;

/**
 * @file DashboardView.styles.js
 * @description Styled components for dashboard layout grid, 2-column flow section, and feedback states.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";

export const StyledDashboardRoot = styled(Box)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  gap: theme.spacing(1.75),
  width: "100%",
  boxSizing: "border-box",
}));

export const StyledTwoColumnGrid = styled(Box)(({ theme }) => ({
  display: "grid",
  gridTemplateColumns: "1.55fr 1fr",
  gap: theme.spacing(1.75),
  width: "100%",
  boxSizing: "border-box",
  [theme.breakpoints.down("lg")]: {
    gridTemplateColumns: "1fr",
  },
}));

export const StyledErrorContainer = styled(Stack)(({ theme }) => ({
  alignItems: "center",
  justifyContent: "center",
  padding: theme.spacing(5),
  gap: theme.spacing(2),
  textAlign: "center",
}));

export const StyledErrorMessage = styled(Typography)(({ theme }) => ({
  color: theme.palette.tones.error.color,
  fontSize: theme.typography.body1.fontSize,
  fontFamily: theme.typography.fontFamily,
}));

export const StyledRetryButton = styled(Button)(({ theme }) => ({
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  padding: theme.spacing(1, 2),
  borderRadius: theme.shape.borderRadiusMd,
  fontWeight: theme.typography.button.fontWeight,
  "&:hover": {
    backgroundColor: theme.palette.primary.dark,
  },
}));

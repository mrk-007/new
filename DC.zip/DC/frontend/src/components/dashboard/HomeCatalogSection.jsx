import { useNavigate } from "react-router-dom";
import { ROUTES } from "../../constants/routes";
import Button from "../common/Button";
import Badge from "../common/Badge";

export const HomeCatalogSection = ({ items = [], onSelectProduct }) => {
  const navigate = useNavigate();

  const handleCardClick = (productName) => {
    if (onSelectProduct) {
      onSelectProduct(productName);
    } else {
      navigate(ROUTES.ORDERS, { state: { selectedService: productName } });
    }
  };

  return (
    <div className="card section">
      <div className="head">
        <h2>Products &amp; Subscription Services</h2>
        <Button onClick={() => navigate(ROUTES.CATALOG)}>
          View Catalog
        </Button>
      </div>

      <div className="grid catalog" id="homeCatalog">
        {items.map((item) => (
          <div
            key={item.id}
            className="card product"
            onClick={() => handleCardClick(item.name)}
          >
            <div className="art">{item.icon}</div>
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <Badge variant="purple">{item.group}</Badge>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HomeCatalogSection;

/**
 * @file HomeCatalogSection.jsx
 * @description Products and subscription services showcase presenting dynamic catalog preview.
 */
import { useNavigate } from "react-router-dom";
import HandymanIcon from "@mui/icons-material/Handyman";
import { ROUTES } from "../../constants/routes.js";
import { ICON_MAP } from "../../constants/iconMap.js";
import SectionCard from "../common/SectionCard.jsx";
import StatusChip from "../common/StatusChip.jsx";
import {
  StyledCatalogGrid,
  StyledProductCard,
  StyledArtBox,
  StyledProductTitle,
  StyledProductDescription,
  StyledBadgeContainer,
} from "./HomeCatalogSection.styles.js";

/**
 * Renders the products and subscription services preview grid.
 */
export const HomeCatalogSection = ({ items = [] }) => {
  const navigate = useNavigate();

  /**
   * Navigates to full product catalog page.
   */
  const handleViewCatalog = () => {
    navigate(ROUTES.CATALOG);
  };

  /**
   * Navigates to order booking page for the selected product.
   */
  const handleProductClick = (productName) => {
    navigate(ROUTES.ORDERS, { state: { selectedService: productName } });
  };

  return (
    <SectionCard
      title="Products &amp; Subscription Services"
      actionLabel="View Catalog"
      onActionClick={handleViewCatalog}
    >
      <StyledCatalogGrid>
        {items.map((item) => {
          const IconComp = ICON_MAP[item.iconKey] || HandymanIcon;
          const tone = item.group === "Subscription" ? "info" : "default";

          return (
            <StyledProductCard key={item.id} onClick={() => handleProductClick(item.name)}>
              <StyledArtBox>
                <IconComp />
              </StyledArtBox>
              <StyledProductTitle>{item.name}</StyledProductTitle>
              <StyledProductDescription>{item.description}</StyledProductDescription>
              <StyledBadgeContainer>
                <StatusChip label={item.group} tone={tone} />
              </StyledBadgeContainer>
            </StyledProductCard>
          );
        })}
      </StyledCatalogGrid>
    </SectionCard>
  );
};

export default HomeCatalogSection;

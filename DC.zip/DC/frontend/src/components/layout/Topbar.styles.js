/**
 * @file Topbar.styles.js
 * @description Styled components for top application header bar and quick actions.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";

export const StyledTopbarHeader = styled(Box)(({ theme }) => ({
  height: theme.shape.topbarHeight,
  backgroundColor: theme.palette.background.paper,
  borderBottom: `${theme.shape.borderWidth} solid ${theme.palette.divider}`,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  padding: theme.spacing(0, 3.125),
  position: "sticky",
  top: 0,
  zIndex: 7,
  boxSizing: "border-box",
}));

export const StyledTitleContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  gap: theme.spacing(1.5),
}));

export const StyledMenuButton = styled(IconButton)(({ theme }) => ({
  display: "none",
  color: theme.palette.text.primary,
  [theme.breakpoints.down("md")]: {
    display: "inline-flex",
  },
}));

export const StyledTopbarTitle = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.h1.fontSize,
  fontWeight: theme.typography.h1.fontWeight,
  color: theme.palette.text.primary,
  margin: 0,
  lineHeight: theme.typography.h1.lineHeight,
  fontFamily: theme.typography.headingFont,
}));

export const StyledTopbarSubtitle = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.body2.fontSize,
  color: theme.palette.text.secondary,
  marginTop: theme.spacing(0.5),
  fontFamily: theme.typography.fontFamily,
}));

export const StyledActionsContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  gap: theme.spacing(1),
  flexWrap: "wrap",
  justifyContent: "flex-end",
}));

export const StyledSecondaryActionButton = styled(Button)(({ theme }) => ({
  border: `${theme.shape.borderWidth} solid ${theme.palette.divider}`,
  backgroundColor: theme.palette.background.paper,
  color: theme.palette.text.primary,
  borderRadius: theme.shape.borderRadiusMd,
  padding: theme.spacing(1.125, 1.5),
  fontWeight: theme.typography.button.fontWeight,
  fontSize: theme.typography.body2.fontSize,
  "&:hover": {
    borderColor: theme.palette.primary.light,
    backgroundColor: theme.palette.background.subtle,
  },
}));

export const StyledPrimaryActionButton = styled(Button)(({ theme }) => ({
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  border: 0,
  borderRadius: theme.shape.borderRadiusMd,
  padding: theme.spacing(1.125, 1.5),
  fontWeight: theme.typography.button.fontWeight,
  fontSize: theme.typography.body2.fontSize,
  "&:hover": {
    backgroundColor: theme.palette.primary.dark,
  },
}));

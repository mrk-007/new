/**
 * @file ProtectedRoute.jsx
 * @description Route guard ensuring only authenticated sessions with valid JWT access view protected children.
 */
import { Navigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext.jsx";
import { ROUTES } from "../../constants/routes.js";
import Loader from "../common/Loader.jsx";

/**
 * Route protection wrapper validating current authentication state.
 */
export const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return <Loader message="Verifying session..." />;
  }

  if (!isAuthenticated) {
    return <Navigate to={ROUTES.LOGIN} replace />;
  }

  return children;
};

export default ProtectedRoute;

/**
 * @file ProtectedRoute.jsx
 * @description Blocks unauthenticated users and waits for session restore.
 */
import { Navigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext.jsx";
import { usePermission } from "../../hooks/usePermission.js";
import { ROUTES } from "../../constants/routes.js";
import Loader from "../common/Loader.jsx";

/** Renders children only when a session exists. */
export const ProtectedRoute = ({ children }) => {
  const { isReady, isAuthenticated } = useAuth();
  if (!isReady) return <Loader />;
  if (!isAuthenticated) return <Navigate to={ROUTES.LOGIN} replace />;
  return children;
};

/** Sends technicians to My Visits and everyone else to the dashboard. */
export const HomeRedirect = () => {
  const { isTechnician } = usePermission();
  return <Navigate to={isTechnician ? ROUTES.MY_VISITS : ROUTES.DASHBOARD} replace />;
};

export default ProtectedRoute;

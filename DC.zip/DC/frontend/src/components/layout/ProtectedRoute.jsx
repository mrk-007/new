import { Navigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { usePermission } from "../../hooks/usePermission";
import { ROUTES } from "../../constants/routes";

export const ProtectedRoute = ({ moduleKey, children }) => {
  const { role } = useAuth();
  const { canAccess } = usePermission(moduleKey);

  // If user is in technician view and tries to access an admin module, redirect to tech home
  if (role === "technician" && !moduleKey?.startsWith("tech")) {
    return <Navigate to={ROUTES.TECH_HOME} replace />;
  }

  // If user is admin or telecaller and tries to access tech workspace, redirect to dashboard
  if (role !== "technician" && moduleKey?.startsWith("tech")) {
    return <Navigate to={ROUTES.DASHBOARD} replace />;
  }

  if (!canAccess && role !== "admin") {
    return <Navigate to={ROUTES.DASHBOARD} replace />;
  }

  return children;
};

export default ProtectedRoute;

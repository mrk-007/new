/**
 * @file Sidebar.jsx
 * @description Dynamic sidebar navigation loop rendering items grouped by section with user session status.
 */
import { Fragment } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { NAVIGATION_ITEMS } from "../../constants/navigation.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { ROUTES } from "../../constants/routes.js";
import {
  StyledSidebarAside,
  StyledBrand,
  StyledLogo,
  StyledBrandTitle,
  StyledBrandSubtitle,
  StyledNavContainer,
  StyledSectionCaption,
  StyledNavButton,
  StyledUserBox,
  StyledUserName,
  StyledUserRole,
  StyledLogoutButton,
} from "./Sidebar.styles.js";

/**
 * Renders the persistent application sidebar with grouped navigation items.
 */
export const Sidebar = ({ onNavigate }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  /**
   * Handles navigation link selection.
   */
  const handleItemClick = (path) => {
    navigate(path);
    if (onNavigate) {
      onNavigate();
    }
  };

  /**
   * Logs out user session and redirects to login view.
   */
  const handleLogout = () => {
    logout();
    navigate(ROUTES.LOGIN, { replace: true });
  };

  // Group navigation items by section while preserving ordering
  const sections = [];
  const sectionMap = new Map();

  NAVIGATION_ITEMS.forEach((item) => {
    if (!sectionMap.has(item.section)) {
      sectionMap.set(item.section, []);
      sections.push(item.section);
    }
    sectionMap.get(item.section).push(item);
  });

  return (
    <StyledSidebarAside>
      <StyledBrand>
        <StyledLogo>JH</StyledLogo>
        <div>
          <StyledBrandTitle>Jolly Home Needs</StyledBrandTitle>
          <StyledBrandSubtitle>Operations &amp; Dispatch</StyledBrandSubtitle>
        </div>
      </StyledBrand>

      <StyledNavContainer>
        {sections.map((sectionName) => (
          <Fragment key={sectionName}>
            <StyledSectionCaption>{sectionName}</StyledSectionCaption>
            {sectionMap.get(sectionName).map((navItem) => {
              const IconComp = navItem.icon;
              const isActive = location.pathname === navItem.path;
              return (
                <StyledNavButton
                  key={navItem.id}
                  active={isActive}
                  onClick={() => handleItemClick(navItem.path)}
                  startIcon={<IconComp />}
                >
                  {navItem.label}
                </StyledNavButton>
              );
            })}
          </Fragment>
        ))}
      </StyledNavContainer>

      {user && (
        <StyledUserBox>
          <div>
            <StyledUserName>{user.fullName || "User"}</StyledUserName>
            <StyledUserRole>{user.role ? `Role: ${user.role}` : user.email}</StyledUserRole>
          </div>
          <StyledLogoutButton onClick={handleLogout}>Sign Out</StyledLogoutButton>
        </StyledUserBox>
      )}
    </StyledSidebarAside>
  );
};

export default Sidebar;

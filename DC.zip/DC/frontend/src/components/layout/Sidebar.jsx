import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { useMasterData } from "../../hooks/useMasterData";
import { ROUTES } from "../../constants/routes";

export const Sidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { role, activeTech, switchRole, switchTechnician } = useAuth();
  const { masters } = useMasterData();

  const handleNavClick = (path) => {
    navigate(path);
  };

  const handleRoleChange = (e) => {
    const newRole = e.target.value;
    switchRole(newRole);
    if (newRole === "technician") {
      navigate(ROUTES.TECH_HOME);
    } else {
      navigate(ROUTES.DASHBOARD);
    }
  };

  // Dynamic technician choices from backend masters if available
  const techOptions = masters.technicians?.length > 0
    ? masters.technicians.map((t) => ({ name: t.name, label: `${t.name} (${t.role?.name || "Technician"})` }))
    : [
        { name: "Arun S.", label: "Arun S. (Shoe Rack Specialist)" },
        { name: "Ravi K.", label: "Ravi K. (Bathroom Cleaning Pro)" },
        { name: "Cleaning Team 2", label: "Cleaning Team 2 (Deep Cleaning Crew)" },
      ];

  const isTechnician = role === "technician";

  return (
    <aside className="side">
      <div className="brand">
        <div className="logo">JH</div>
        <div>
          <b>Jolly Home Needs</b>
          <small>Operations &amp; Dispatch</small>
        </div>
      </div>

      <nav className="nav" id="sidebarNav" aria-label="Main Navigation">
        {!isTechnician ? (
          <>
            <div className="cap">Operations</div>
            <button
              type="button"
              className={location.pathname === ROUTES.DASHBOARD ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.DASHBOARD)}
            >
              📊 <span>Dashboard</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.CUSTOMERS ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.CUSTOMERS)}
            >
              👥 <span>Customers</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.ORDERS ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.ORDERS)}
            >
              📦 <span>Orders</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.SUBSCRIPTIONS ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.SUBSCRIPTIONS)}
            >
              🔁 <span>Subscriptions</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.JOB_ORDERS ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.JOB_ORDERS)}
            >
              🛠️ <span>Job Orders</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.SCHEDULE ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.SCHEDULE)}
            >
              🗓️ <span>Schedule &amp; Calendar</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.TECHNICIANS ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.TECHNICIANS)}
            >
              👷 <span>Technicians</span>
            </button>

            <div className="cap">Catalog &amp; Billing</div>
            <button
              type="button"
              className={location.pathname === ROUTES.CATALOG ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.CATALOG)}
            >
              🏷️ <span>Products &amp; Services</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.INVOICES ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.INVOICES)}
            >
              🧾 <span>Invoices &amp; Payments</span>
            </button>

            {role === "admin" && (
              <>
                <div className="cap">Control</div>
                <button
                  type="button"
                  className={location.pathname === ROUTES.CONFIGURATION ? "active" : ""}
                  onClick={() => handleNavClick(ROUTES.CONFIGURATION)}
                >
                  ⚙️ <span>Configuration</span>
                </button>
              </>
            )}
          </>
        ) : (
          <>
            <div className="cap">Technician View</div>
            <button
              type="button"
              className={location.pathname === ROUTES.TECH_HOME ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.TECH_HOME)}
            >
              📱 <span>Tech Home</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.TECH_CALENDAR ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.TECH_CALENDAR)}
            >
              🗓️ <span>My Calendar</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.TECH_HISTORY ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.TECH_HISTORY)}
            >
              📜 <span>Job History</span>
            </button>
            <button
              type="button"
              className={location.pathname === ROUTES.TECH_PROFILE ? "active" : ""}
              onClick={() => handleNavClick(ROUTES.TECH_PROFILE)}
            >
              👤 <span>My Profile</span>
            </button>
          </>
        )}
      </nav>

      <div className="loginbox">
        <label htmlFor="roleSwitch">Switch View (Demo)</label>
        <select
          id="roleSwitch"
          value={role}
          onChange={handleRoleChange}
        >
          <option value="admin">Super Admin</option>
          <option value="telecaller">Telecaller</option>
          <option value="technician">Technician (Mobile View)</option>
        </select>

        {isTechnician && (
          <div id="techPicker" className="tech-picker">
            <label htmlFor="activeTechSelect" className="tech-picker-label">
              Select Technician
            </label>
            <select
              id="activeTechSelect"
              value={activeTech}
              onChange={(e) => switchTechnician(e.target.value)}
            >
              {techOptions.map((opt) => (
                <option key={opt.name} value={opt.name}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;

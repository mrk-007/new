import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { ROUTES } from "../../constants/routes";
import Button from "../common/Button";

const PAGE_META = {
  [ROUTES.DASHBOARD]: {
    title: "Operations Dashboard",
    sub: "Urban-style Home Services & Installation Workflow",
  },
  [ROUTES.CUSTOMERS]: {
    title: "Customer Directory & CRM",
    sub: "Customer master, property locations, past orders and subscriptions",
  },
  [ROUTES.ORDERS]: {
    title: "Order Management & Booking",
    sub: "One-time and subscription bookings with dynamic pricing and conflict checks",
  },
  [ROUTES.SUBSCRIPTIONS]: {
    title: "Recurring Subscriptions",
    sub: "Automated recurring visit scheduling, plans and execution cadence",
  },
  [ROUTES.JOB_ORDERS]: {
    title: "Job Orders & Dispatch Kanban",
    sub: "Urban-style lifecycle: Scheduled → En Route → Reached → In Progress → Done",
  },
  [ROUTES.SCHEDULE]: {
    title: "Service Calendar & Scheduling",
    sub: "Resource allocation, technician travel buffer and overlap protection",
  },
  [ROUTES.TECHNICIANS]: {
    title: "Technicians & Rosters",
    sub: "Capacity, skills matching, live assignment and area coverage",
  },
  [ROUTES.CATALOG]: {
    title: "Products & Subscription Services",
    sub: "Service variants, measurement units, GST rates and pricing rules",
  },
  [ROUTES.INVOICES]: {
    title: "Invoices & Payments",
    sub: "Automated tax invoice generation, payment receipts and outstanding balances",
  },
  [ROUTES.CONFIGURATION]: {
    title: "System Configuration & Access Control",
    sub: "Master tables, user management, RBAC and system settings",
  },
  [ROUTES.TECH_HOME]: {
    title: "Technician Mobile Workspace",
    sub: "Today's allocated service visits and real-time execution controls",
  },
  [ROUTES.TECH_CALENDAR]: {
    title: "My Service Calendar",
    sub: "Assigned schedule and travel route for upcoming visits",
  },
  [ROUTES.TECH_HISTORY]: {
    title: "My Service History",
    sub: "Completed work orders, customer ratings and execution notes",
  },
  [ROUTES.TECH_PROFILE]: {
    title: "My Profile & Skills",
    sub: "Personal details, certified service skills and active status",
  },
};

export const Topbar = ({ onOpenOrderModal, onOpenTechModal }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { role } = useAuth();

  const meta = PAGE_META[location.pathname] || {
    title: "Operations Dashboard",
    sub: "Urban-style Home Services & Installation Workflow",
  };

  const handleNewOrder = () => {
    if (onOpenOrderModal) {
      onOpenOrderModal();
    } else {
      navigate(ROUTES.ORDERS);
    }
  };

  const handleNewTechnician = () => {
    if (onOpenTechModal) {
      onOpenTechModal();
    } else {
      navigate(ROUTES.TECHNICIANS);
    }
  };

  return (
    <header className="top">
      <div>
        <h1 id="pageTitle">{meta.title}</h1>
        <div className="sub" id="pageSub">{meta.sub}</div>
      </div>
      {role !== "technician" && (
        <div className="actions">
          <Button onClick={handleNewTechnician} title="Add Technician">
            + Technician
          </Button>
          <Button variant="primary" onClick={handleNewOrder} title="Create New Order">
            + New Order
          </Button>
        </div>
      )}
    </header>
  );
};

export default Topbar;

/**
 * @file Topbar.jsx
 * @description Application top bar displaying active page title, subtitle, and primary actions.
 */
import MenuIcon from "@mui/icons-material/Menu";
import {
  StyledTopbarHeader,
  StyledTitleContainer,
  StyledMenuButton,
  StyledTopbarTitle,
  StyledTopbarSubtitle,
  StyledActionsContainer,
  StyledSecondaryActionButton,
  StyledPrimaryActionButton,
} from "./Topbar.styles.js";

/**
 * Renders topbar with page meta, mobile drawer trigger, and action buttons.
 */
export const Topbar = ({ onToggleMobileMenu, onNewTechnician, onNewOrder }) => {
  return (
    <StyledTopbarHeader>
      <StyledTitleContainer>
        <StyledMenuButton
          onClick={onToggleMobileMenu}
          aria-label="Toggle navigation menu"
          edge="start"
        >
          <MenuIcon />
        </StyledMenuButton>
        <div>
          <StyledTopbarTitle>Operations Dashboard</StyledTopbarTitle>
          <StyledTopbarSubtitle>
            Urban-style Home Services &amp; Installation Workflow
          </StyledTopbarSubtitle>
        </div>
      </StyledTitleContainer>

      <StyledActionsContainer>
        <StyledSecondaryActionButton onClick={onNewTechnician}>
          + Technician
        </StyledSecondaryActionButton>
        <StyledPrimaryActionButton onClick={onNewOrder}>+ New Order</StyledPrimaryActionButton>
      </StyledActionsContainer>
    </StyledTopbarHeader>
  );
};

export default Topbar;

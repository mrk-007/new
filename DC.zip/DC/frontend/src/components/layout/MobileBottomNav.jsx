import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { ROUTES } from "../../constants/routes";

export const MobileBottomNav = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { role } = useAuth();

  const isTechnician = role === "technician";

  return (
    <nav className="mobile-nav" aria-label="Mobile Navigation">
      {!isTechnician ? (
        <>
          <button
            type="button"
            className={location.pathname === ROUTES.DASHBOARD ? "active" : ""}
            onClick={() => navigate(ROUTES.DASHBOARD)}
          >
            <span>📊</span>
            <span>Dashboard</span>
          </button>
          <button
            type="button"
            className={location.pathname === ROUTES.ORDERS ? "active" : ""}
            onClick={() => navigate(ROUTES.ORDERS)}
          >
            <span>📦</span>
            <span>Orders</span>
          </button>
          <button
            type="button"
            className={location.pathname === ROUTES.SCHEDULE ? "active" : ""}
            onClick={() => navigate(ROUTES.SCHEDULE)}
          >
            <span>🗓️</span>
            <span>Schedule</span>
          </button>
          <button
            type="button"
            className={location.pathname === ROUTES.CUSTOMERS ? "active" : ""}
            onClick={() => navigate(ROUTES.CUSTOMERS)}
          >
            <span>👥</span>
            <span>Customers</span>
          </button>
        </>
      ) : (
        <>
          <button
            type="button"
            className={location.pathname === ROUTES.TECH_HOME ? "active" : ""}
            onClick={() => navigate(ROUTES.TECH_HOME)}
          >
            <span>📱</span>
            <span>Jobs</span>
          </button>
          <button
            type="button"
            className={location.pathname === ROUTES.TECH_CALENDAR ? "active" : ""}
            onClick={() => navigate(ROUTES.TECH_CALENDAR)}
          >
            <span>🗓️</span>
            <span>Calendar</span>
          </button>
          <button
            type="button"
            className={location.pathname === ROUTES.TECH_HISTORY ? "active" : ""}
            onClick={() => navigate(ROUTES.TECH_HISTORY)}
          >
            <span>📜</span>
            <span>History</span>
          </button>
          <button
            type="button"
            className={location.pathname === ROUTES.TECH_PROFILE ? "active" : ""}
            onClick={() => navigate(ROUTES.TECH_PROFILE)}
          >
            <span>👤</span>
            <span>Profile</span>
          </button>
        </>
      )}
    </nav>
  );
};

export default MobileBottomNav;

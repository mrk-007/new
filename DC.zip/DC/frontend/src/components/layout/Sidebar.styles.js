/**
 * @file Sidebar.styles.js
 * @description Styled components for application navigation sidebar and mobile drawer.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";

export const StyledSidebarAside = styled(Box)(({ theme }) => ({
  width: theme.shape.sidebarWidth,
  height: "100vh",
  background: theme.palette.background.navGradient,
  color: theme.palette.primary.contrastText,
  padding: theme.spacing(2.125, 1.625),
  position: "sticky",
  top: 0,
  display: "flex",
  flexDirection: "column",
  overflow: "hidden",
  boxSizing: "border-box",
}));

export const StyledBrand = styled(Box)(({ theme }) => ({
  display: "flex",
  gap: theme.spacing(1.375),
  alignItems: "center",
  padding: theme.spacing(0.625, 1.25, 2),
  flex: "0 0 auto",
}));

export const StyledLogo = styled(Box)(({ theme }) => ({
  width: theme.shape.logoSize,
  height: theme.shape.logoSize,
  borderRadius: theme.shape.borderRadiusLogo,
  background: theme.palette.background.brandGradient,
  display: "grid",
  placeItems: "center",
  fontWeight: 900,
  color: theme.palette.primary.contrastText,
  fontFamily: theme.typography.headingFont,
}));

export const StyledBrandTitle = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.h2.fontSize,
  fontWeight: theme.typography.h2.fontWeight,
  color: theme.palette.primary.contrastText,
  lineHeight: 1.2,
  fontFamily: theme.typography.headingFont,
}));

export const StyledBrandSubtitle = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.caption.fontSize,
  color: theme.palette.text.navCaption,
  marginTop: theme.spacing(0.375),
  fontFamily: theme.typography.fontFamily,
}));

export const StyledNavContainer = styled(Box)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  gap: theme.spacing(0.625),
  overflowY: "auto",
  overflowX: "hidden",
  minHeight: 0,
  paddingRight: theme.spacing(0.5),
}));

export const StyledSectionCaption = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.caption.fontSize,
  color: theme.palette.text.navCaption,
  letterSpacing: theme.typography.caption.letterSpacing,
  padding: theme.spacing(2, 1.5, 0.5),
  textTransform: "uppercase",
  fontWeight: 700,
  fontFamily: theme.typography.fontFamily,
}));

export const StyledNavButton = styled(Button, {
  shouldForwardProp: (prop) => prop !== "active",
})(({ theme, active }) => ({
  border: 0,
  background: active ? theme.palette.background.navHover : "transparent",
  color: active ? theme.palette.primary.contrastText : theme.palette.text.light,
  justifyContent: "flex-start",
  textAlign: "left",
  padding: theme.spacing(1.25, 1.5),
  borderRadius: theme.shape.borderRadiusMd,
  fontSize: theme.typography.body2.fontSize,
  fontFamily: theme.typography.fontFamily,
  fontWeight: active ? 700 : 500,
  gap: theme.spacing(1.25),
  "&:hover": {
    background: theme.palette.background.navHover,
    color: theme.palette.primary.contrastText,
  },
  "& .MuiSvgIcon-root": {
    fontSize: theme.typography.h2.fontSize,
  },
}));

export const StyledUserBox = styled(Box)(({ theme }) => ({
  marginTop: "auto",
  flex: "0 0 auto",
  border: `${theme.shape.borderWidth} solid ${theme.palette.background.navBorder}`,
  borderRadius: theme.shape.borderRadiusLg,
  padding: theme.spacing(1.375),
  background: theme.palette.background.navBox,
  boxShadow: theme.palette.shadows.navBox,
  display: "flex",
  flexDirection: "column",
  gap: theme.spacing(1),
}));

export const StyledUserName = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.body2.fontSize,
  fontWeight: 700,
  color: theme.palette.primary.contrastText,
  fontFamily: theme.typography.headingFont,
}));

export const StyledUserRole = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.caption.fontSize,
  color: theme.palette.text.navCaption,
  fontFamily: theme.typography.fontFamily,
}));

export const StyledLogoutButton = styled(Button)(({ theme }) => ({
  border: `${theme.shape.borderWidth} solid ${theme.palette.background.navBorder}`,
  color: theme.palette.text.light,
  fontSize: theme.typography.caption.fontSize,
  padding: theme.spacing(0.75, 1),
  borderRadius: theme.shape.borderRadiusSm,
  marginTop: theme.spacing(0.5),
  "&:hover": {
    borderColor: theme.palette.primary.light,
    color: theme.palette.primary.contrastText,
  },
}));

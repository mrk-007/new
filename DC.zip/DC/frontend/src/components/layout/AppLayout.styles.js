/**
 * @file AppLayout.styles.js
 * @description Styled components for master layout grid, main workspace, and mobile drawer wrapper.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";

export const StyledLayoutRoot = styled(Box)(({ theme }) => ({
  display: "grid",
  gridTemplateColumns: `${theme.shape.sidebarWidth}px 1fr`,
  minHeight: "100vh",
  backgroundColor: theme.palette.background.default,
  [theme.breakpoints.down("md")]: {
    gridTemplateColumns: "1fr",
  },
}));

export const StyledDesktopSidebarContainer = styled(Box)(({ theme }) => ({
  display: "block",
  [theme.breakpoints.down("md")]: {
    display: "none",
  },
}));

export const StyledMainArea = styled(Box)(() => ({
  minWidth: 0,
  display: "flex",
  flexDirection: "column",
}));

export const StyledContentContainer = styled(Box)(({ theme }) => ({
  padding: theme.spacing(2.75, 3.125, 5),
  flex: 1,
  boxSizing: "border-box",
  [theme.breakpoints.down("sm")]: {
    padding: theme.spacing(1.75),
  },
}));

export const StyledMobileDrawer = styled(Drawer)(({ theme }) => ({
  display: "none",
  [theme.breakpoints.down("md")]: {
    display: "block",
  },
  "& .MuiDrawer-paper": {
    boxSizing: "border-box",
    width: theme.shape.sidebarWidth,
    background: theme.palette.background.navGradient,
    border: 0,
  },
}));

import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import MobileBottomNav from "./MobileBottomNav";

export const AppLayout = ({ children, onOpenOrderModal, onOpenTechModal }) => {
  return (
    <div className="app">
      <Sidebar />
      <div className="main">
        <Topbar
          onOpenOrderModal={onOpenOrderModal}
          onOpenTechModal={onOpenTechModal}
        />
        <main className="content">{children}</main>
      </div>
      <MobileBottomNav />
    </div>
  );
};

export default AppLayout;

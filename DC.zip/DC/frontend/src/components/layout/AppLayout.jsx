/**
 * @file AppLayout.jsx
 * @description Master application frame organizing Sidebar, Topbar, and children inside main content grid.
 */
import { useState } from "react";
import Sidebar from "./Sidebar.jsx";
import Topbar from "./Topbar.jsx";
import {
  StyledLayoutRoot,
  StyledDesktopSidebarContainer,
  StyledMainArea,
  StyledContentContainer,
  StyledMobileDrawer,
} from "./AppLayout.styles.js";

/**
 * Main application layout integrating responsive sidebar and sticky topbar.
 */
export const AppLayout = ({ children }) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  /**
   * Toggles the responsive mobile navigation drawer.
   */
  const handleDrawerToggle = () => {
    setMobileOpen((prev) => !prev);
  };

  /**
   * Closes mobile navigation drawer when a link is clicked.
   */
  const handleDrawerClose = () => {
    setMobileOpen(false);
  };

  return (
    <StyledLayoutRoot>
      <StyledDesktopSidebarContainer>
        <Sidebar />
      </StyledDesktopSidebarContainer>

      <StyledMobileDrawer
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerClose}
        ModalProps={{ keepMounted: true }}
      >
        <Sidebar onNavigate={handleDrawerClose} />
      </StyledMobileDrawer>

      <StyledMainArea>
        <Topbar onToggleMobileMenu={handleDrawerToggle} />
        <StyledContentContainer>{children}</StyledContentContainer>
      </StyledMainArea>
    </StyledLayoutRoot>
  );
};

export default AppLayout;

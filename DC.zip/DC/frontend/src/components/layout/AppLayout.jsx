/**
 * @file AppLayout.jsx
 * @description Sidebar, topbar, and outlet for protected screens.
 */
import { useMemo, useState } from "react";
import { Outlet, useLocation, useNavigate } from "react-router-dom";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import List from "@mui/material/List";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Tooltip from "@mui/material/Tooltip";
import Stack from "@mui/material/Stack";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material/styles";
import MenuIcon from "@mui/icons-material/Menu";
import DarkModeOutlined from "@mui/icons-material/DarkModeOutlined";
import LightModeOutlined from "@mui/icons-material/LightModeOutlined";
import AccountCircleOutlined from "@mui/icons-material/AccountCircleOutlined";
import ChevronLeft from "@mui/icons-material/ChevronLeft";
import ChevronRight from "@mui/icons-material/ChevronRight";
import { APP, COMMON } from "../../constants/Content.js";
import { NAVIGATION } from "../../constants/navigation.js";
import { resolveIcon } from "../../constants/iconMap.js";
import { useAuth } from "../../context/AuthContext.jsx";
import { useThemeMode } from "../../context/ThemeModeContext.jsx";
import { usePermission } from "../../hooks/usePermission.js";
import {
  Shell,
  NavDrawer,
  BrandRow,
  BrandMark,
  SectionCaption,
  NavButton,
  Main,
  TopBar,
  TopToolbar,
  Content,
} from "../../theme/styles/layout.styles.js";

/** Filters nav items by read permission and technician-only flags. */
const visibleNavigation = (canRead, isTechnician) =>
  NAVIGATION.map((group) => ({
    ...group,
    items: group.items.filter((item) => {
      if (!canRead) return false;
      if (item.technicianOnly && !isTechnician) return false;
      return true;
    }),
  })).filter((group) => group.items.length);

/** Sidebar groups plus the collapsing drawer. */
const SideNav = ({ isCollapsed, isMobile, isOpen, onClose, path }) => {
  const navigate = useNavigate();
  const { canRead, isTechnician } = usePermission();
  const groups = useMemo(() => visibleNavigation(canRead, isTechnician), [canRead, isTechnician]);

  const body = (
    <>
      <BrandRow>
        <BrandMark />
        {isCollapsed ? null : (
          <Typography variant="h3" color="common.white">
            {APP.NAME}
          </Typography>
        )}
      </BrandRow>
      {groups.map((group) => (
        <List key={group.group} disablePadding>
          {isCollapsed ? null : <SectionCaption>{group.group}</SectionCaption>}
          {group.items.map((item) => {
            const Icon = resolveIcon(item.iconKey);
            const isActive = path === item.path || path.startsWith(`${item.path}/`);
            return (
              <Tooltip key={item.id} title={isCollapsed ? item.label : ""} placement="right">
                <NavButton
                  isActive={isActive}
                  onClick={() => {
                    navigate(item.path);
                    if (isMobile) onClose();
                  }}
                >
                  <ListItemIcon>
                    <Icon htmlColor="currentColor" />
                  </ListItemIcon>
                  {isCollapsed ? null : <ListItemText primary={item.label} />}
                </NavButton>
              </Tooltip>
            );
          })}
        </List>
      ))}
    </>
  );

  return (
    <NavDrawer
      isCollapsed={isCollapsed && !isMobile}
      variant={isMobile ? "temporary" : "permanent"}
      open={isMobile ? isOpen : true}
      onClose={onClose}
    >
      {body}
    </NavDrawer>
  );
};

/** Protected chrome around nested routes. */
export const AppLayout = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));
  const [isOpen, setIsOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [anchor, setAnchor] = useState(null);
  const { user, logout } = useAuth();
  const { isDark, toggleMode } = useThemeMode();
  const location = useLocation();
  const title = location.pathname.split("/").filter(Boolean).join(" / ") || APP.NAME;

  return (
    <Shell>
      <SideNav
        isCollapsed={isCollapsed}
        isMobile={isMobile}
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        path={location.pathname}
      />
      <Main>
        <TopBar>
          <TopToolbar>
            <Stack direction="row" alignItems="center" spacing={1}>
              {isMobile ? (
                <IconButton aria-label="Open navigation" onClick={() => setIsOpen(true)}>
                  <MenuIcon />
                </IconButton>
              ) : (
                <IconButton aria-label="Collapse sidebar" onClick={() => setIsCollapsed((value) => !value)}>
                  {isCollapsed ? <ChevronRight /> : <ChevronLeft />}
                </IconButton>
              )}
              <Typography variant="h3">{title}</Typography>
            </Stack>
            <Stack direction="row" alignItems="center" spacing={0.5}>
              <IconButton aria-label={isDark ? COMMON.LIGHT : COMMON.DARK} onClick={toggleMode}>
                {isDark ? <LightModeOutlined /> : <DarkModeOutlined />}
              </IconButton>
              <IconButton aria-label={user?.email || "Account"} onClick={(event) => setAnchor(event.currentTarget)}>
                <AccountCircleOutlined />
              </IconButton>
              <Menu open={Boolean(anchor)} anchorEl={anchor} onClose={() => setAnchor(null)}>
                <MenuItem disabled>{user?.email}</MenuItem>
                <MenuItem
                  onClick={() => {
                    setAnchor(null);
                    logout();
                  }}
                >
                  {COMMON.LOGOUT}
                </MenuItem>
              </Menu>
            </Stack>
          </TopToolbar>
        </TopBar>
        <Content>
          <Outlet />
        </Content>
      </Main>
    </Shell>
  );
};

export default AppLayout;

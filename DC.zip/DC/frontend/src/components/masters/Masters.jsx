/**
 * @file Masters.jsx
 * @description Config-driven CRUD renderer for catalog and configuration resources.
 */
import { useState } from "react";
import { useParams } from "react-router-dom";
import Button from "@mui/material/Button";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import Typography from "@mui/material/Typography";
import { COMMON, CONFIRM, MASTER_CONFIG } from "../../constants/Content.js";
import { listMaster, createMaster, updateMaster, removeMaster } from "../../services/api.js";
import { useApi } from "../../hooks/useApi.js";
import { usePermission } from "../../hooks/usePermission.js";
import { useNotifier } from "../../context/NotifierContext.jsx";
import PageHeader from "../common/PageHeader.jsx";
import DataTable from "../common/DataTable.jsx";
import FormDialog from "../common/FormDialog.jsx";
import ConfirmDialog from "../common/ConfirmDialog.jsx";
import Loader from "../common/Loader.jsx";
import EmptyState from "../common/EmptyState.jsx";
import { ErrorBanner, FilterRow, PageStack } from "../../theme/styles/common.styles.js";

/** Renders a retryable API error. */
const ErrorPanel = ({ error, onRetry }) => (
  <ErrorBanner elevation={0}>
    <Typography color="error">{error?.message || "Request failed."}</Typography>
    <Button onClick={onRetry}>{COMMON.RETRY}</Button>
  </ErrorBanner>
);

/** Renders the selected master using its Content.js configuration. */
const Masters = () => {
  const { resourceKey } = useParams();
  const config = MASTER_CONFIG[resourceKey];
  const { canWrite, canDelete } = usePermission();
  const { notify } = useNotifier();
  const [showInactive, setShowInactive] = useState(false);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [editor, setEditor] = useState(null);
  const [removeRow, setRemoveRow] = useState(null);
  const { data, meta, isLoading, error, reload } = useApi(
    () => (config ? listMaster(config.endpoint, { page, limit, isActive: showInactive ? false : undefined }) : Promise.resolve({ data: [] })),
    [config, page, limit, showInactive]
  );

  if (!config) return <EmptyState message="This configuration resource does not exist." />;

  const handleSave = async (body) => {
    if (editor?._id) await updateMaster(config.endpoint, editor._id, body);
    else await createMaster(config.endpoint, body);
    notify({ severity: "success", message: COMMON.SUCCESS });
    setEditor(null);
    reload();
  };

  return (
    <PageStack>
      <PageHeader title={config.title} actions={canWrite ? <Button variant="contained" onClick={() => setEditor({})}>{COMMON.CREATE}</Button> : null} />
      <FilterRow>
        <FormControlLabel control={<Switch checked={showInactive} onChange={(event) => setShowInactive(event.target.checked)} />} label={COMMON.SHOW_INACTIVE} />
      </FilterRow>
      {error ? <ErrorPanel error={error} onRetry={reload} /> : null}
      {isLoading ? <Loader /> : null}
      {!isLoading && !error && !(data || []).length ? <EmptyState message={COMMON.EMPTY} /> : null}
      {!isLoading && (data || []).length ? (
        <DataTable
          columns={config.columns}
          rows={data}
          meta={meta}
          onPageChange={(nextPage, nextLimit) => {
            setPage(nextPage);
            setLimit(nextLimit);
          }}
          canWrite={canWrite}
          canDelete={canDelete}
          actions={[
            { id: "edit", label: COMMON.EDIT, require: "write", onClick: setEditor },
            { id: "remove", label: COMMON.DELETE, require: "delete", onClick: setRemoveRow, hidden: (row) => row.isActive === false },
          ]}
        />
      ) : null}
      <FormDialog open={Boolean(editor)} title={editor?._id ? COMMON.EDIT : config.title} fields={config.fields} initialValues={editor} onClose={() => setEditor(null)} onSubmit={handleSave} />
      <ConfirmDialog
        open={Boolean(removeRow)}
        title={CONFIRM.DELETE_TITLE}
        body={CONFIRM.DELETE_BODY}
        onClose={() => setRemoveRow(null)}
        onConfirm={async () => {
          await removeMaster(config.endpoint, removeRow._id);
          notify({ severity: "success", message: COMMON.DELETED });
          setRemoveRow(null);
          reload();
        }}
      />
    </PageStack>
  );
};

export default Masters;

/**
 * @file Audit.jsx
 * @description Read-only audit log table with filters and before/after inspection.
 */
import { useState } from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { AUDIT, COMMON } from "../../constants/Content.js";
import { listAuditLogs } from "../../services/api.js";
import { useApi } from "../../hooks/useApi.js";
import { useDebounce } from "../../hooks/useDebounce.js";
import PageHeader from "../common/PageHeader.jsx";
import DataTable from "../common/DataTable.jsx";
import Loader from "../common/Loader.jsx";
import EmptyState from "../common/EmptyState.jsx";
import { ErrorBanner, FilterRow, GrowBox, PageStack } from "../../theme/styles/common.styles.js";

/** Renders a retryable API error. */
const ErrorPanel = ({ error, onRetry }) => (
  <ErrorBanner elevation={0}>
    <Typography color="error">{error?.message || "Request failed."}</Typography>
    <Button onClick={onRetry}>{COMMON.RETRY}</Button>
  </ErrorBanner>
);

/** Renders audit history with a change inspection dialog. */
const Audit = () => {
  const [entity, setEntity] = useState("");
  const [action, setAction] = useState("");
  const [performedBy, setPerformedBy] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [selected, setSelected] = useState(null);
  const debouncedEntity = useDebounce(entity);
  const { data, meta, isLoading, error, reload } = useApi(
    () => listAuditLogs({ entity: debouncedEntity, action, performedBy, from, to, page, limit }),
    [debouncedEntity, action, performedBy, from, to, page, limit]
  );

  return (
    <PageStack>
      <PageHeader title={AUDIT.TITLE} />
      <FilterRow>
        <GrowBox><TextField label={AUDIT.ENTITY} value={entity} onChange={(event) => setEntity(event.target.value)} /></GrowBox>
        <TextField label={AUDIT.ACTION} value={action} onChange={(event) => setAction(event.target.value)} />
        <TextField label={AUDIT.USER} value={performedBy} onChange={(event) => setPerformedBy(event.target.value)} />
        <TextField type="date" label={AUDIT.FROM} value={from} onChange={(event) => setFrom(event.target.value)} InputLabelProps={{ shrink: true }} />
        <TextField type="date" label={AUDIT.TO} value={to} onChange={(event) => setTo(event.target.value)} InputLabelProps={{ shrink: true }} />
      </FilterRow>
      {error ? <ErrorPanel error={error} onRetry={reload} /> : null}
      {isLoading ? <Loader /> : null}
      {!isLoading && !error && !(data || []).length ? <EmptyState message={AUDIT.EMPTY} /> : null}
      {!isLoading && (data || []).length ? (
        <DataTable
          columns={AUDIT.COLUMNS}
          rows={data}
          meta={meta}
          onPageChange={(nextPage, nextLimit) => {
            setPage(nextPage);
            setLimit(nextLimit);
          }}
          actions={[{ id: "view", label: AUDIT.VIEW, onClick: setSelected }]}
        />
      ) : null}
      <Dialog open={Boolean(selected)} onClose={() => setSelected(null)} fullWidth maxWidth="md">
        <DialogTitle>{AUDIT.VIEW}</DialogTitle>
        <DialogContent>
          <Typography variant="h4">{AUDIT.BEFORE}</Typography>
          <Typography component="pre">{JSON.stringify(selected?.before || {}, null, 2)}</Typography>
          <Typography variant="h4">{AUDIT.AFTER}</Typography>
          <Typography component="pre">{JSON.stringify(selected?.after || {}, null, 2)}</Typography>
        </DialogContent>
        <DialogActions><Button onClick={() => setSelected(null)}>{COMMON.CLOSE}</Button></DialogActions>
      </Dialog>
    </PageStack>
  );
};

export default Audit;

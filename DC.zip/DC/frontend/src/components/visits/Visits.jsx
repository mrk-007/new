/**
 * @file Visits.jsx
 * @description Visit list, technician My Visits, and lifecycle actions.
 */
import { useState } from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import Typography from "@mui/material/Typography";
import { COMMON, VISIT_STATUSES, VISIT_TYPES, VISITS } from "../../constants/Content.js";
import {
  allocateVisit,
  cancelVisit,
  completeVisit,
  listMyVisits,
  listTechnicians,
  listVisits,
  reassignVisit,
  startVisit,
} from "../../services/api.js";
import { useApi } from "../../hooks/useApi.js";
import { usePermission } from "../../hooks/usePermission.js";
import { useNotifier } from "../../context/NotifierContext.jsx";
import { formatDateTime, humanize, todayIstDate } from "../../utils/format.js";
import PageHeader from "../common/PageHeader.jsx";
import DataTable from "../common/DataTable.jsx";
import Loader from "../common/Loader.jsx";
import EmptyState from "../common/EmptyState.jsx";
import ConfirmDialog from "../common/ConfirmDialog.jsx";
import FormDialog from "../common/FormDialog.jsx";
import StatusChip from "../common/StatusChip.jsx";
import { ErrorBanner, FilterRow, GrowBox, PageStack } from "../../theme/styles/common.styles.js";
import { FlagChipWrap, VisitCard } from "../../theme/styles/feature.styles.js";

/** Retryable error strip. */
const ErrorPanel = ({ error, onRetry }) => (
  <ErrorBanner elevation={0}>
    <Typography color="error">{error?.message}</Typography>
    <Button onClick={onRetry}>{COMMON.RETRY}</Button>
  </ErrorBanner>
);

const SITE_FIELDS = [
  { name: "notes", label: VISITS.NOTES, type: "text" },
  { name: "width", label: VISITS.WIDTH, type: "number" },
  { name: "height", label: VISITS.HEIGHT, type: "number" },
  { name: "unit", label: VISITS.UNIT, type: "text" },
  { name: "quotedAmount", label: VISITS.QUOTED, type: "number", required: true },
];

/** Shared visit actions for list and my-visits. */
const useVisitActions = (reload) => {
  const { notify } = useNotifier();
  const { canWrite } = usePermission();
  const [completeRow, setCompleteRow] = useState(null);
  const [cancelRow, setCancelRow] = useState(null);
  const [reason, setReason] = useState("");
  const [techRow, setTechRow] = useState(null);
  const [isReassign, setIsReassign] = useState(false);

  const run = async (fn, message) => {
    try {
      await fn();
      notify({ severity: "success", message: message || COMMON.SUCCESS });
      reload();
    } catch (err) {
      notify({ severity: "error", message: err.message });
    }
  };

  const actions = [
    {
      id: "start",
      label: VISITS.START,
      require: "write",
      hidden: (row) => row.status !== "PENDING",
      onClick: (row) => run(() => startVisit(row._id)),
    },
    {
      id: "complete",
      label: VISITS.COMPLETE,
      require: "write",
      hidden: (row) => row.status !== "IN_PROGRESS",
      onClick: setCompleteRow,
    },
    {
      id: "cancel",
      label: VISITS.CANCEL,
      require: "write",
      hidden: (row) => row.status === "COMPLETED" || row.status === "CANCELLED",
      onClick: setCancelRow,
    },
    {
      id: "allocate",
      label: VISITS.ALLOCATE,
      require: "write",
      hidden: (row) => row.isAllocated !== false && row.technician,
      onClick: (row) => run(() => allocateVisit(row._id, {})),
    },
    {
      id: "reassign",
      label: VISITS.REASSIGN,
      require: "write",
      hidden: (row) => row.status === "COMPLETED" || row.status === "CANCELLED",
      onClick: (row) => {
        setIsReassign(true);
        setTechRow(row);
      },
    },
  ];

  const dialogs = (
    <>
      <FormDialog
        open={Boolean(completeRow)}
        title={completeRow?.visitType === "SITE_VISIT" ? VISITS.SITE_REPORT : VISITS.COMPLETE}
        fields={completeRow?.visitType === "SITE_VISIT" ? SITE_FIELDS : []}
        onClose={() => setCompleteRow(null)}
        onSubmit={async (body) => {
          await completeVisit(completeRow._id, body);
          notify({ severity: "success", message: COMMON.SUCCESS });
          setCompleteRow(null);
          reload();
        }}
      />
      <ConfirmDialog
        open={Boolean(cancelRow)}
        title={VISITS.CANCEL}
        body={VISITS.REASON}
        onClose={() => setCancelRow(null)}
        onConfirm={() => {
          run(() => cancelVisit(cancelRow._id, { cancelReason: reason }));
          setCancelRow(null);
        }}
      >
        <TextField label={VISITS.REASON} value={reason} onChange={(event) => setReason(event.target.value)} />
      </ConfirmDialog>
      <FormDialog
        open={Boolean(techRow) && isReassign}
        title={VISITS.REASSIGN}
        fields={[{ name: "technicianId", label: VISITS.TECHNICIAN, type: "select", ref: "technicians", required: true }]}
        extraOptions={{}}
        onClose={() => setTechRow(null)}
        onSubmit={async (body) => {
          await reassignVisit(techRow._id, body);
          notify({ severity: "success", message: COMMON.SUCCESS });
          setTechRow(null);
          reload();
        }}
      />
    </>
  );

  return { actions, dialogs, canWrite };
};

/** Filterable operations visit list. */
export const Visits = () => {
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [date, setDate] = useState(todayIstDate());
  const [status, setStatus] = useState("");
  const [visitType, setVisitType] = useState("");
  const [technician, setTechnician] = useState("");
  const techQuery = useApi(() => listTechnicians({ limit: 100 }), []);
  const { data, meta, isLoading, error, reload } = useApi(
    () => listVisits({ page, limit, date, status, visitType, technician }),
    [page, limit, date, status, visitType, technician]
  );
  const { actions, dialogs, canWrite } = useVisitActions(reload);

  return (
    <PageStack>
      <PageHeader title={VISITS.TITLE} />
      <FilterRow>
        <TextField type="date" label={VISITS.DATE} value={date} onChange={(event) => setDate(event.target.value)} InputLabelProps={{ shrink: true }} />
        <TextField select label={VISITS.STATUS} value={status} onChange={(event) => setStatus(event.target.value)}>
          <MenuItem value="">All</MenuItem>
          {VISIT_STATUSES.map((code) => (
            <MenuItem key={code} value={code}>{humanize(code)}</MenuItem>
          ))}
        </TextField>
        <TextField select label={VISITS.TYPE} value={visitType} onChange={(event) => setVisitType(event.target.value)}>
          <MenuItem value="">All</MenuItem>
          {VISIT_TYPES.map((code) => (
            <MenuItem key={code} value={code}>{humanize(code)}</MenuItem>
          ))}
        </TextField>
        <GrowBox>
          <TextField select label={VISITS.TECHNICIAN} value={technician} onChange={(event) => setTechnician(event.target.value)}>
            <MenuItem value="">All</MenuItem>
            {(techQuery.data || []).map((row) => (
              <MenuItem key={row._id} value={row._id}>{row.name}</MenuItem>
            ))}
          </TextField>
        </GrowBox>
      </FilterRow>
      {error ? <ErrorPanel error={error} onRetry={reload} /> : null}
      {isLoading ? <Loader /> : null}
      {!isLoading && !(data || []).length ? <EmptyState message={VISITS.EMPTY} /> : null}
      {!isLoading && (data || []).length ? (
        <DataTable
          columns={[
            ...VISITS.COLUMNS,
            { key: "isAllocated", label: VISITS.UNALLOCATED, boolean: true },
          ]}
          rows={(data || []).map((row) => ({ ...row, isAllocated: row.isAllocated !== false && Boolean(row.technician || row.isAllocated) }))}
          meta={meta}
          onPageChange={(next, nextLimit) => {
            setPage(next);
            setLimit(nextLimit);
          }}
          canWrite={canWrite}
          actions={actions}
        />
      ) : null}
      {dialogs}
    </PageStack>
  );
};

/** Card list of visits assigned to the signed-in technician. */
export const MyVisits = () => {
  const { data, isLoading, error, reload } = useApi(() => listMyVisits({ limit: 50 }), []);
  const { actions, dialogs } = useVisitActions(reload);

  return (
    <PageStack>
      <PageHeader title={VISITS.MY_TITLE} />
      {error ? <ErrorPanel error={error} onRetry={reload} /> : null}
      {isLoading ? <Loader /> : null}
      {!isLoading && !(data || []).length ? <EmptyState message={VISITS.EMPTY} /> : null}
      {(data || []).map((visit) => (
        <VisitCard key={visit._id} elevation={1}>
          <FlagChipWrap>
            <StatusChip code={visit.visitType} />
            <StatusChip code={visit.status} />
            {visit.isAllocated === false ? <StatusChip code="PENDING" label={VISITS.UNALLOCATED} /> : null}
          </FlagChipWrap>
          <Typography variant="h4">{visit.customer?.fullName}</Typography>
          <Typography variant="body2">{formatDateTime(visit.scheduledStart)}</Typography>
          <FilterRow>
            {actions
              .filter((action) => !action.hidden?.(visit))
              .map((action) => (
                <Button key={action.id} size="small" onClick={() => action.onClick(visit)}>
                  {action.label}
                </Button>
              ))}
          </FilterRow>
        </VisitCard>
      ))}
      {dialogs}
    </PageStack>
  );
};

export default Visits;

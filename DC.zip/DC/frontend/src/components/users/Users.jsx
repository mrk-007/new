/**
 * @file Users.jsx
 * @description User administration with role-aware CRUD actions.
 */
import { useState } from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import { COMMON, CONFIRM, USERS } from "../../constants/Content.js";
import { createUser, listUsers, removeUser, updateUser } from "../../services/api.js";
import { useApi } from "../../hooks/useApi.js";
import { useDebounce } from "../../hooks/useDebounce.js";
import { usePermission } from "../../hooks/usePermission.js";
import { useNotifier } from "../../context/NotifierContext.jsx";
import PageHeader from "../common/PageHeader.jsx";
import DataTable from "../common/DataTable.jsx";
import FormDialog from "../common/FormDialog.jsx";
import ConfirmDialog from "../common/ConfirmDialog.jsx";
import Loader from "../common/Loader.jsx";
import EmptyState from "../common/EmptyState.jsx";
import { ErrorBanner, FilterRow, GrowBox, PageStack } from "../../theme/styles/common.styles.js";

/** Renders a retryable API error. */
const ErrorPanel = ({ error, onRetry }) => (
  <ErrorBanner elevation={0}>
    <Typography color="error">{error?.message || "Request failed."}</Typography>
    <Button onClick={onRetry}>{COMMON.RETRY}</Button>
  </ErrorBanner>
);

/** Renders the user administration table. */
const Users = () => {
  const { canWrite, canDelete } = usePermission();
  const { notify } = useNotifier();
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [editor, setEditor] = useState(null);
  const [removeRow, setRemoveRow] = useState(null);
  const debounced = useDebounce(search);
  const { data, meta, isLoading, error, reload } = useApi(() => listUsers({ search: debounced, page, limit }), [debounced, page, limit]);

  const handleSave = async (body) => {
    if (editor?._id) await updateUser(editor._id, body);
    else await createUser(body);
    notify({ severity: "success", message: COMMON.SUCCESS });
    setEditor(null);
    reload();
  };

  return (
    <PageStack>
      <PageHeader title={USERS.TITLE} actions={canWrite ? <Button variant="contained" onClick={() => setEditor({})}>{USERS.NEW}</Button> : null} />
      <FilterRow>
        <GrowBox><TextField label={COMMON.SEARCH} value={search} onChange={(event) => setSearch(event.target.value)} /></GrowBox>
      </FilterRow>
      {error ? <ErrorPanel error={error} onRetry={reload} /> : null}
      {isLoading ? <Loader /> : null}
      {!isLoading && !error && !(data || []).length ? <EmptyState message={USERS.EMPTY} /> : null}
      {!isLoading && (data || []).length ? (
        <DataTable
          columns={USERS.COLUMNS}
          rows={data}
          meta={meta}
          onPageChange={(nextPage, nextLimit) => {
            setPage(nextPage);
            setLimit(nextLimit);
          }}
          canWrite={canWrite}
          canDelete={canDelete}
          actions={[
            { id: "edit", label: COMMON.EDIT, require: "write", onClick: setEditor },
            { id: "remove", label: COMMON.DELETE, require: "delete", onClick: setRemoveRow, hidden: (row) => row.isActive === false },
          ]}
        />
      ) : null}
      <FormDialog open={Boolean(editor)} title={editor?._id ? COMMON.EDIT : USERS.NEW} fields={USERS.FIELDS} initialValues={editor} onClose={() => setEditor(null)} onSubmit={handleSave} />
      <ConfirmDialog
        open={Boolean(removeRow)}
        title={CONFIRM.DELETE_TITLE}
        body={CONFIRM.DELETE_BODY}
        onClose={() => setRemoveRow(null)}
        onConfirm={async () => {
          await removeUser(removeRow._id);
          notify({ severity: "success", message: COMMON.DELETED });
          setRemoveRow(null);
          reload();
        }}
      />
    </PageStack>
  );
};

export default Users;

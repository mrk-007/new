/**
 * @file Technicians.jsx
 * @description Technician CRUD, availability toggle, and skill matrix.
 */
import { useState } from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import FormControlLabel from "@mui/material/FormControlLabel";
import Switch from "@mui/material/Switch";
import { COMMON, CONFIRM, TECHNICIANS } from "../../constants/Content.js";
import {
  createTechnician,
  getTechnicianSkills,
  listTechnicians,
  putTechnicianSkills,
  removeTechnician,
  setTechnicianAvailability,
  updateTechnician,
} from "../../services/api.js";
import { useApi } from "../../hooks/useApi.js";
import { useDebounce } from "../../hooks/useDebounce.js";
import { usePermission } from "../../hooks/usePermission.js";
import { useNotifier } from "../../context/NotifierContext.jsx";
import PageHeader from "../common/PageHeader.jsx";
import DataTable from "../common/DataTable.jsx";
import FormDialog from "../common/FormDialog.jsx";
import ConfirmDialog from "../common/ConfirmDialog.jsx";
import Loader from "../common/Loader.jsx";
import EmptyState from "../common/EmptyState.jsx";
import { ErrorBanner, FilterRow, FormStack, GrowBox, PageStack } from "../../theme/styles/common.styles.js";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";

/** Retryable error strip. */
const ErrorPanel = ({ error, onRetry }) => (
  <ErrorBanner elevation={0}>
    <Typography color="error">{error?.message}</Typography>
    <Button onClick={onRetry}>{COMMON.RETRY}</Button>
  </ErrorBanner>
);

/** Skill true/false matrix dialog. */
const SkillsDialog = ({ technician, onClose, onSaved }) => {
  const [rows, setRows] = useState([]);
  const [isBusy, setIsBusy] = useState(false);

  useApi(async () => {
    if (!technician) return { data: [] };
    const result = await getTechnicianSkills(technician._id);
    setRows(result.data || []);
    return result;
  }, [technician]);

  const handleSave = async () => {
    setIsBusy(true);
    await putTechnicianSkills(
      technician._id,
      rows.map((row) => ({ skill: row.skill, isSkilled: row.isSkilled }))
    );
    onSaved();
    setIsBusy(false);
  };

  return (
    <Dialog open={Boolean(technician)} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>{TECHNICIANS.SKILLS}</DialogTitle>
      <DialogContent>
        <FormStack>
          {rows.map((row) => (
            <FormControlLabel
              key={row.skill}
              control={
                <Switch
                  checked={Boolean(row.isSkilled)}
                  onChange={(event) =>
                    setRows((current) =>
                      current.map((item) =>
                        item.skill === row.skill ? { ...item, isSkilled: event.target.checked } : item
                      )
                    )
                  }
                />
              }
              label={row.name}
            />
          ))}
        </FormStack>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{COMMON.CANCEL}</Button>
        <Button variant="contained" onClick={handleSave} disabled={isBusy}>
          {COMMON.SAVE}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

/** Technician directory. */
export const Technicians = () => {
  const { canWrite, canDelete } = usePermission();
  const { notify } = useNotifier();
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [search, setSearch] = useState("");
  const [editor, setEditor] = useState(null);
  const [removeRow, setRemoveRow] = useState(null);
  const [skillsFor, setSkillsFor] = useState(null);
  const debounced = useDebounce(search);
  const { data, meta, isLoading, error, reload } = useApi(
    () => listTechnicians({ page, limit, search: debounced }),
    [page, limit, debounced]
  );

  const handleSave = async (body) => {
    if (editor?._id) await updateTechnician(editor._id, body);
    else await createTechnician(body);
    notify({ severity: "success", message: COMMON.SUCCESS });
    setEditor(null);
    reload();
  };

  return (
    <PageStack>
      <PageHeader
        title={TECHNICIANS.TITLE}
        actions={
          canWrite ? (
            <Button variant="contained" onClick={() => setEditor({})}>
              {TECHNICIANS.NEW}
            </Button>
          ) : null
        }
      />
      <FilterRow>
        <GrowBox>
          <TextField label={COMMON.SEARCH} value={search} onChange={(event) => setSearch(event.target.value)} />
        </GrowBox>
      </FilterRow>
      {error ? <ErrorPanel error={error} onRetry={reload} /> : null}
      {isLoading ? <Loader /> : null}
      {!isLoading && !(data || []).length ? <EmptyState message={TECHNICIANS.EMPTY} /> : null}
      {!isLoading && (data || []).length ? (
        <DataTable
          columns={TECHNICIANS.COLUMNS}
          rows={data || []}
          meta={meta}
          onPageChange={(next, nextLimit) => {
            setPage(next);
            setLimit(nextLimit);
          }}
          canWrite={canWrite}
          canDelete={canDelete}
          actions={[
            { id: "edit", label: COMMON.EDIT, require: "write", onClick: setEditor },
            {
              id: "avail",
              label: TECHNICIANS.AVAILABLE,
              require: "write",
              onClick: async (row) => {
                await setTechnicianAvailability(row._id, !row.isAvailable);
                reload();
              },
            },
            { id: "skills", label: TECHNICIANS.SKILLS, require: "write", onClick: setSkillsFor },
            { id: "remove", label: COMMON.DELETE, require: "delete", onClick: setRemoveRow },
          ]}
        />
      ) : null}
      <FormDialog
        open={Boolean(editor)}
        title={editor?._id ? COMMON.EDIT : TECHNICIANS.NEW}
        fields={TECHNICIANS.FIELDS}
        initialValues={editor}
        onClose={() => setEditor(null)}
        onSubmit={handleSave}
      />
      <ConfirmDialog
        open={Boolean(removeRow)}
        title={CONFIRM.DELETE_TITLE}
        body={CONFIRM.DELETE_BODY}
        onClose={() => setRemoveRow(null)}
        onConfirm={async () => {
          await removeTechnician(removeRow._id);
          notify({ severity: "success", message: COMMON.DELETED });
          setRemoveRow(null);
          reload();
        }}
      />
      <SkillsDialog
        technician={skillsFor}
        onClose={() => setSkillsFor(null)}
        onSaved={() => {
          notify({ severity: "success", message: COMMON.SUCCESS });
          setSkillsFor(null);
        }}
      />
    </PageStack>
  );
};

export default Technicians;

/**
 * @file Customers.jsx
 * @description Customer CRUD plus an addresses panel.
 */
import { useState } from "react";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import Chip from "@mui/material/Chip";
import { COMMON, CONFIRM, CUSTOMERS } from "../../constants/Content.js";
import {
  createAddress,
  createCustomer,
  listAddresses,
  listCustomers,
  removeAddress,
  removeCustomer,
  setDefaultAddress,
  updateAddress,
  updateCustomer,
} from "../../services/api.js";
import { useApi } from "../../hooks/useApi.js";
import { useDebounce } from "../../hooks/useDebounce.js";
import { usePermission } from "../../hooks/usePermission.js";
import { useNotifier } from "../../context/NotifierContext.jsx";
import PageHeader from "../common/PageHeader.jsx";
import DataTable from "../common/DataTable.jsx";
import FormDialog from "../common/FormDialog.jsx";
import ConfirmDialog from "../common/ConfirmDialog.jsx";
import Loader from "../common/Loader.jsx";
import EmptyState from "../common/EmptyState.jsx";
import { ErrorBanner, FilterRow, GrowBox, PageStack } from "../../theme/styles/common.styles.js";
import { DrawerPaper, FlagChipWrap, SideDrawer } from "../../theme/styles/feature.styles.js";

/** Retryable error strip. */
const ErrorPanel = ({ error, onRetry }) => (
  <ErrorBanner elevation={0}>
    <Typography color="error">{error?.message}</Typography>
    <Button onClick={onRetry}>{COMMON.RETRY}</Button>
  </ErrorBanner>
);

/** Customer list with nested addresses. */
export const Customers = () => {
  const { canWrite, canDelete } = usePermission();
  const { notify } = useNotifier();
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [search, setSearch] = useState("");
  const [editor, setEditor] = useState(null);
  const [removeRow, setRemoveRow] = useState(null);
  const [selected, setSelected] = useState(null);
  const [addresses, setAddresses] = useState([]);
  const [addressEditor, setAddressEditor] = useState(null);
  const debounced = useDebounce(search);
  const { data, meta, isLoading, error, reload } = useApi(
    () => listCustomers({ page, limit, search: debounced }),
    [page, limit, debounced]
  );

  const loadAddresses = async (customer) => {
    setSelected(customer);
    const result = await listAddresses(customer._id);
    setAddresses(result.data || []);
  };

  const handleSave = async (body) => {
    if (editor?._id) await updateCustomer(editor._id, body);
    else await createCustomer(body);
    notify({ severity: "success", message: COMMON.SUCCESS });
    setEditor(null);
    reload();
  };

  const handleAddressSave = async (body) => {
    if (addressEditor?._id) await updateAddress(addressEditor._id, body);
    else await createAddress(selected._id, body);
    notify({ severity: "success", message: COMMON.SUCCESS });
    setAddressEditor(null);
    loadAddresses(selected);
  };

  return (
    <PageStack>
      <PageHeader
        title={CUSTOMERS.TITLE}
        actions={
          canWrite ? (
            <Button variant="contained" onClick={() => setEditor({})}>
              {CUSTOMERS.NEW}
            </Button>
          ) : null
        }
      />
      <FilterRow>
        <GrowBox>
          <TextField label={COMMON.SEARCH} value={search} onChange={(event) => setSearch(event.target.value)} />
        </GrowBox>
      </FilterRow>
      {error ? <ErrorPanel error={error} onRetry={reload} /> : null}
      {isLoading ? <Loader /> : null}
      {!isLoading && !(data || []).length ? <EmptyState message={CUSTOMERS.EMPTY} /> : null}
      {!isLoading && (data || []).length ? (
        <DataTable
          columns={CUSTOMERS.COLUMNS}
          rows={data || []}
          meta={meta}
          onPageChange={(next, nextLimit) => {
            setPage(next);
            setLimit(nextLimit);
          }}
          onRowClick={loadAddresses}
          canWrite={canWrite}
          canDelete={canDelete}
          actions={[
            { id: "edit", label: COMMON.EDIT, require: "write", onClick: setEditor },
            { id: "remove", label: COMMON.DELETE, require: "delete", onClick: setRemoveRow },
          ]}
        />
      ) : null}

      <FormDialog
        open={Boolean(editor)}
        title={editor?._id ? COMMON.EDIT : CUSTOMERS.NEW}
        fields={CUSTOMERS.FIELDS}
        initialValues={editor}
        onClose={() => setEditor(null)}
        onSubmit={handleSave}
      />
      <ConfirmDialog
        open={Boolean(removeRow)}
        title={CONFIRM.DELETE_TITLE}
        body={CONFIRM.DELETE_BODY}
        onClose={() => setRemoveRow(null)}
        onConfirm={async () => {
          await removeCustomer(removeRow._id);
          notify({ severity: "success", message: COMMON.DELETED });
          setRemoveRow(null);
          reload();
        }}
      />

      <SideDrawer anchor="right" open={Boolean(selected)} onClose={() => setSelected(null)}>
        {selected ? (
          <DrawerPaper>
            <Typography variant="h2">{selected.fullName}</Typography>
            <Typography variant="h4">{CUSTOMERS.ADDRESSES}</Typography>
            {canWrite ? (
              <Button onClick={() => setAddressEditor({})}>{CUSTOMERS.ADD_ADDRESS}</Button>
            ) : null}
            {addresses.map((address) => (
              <PageStack key={address._id}>
                <FlagChipWrap>
                  <Typography variant="body2">
                    {address.label} · {address.city}, {address.state}
                  </Typography>
                  {address.isDefault ? <Chip size="small" label={CUSTOMERS.DEFAULT} /> : null}
                </FlagChipWrap>
                <FilterRow>
                  {canWrite ? (
                    <Button size="small" onClick={() => setAddressEditor(address)}>
                      {COMMON.EDIT}
                    </Button>
                  ) : null}
                  {canWrite && !address.isDefault ? (
                    <Button size="small" onClick={() => setDefaultAddress(address._id).then(() => loadAddresses(selected))}>
                      {CUSTOMERS.SET_DEFAULT}
                    </Button>
                  ) : null}
                  {canDelete ? (
                    <Button size="small" color="error" onClick={() => removeAddress(address._id).then(() => loadAddresses(selected))}>
                      {COMMON.DELETE}
                    </Button>
                  ) : null}
                </FilterRow>
              </PageStack>
            ))}
          </DrawerPaper>
        ) : null}
      </SideDrawer>

      <FormDialog
        open={Boolean(addressEditor)}
        title={CUSTOMERS.ADD_ADDRESS}
        fields={CUSTOMERS.ADDRESS_FIELDS}
        initialValues={addressEditor}
        extraOptions={{
          labels: CUSTOMERS.ADDRESS_LABELS.map((label) => ({ value: label, label })),
        }}
        onClose={() => setAddressEditor(null)}
        onSubmit={handleAddressSave}
      />
    </PageStack>
  );
};

export default Customers;

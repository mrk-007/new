/**
 * @file App.jsx
 * @description Route tree only.
 */
import { Routes, Route, Navigate } from "react-router-dom";
import { ROUTES } from "./constants/routes.js";
import ProtectedRoute, { HomeRedirect } from "./components/layout/ProtectedRoute.jsx";
import AppLayout from "./components/layout/AppLayout.jsx";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Orders from "./pages/Orders.jsx";
import OrderNew from "./pages/OrderNew.jsx";
import Subscriptions from "./pages/Subscriptions.jsx";
import SubscriptionNew from "./pages/SubscriptionNew.jsx";
import Visits from "./pages/Visits.jsx";
import MyVisits from "./pages/MyVisits.jsx";
import Customers from "./pages/Customers.jsx";
import Technicians from "./pages/Technicians.jsx";
import Users from "./pages/Users.jsx";
import Audit from "./pages/Audit.jsx";
import Masters from "./pages/Masters.jsx";

/** Declares public and protected routes. */
const App = () => (
  <Routes>
    <Route path={ROUTES.LOGIN} element={<Login />} />
    <Route
      element={
        <ProtectedRoute>
          <AppLayout />
        </ProtectedRoute>
      }
    >
      <Route index element={<HomeRedirect />} />
      <Route path={ROUTES.DASHBOARD} element={<Dashboard />} />
      <Route path={ROUTES.ORDERS} element={<Orders />} />
      <Route path={ROUTES.ORDER_NEW} element={<OrderNew />} />
      <Route path={ROUTES.SUBSCRIPTIONS} element={<Subscriptions />} />
      <Route path={ROUTES.SUBSCRIPTION_NEW} element={<SubscriptionNew />} />
      <Route path={ROUTES.VISITS} element={<Visits />} />
      <Route path={ROUTES.MY_VISITS} element={<MyVisits />} />
      <Route path={ROUTES.CUSTOMERS} element={<Customers />} />
      <Route path={ROUTES.TECHNICIANS} element={<Technicians />} />
      <Route path={ROUTES.USERS} element={<Users />} />
      <Route path={ROUTES.AUDIT} element={<Audit />} />
      <Route path={ROUTES.MASTER} element={<Masters />} />
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>
);

export default App;

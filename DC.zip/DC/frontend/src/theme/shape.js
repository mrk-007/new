/**
 * @file shape.js
 * @description Corner, layout, and motion tokens.
 */

export const shape = {
  borderRadius: 12,
  borderRadiusSm: 10,
  borderRadiusMd: 12,
  borderRadiusLg: 16,
  borderRadiusPill: 9999,
  sidebarWidth: 260,
  sidebarCollapsed: 84,
  topbarHeight: 72,
  transitionMs: "200ms",
};

export default shape;

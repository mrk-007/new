/**
 * @file shape.js
 * @description Centralized shape and layout dimension tokens.
 */

export const shape = {
  borderRadius: 8,
  borderRadiusSm: 8,
  borderRadiusMd: 9,
  borderRadiusLg: 10,
  borderRadiusLogo: 12,
  borderRadiusCard: 13,
  borderRadiusHero: 14,
  borderRadiusPill: 9999,
  borderWidth: "1px",
  borderWidthDashed: "1px",
  sidebarWidth: 245,
  topbarHeight: 72,
  catalogArtHeight: 112,
  logoSize: 42,
};

export default shape;

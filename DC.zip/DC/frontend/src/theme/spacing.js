/**
 * @file spacing.js
 * @description Centralized spacing system scaling from an 8px base factor.
 */

/**
 * Computes CSS pixel spacing from scaling multiplier arguments.
 */
export const spacing = (...factors) => {
  if (factors.length === 0) return "8px";
  return factors.map((factor) => `${factor * 8}px`).join(" ");
};

export default spacing;

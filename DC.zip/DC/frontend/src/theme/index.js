/**
 * @file index.js
 * @description Assembles the MUI theme from palette, type, shape, and overrides.
 */
import { createTheme } from "@mui/material/styles";
import { getPalette } from "./palette.js";
import { typography } from "./typography.js";
import { shape } from "./shape.js";
import { getComponents } from "./components.js";

/** Creates a complete theme for light or dark mode. */
export const createAppTheme = (mode) => {
  const palette = getPalette(mode);
  return createTheme({
    palette,
    typography,
    shape,
    components: getComponents(palette, shape, typography),
  });
};

export default createAppTheme;

/**
 * @file index.js
 * @description Theme entry point compiling palette, typography, spacing, shape, and component overrides.
 */
import { createTheme } from "@mui/material/styles";
import { palette } from "./palette.js";
import { typography } from "./typography.js";
import { spacing } from "./spacing.js";
import { shape } from "./shape.js";
import { components } from "./components.js";

export const theme = createTheme({
  palette,
  typography,
  spacing,
  shape,
  components,
});

export default theme;

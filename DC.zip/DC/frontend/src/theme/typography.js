/**
 * @file typography.js
 * @description Single Inter type scale used across the app.
 */

export const FONT_FAMILY =
  "Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif";

export const typography = {
  fontFamily: FONT_FAMILY,
  h1: { fontSize: "1.5rem", fontWeight: 700, lineHeight: 1.25 },
  h2: { fontSize: "1.25rem", fontWeight: 700, lineHeight: 1.3 },
  h3: { fontSize: "1.05rem", fontWeight: 600, lineHeight: 1.35 },
  h4: { fontSize: "0.95rem", fontWeight: 600, lineHeight: 1.4 },
  body1: { fontSize: "0.9rem", lineHeight: 1.5 },
  body2: { fontSize: "0.8rem", lineHeight: 1.45 },
  caption: { fontSize: "0.72rem", fontWeight: 600, letterSpacing: "0.08em" },
  button: { fontWeight: 600, textTransform: "none" },
};

export default typography;

/**
 * @file typography.js
 * @description Typography tokens, font definitions, and heading variants.
 */

export const fonts = {
  heading: "Segoe UI, -apple-system, BlinkMacSystemFont, Arial, sans-serif",
  body: "Segoe UI, -apple-system, BlinkMacSystemFont, Arial, sans-serif",
  mono: "'Courier New', Courier, monospace",
};

export const typography = {
  fontFamily: fonts.body,
  headingFont: fonts.heading,
  monoFont: fonts.mono,
  h1: {
    fontFamily: fonts.heading,
    fontSize: "1.375rem",
    fontWeight: 700,
    lineHeight: 1.25,
  },
  h2: {
    fontFamily: fonts.heading,
    fontSize: "1rem",
    fontWeight: 700,
    lineHeight: 1.3,
  },
  h3: {
    fontFamily: fonts.heading,
    fontSize: "0.84375rem",
    fontWeight: 600,
    lineHeight: 1.35,
  },
  body1: {
    fontFamily: fonts.body,
    fontSize: "0.78125rem",
    lineHeight: 1.45,
  },
  body2: {
    fontFamily: fonts.body,
    fontSize: "0.71875rem",
    lineHeight: 1.4,
  },
  caption: {
    fontFamily: fonts.body,
    fontSize: "0.65625rem",
    fontWeight: 700,
    letterSpacing: "0.12em",
  },
  button: {
    fontFamily: fonts.body,
    fontWeight: 650,
    textTransform: "none",
  },
};

export default typography;

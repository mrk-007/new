/**
 * @file palette.js
 * @description Light and dark palettes, brand tokens, and status-tone map.
 */

const STATUS_TONES_LIGHT = {
  PENDING: { bg: "#f1f5f9", color: "#475569", border: "#cbd5e1" },
  SITE_VISIT_PENDING: { bg: "#e6efff", color: "#1b55ac", border: "#93c5fd" },
  QUOTED: { bg: "#f3e8ff", color: "#6b21a8", border: "#d8b4fe" },
  CONFIRMED: { bg: "#dbeafe", color: "#1d4ed8", border: "#93c5fd" },
  ASSIGNED: { bg: "#e0f2fe", color: "#0369a1", border: "#7dd3fc" },
  IN_PROGRESS: { bg: "#fff1d8", color: "#9c5b00", border: "#fde047" },
  COMPLETED: { bg: "#dcf7e9", color: "#08764b", border: "#86efac" },
  CANCELLED: { bg: "#fee2e2", color: "#ad1e1e", border: "#fca5a5" },
  RELEASED: { bg: "#f1f5f9", color: "#64748b", border: "#cbd5e1" },
  DEFAULT: { bg: "#f1f5f9", color: "#64748b", border: "#cbd5e1" },
};

const STATUS_TONES_DARK = {
  PENDING: { bg: "#1e293b", color: "#cbd5e1", border: "#334155" },
  SITE_VISIT_PENDING: { bg: "#1e3a5f", color: "#93c5fd", border: "#1d4ed8" },
  QUOTED: { bg: "#3b0764", color: "#e9d5ff", border: "#7e22ce" },
  CONFIRMED: { bg: "#1e3a8a", color: "#bfdbfe", border: "#2563eb" },
  ASSIGNED: { bg: "#0c4a6e", color: "#7dd3fc", border: "#0284c7" },
  IN_PROGRESS: { bg: "#422006", color: "#fde68a", border: "#ca8a04" },
  COMPLETED: { bg: "#064e3b", color: "#6ee7b7", border: "#059669" },
  CANCELLED: { bg: "#7f1d1d", color: "#fecaca", border: "#dc2626" },
  RELEASED: { bg: "#1e293b", color: "#94a3b8", border: "#334155" },
  DEFAULT: { bg: "#1e293b", color: "#94a3b8", border: "#334155" },
};

/** Returns a MUI-compatible palette for the given color mode. */
export const getPalette = (mode) => {
  const isDark = mode === "dark";
  return {
    mode,
    common: { white: "#ffffff", black: "#0b1224" },
    primary: {
      main: "#5b47dc",
      light: "#7a66ec",
      dark: "#4e38bf",
      contrastText: "#ffffff",
    },
    secondary: {
      main: "#27c2a3",
      dark: "#1d9b82",
      contrastText: "#ffffff",
    },
    success: { main: "#08764b" },
    warning: { main: "#9c5b00" },
    error: { main: "#ad1e1e" },
    info: { main: "#1b55ac" },
    background: {
      default: isDark ? "#0b1224" : "#f5f7fb",
      paper: isDark ? "#111b32" : "#ffffff",
    },
    text: {
      primary: isDark ? "#e8edf7" : "#1f2937",
      secondary: isDark ? "#9aa8c2" : "#64748b",
    },
    divider: isDark ? "#243049" : "#e5e7eb",
    surface: {
      subtle: isDark ? "#0f1830" : "#fafbfc",
      lane: isDark ? "#121c36" : "#f8fafc",
      nav: "#111b32",
      navDark: "#0b1224",
      navHover: "#313270",
      navBorder: "#33415e",
    },
    gradients: {
      brand: "linear-gradient(135deg, #7a66ec, #27c2a3)",
      nav: "linear-gradient(180deg, #111b32, #0b1224)",
      hero: "linear-gradient(135deg, #2d2f75, #604bdc)",
      catalog: "linear-gradient(135deg, #eef2ff, #ecfeff)",
    },
    shadows: {
      card: isDark ? "0 8px 26px rgba(0, 0, 0, 0.35)" : "0 8px 26px rgba(15, 23, 42, 0.06)",
    },
    statusTones: isDark ? STATUS_TONES_DARK : STATUS_TONES_LIGHT,
  };
};

export default getPalette;

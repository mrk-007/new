/**
 * @file palette.js
 * @description Centralized color palette, gradient surfaces, and semantic tones.
 */

export const palette = {
  mode: "light",
  primary: {
    main: "#5b47dc",
    light: "#7a66ec",
    dark: "#4e38bf",
    soft: "#efedff",
    contrastText: "#ffffff",
  },
  secondary: {
    main: "#27c2a3",
    contrastText: "#ffffff",
  },
  background: {
    default: "#f5f7fb",
    paper: "#ffffff",
    subtle: "#fafbfc",
    lane: "#f8fafc",
    step: "#eef2ff",
    notice: "#eff6ff",
    nav: "#111b32",
    navDark: "#0b1224",
    navHover: "#313270",
    navBorder: "#33415e",
    navBox: "#111c35",
    brandGradient: "linear-gradient(135deg, #7a66ec, #27c2a3)",
    navGradient: "linear-gradient(180deg, #111b32, #0b1224)",
    productArtGradient: "linear-gradient(135deg, #eef2ff, #ecfeff)",
    heroGradient: "linear-gradient(135deg, #2d2f75, #604bdc)",
  },
  text: {
    primary: "#1f2937",
    secondary: "#64748b",
    muted: "#64748b",
    light: "#dce4f5",
    navCaption: "#8390ae",
    notice: "#1e40af",
  },
  divider: "#e5e7eb",
  shadows: {
    card: "0 8px 26px rgba(15, 23, 42, 0.06)",
    navBox: "0 -8px 20px rgba(6, 12, 26, 0.18)",
  },
  tones: {
    default: {
      bg: "#f1f5f9",
      color: "#64748b",
      border: "#cbd5e1",
    },
    info: {
      bg: "#e6efff",
      color: "#1b55ac",
      border: "#93c5fd",
    },
    success: {
      bg: "#dcf7e9",
      color: "#08764b",
      border: "#86efac",
    },
    warning: {
      bg: "#fff1d8",
      color: "#9c5b00",
      border: "#fde047",
    },
    error: {
      bg: "#fee2e2",
      color: "#ad1e1e",
      border: "#fca5a5",
    },
  },
};

export default palette;

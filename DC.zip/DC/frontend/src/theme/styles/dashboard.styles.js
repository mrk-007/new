/**
 * @file dashboard.styles.js
 * @description Dashboard KPI, flow, lifecycle, and catalog layout.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Paper from "@mui/material/Paper";
import Card from "@mui/material/Card";

export const KpiGrid = styled(Box)(({ theme }) => ({
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
  gap: theme.spacing(2),
}));

export const SplitGrid = styled(Box)(({ theme }) => ({
  display: "grid",
  gridTemplateColumns: "2fr 1fr",
  gap: theme.spacing(2),
  [theme.breakpoints.down("md")]: { gridTemplateColumns: "1fr" },
}));

export const SectionCard = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2.5),
  height: "100%",
}));

export const CatalogGrid = styled(Box)(({ theme }) => ({
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
  gap: theme.spacing(2),
}));

export const CatalogCard = styled(Card)(({ theme }) => ({
  padding: theme.spacing(2),
  display: "flex",
  flexDirection: "column",
  gap: theme.spacing(1),
}));

export const CatalogArt = styled(Box)(({ theme }) => ({
  height: 88,
  borderRadius: theme.shape.borderRadiusMd,
  backgroundImage: theme.palette.gradients.catalog,
}));

export const StepList = styled(Stack)(({ theme }) => ({
  gap: theme.spacing(1),
  marginTop: theme.spacing(2),
}));

/**
 * @file common.styles.js
 * @description Styled wrappers for shared UI primitives.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Paper from "@mui/material/Paper";
import TableContainer from "@mui/material/TableContainer";
import Chip from "@mui/material/Chip";

export const PageStack = styled(Stack)(({ theme }) => ({
  gap: theme.spacing(2.5),
}));

export const ToolbarRow = styled(Stack)(({ theme }) => ({
  flexDirection: "row",
  flexWrap: "wrap",
  gap: theme.spacing(1.5),
  alignItems: "center",
  justifyContent: "space-between",
}));

export const FilterRow = styled(Stack)(({ theme }) => ({
  flexDirection: "row",
  flexWrap: "wrap",
  gap: theme.spacing(1.5),
  alignItems: "center",
}));

export const GrowBox = styled(Box)({
  flex: 1,
  minWidth: 180,
});

export const TablePaper = styled(Paper)(({ theme }) => ({
  overflow: "hidden",
  [theme.breakpoints.down("md")]: { display: "none" },
}));

export const DesktopTable = styled(TableContainer)({
  maxHeight: 640,
});

export const MobileCardList = styled(Stack)(({ theme }) => ({
  gap: theme.spacing(1.5),
  [theme.breakpoints.up("md")]: { display: "none" },
}));

export const MobileCard = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  borderRadius: theme.shape.borderRadiusLg,
}));

export const StatRoot = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2.5),
  display: "flex",
  flexDirection: "column",
  gap: theme.spacing(0.75),
  minHeight: 110,
}));

export const StatValue = styled(Box)(({ theme }) => ({
  fontSize: "1.4rem",
  fontWeight: 700,
  color: theme.palette.primary.main,
}));

export const StatusToneChip = styled(Chip, {
  shouldForwardProp: (prop) => prop !== "tone",
})(({ tone, theme }) => {
  const map = theme.palette.statusTones || {};
  const colors = map[tone] || map.DEFAULT;
  return {
    backgroundColor: colors.bg,
    color: colors.color,
    border: `1px solid ${colors.border}`,
    fontWeight: 600,
  };
});

export const LoaderBox = styled(Stack)(({ theme }) => ({
  padding: theme.spacing(6),
  alignItems: "center",
  justifyContent: "center",
  gap: theme.spacing(2),
}));

export const EmptyBox = styled(Stack)(({ theme }) => ({
  padding: theme.spacing(6),
  alignItems: "center",
  gap: theme.spacing(1),
  color: theme.palette.text.secondary,
}));

export const HeaderRow = styled(Stack)(({ theme }) => ({
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: theme.spacing(2),
  flexWrap: "wrap",
}));

export const FormStack = styled(Stack)(({ theme }) => ({
  gap: theme.spacing(2),
  paddingTop: theme.spacing(1),
}));

export const ErrorBanner = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: theme.spacing(2),
  border: `1px solid ${theme.palette.error.main}`,
}));

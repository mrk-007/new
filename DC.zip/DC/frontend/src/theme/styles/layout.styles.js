/**
 * @file layout.styles.js
 * @description Sidebar, topbar, and shell layout.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Drawer from "@mui/material/Drawer";
import ListItemButton from "@mui/material/ListItemButton";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";

export const Shell = styled(Box)({
  display: "flex",
  minHeight: "100vh",
});

export const NavDrawer = styled(Drawer, {
  shouldForwardProp: (prop) => prop !== "isCollapsed",
})(({ theme, isCollapsed }) => ({
  "& .MuiDrawer-paper": {
    width: isCollapsed ? theme.shape.sidebarCollapsed : theme.shape.sidebarWidth,
    backgroundImage: theme.palette.gradients.nav,
    color: theme.palette.common.white,
    borderRight: "none",
    transition: `width ${theme.shape.transitionMs} ease`,
    overflowX: "hidden",
  },
}));

export const BrandRow = styled(Stack)(({ theme }) => ({
  flexDirection: "row",
  alignItems: "center",
  gap: theme.spacing(1.5),
  padding: theme.spacing(2.5, 2),
}));

export const BrandMark = styled(Box)(({ theme }) => ({
  width: 42,
  height: 42,
  borderRadius: theme.shape.borderRadiusMd,
  backgroundImage: theme.palette.gradients.brand,
  flexShrink: 0,
}));

export const SectionCaption = styled(Box)(({ theme }) => ({
  padding: theme.spacing(2, 2, 0.5),
  fontSize: "0.68rem",
  letterSpacing: "0.12em",
  textTransform: "uppercase",
  color: "#8390ae",
  fontWeight: 700,
}));

export const NavButton = styled(ListItemButton, {
  shouldForwardProp: (prop) => prop !== "isActive",
})(({ theme, isActive }) => ({
  margin: theme.spacing(0.25, 1),
  borderRadius: theme.shape.borderRadiusMd,
  color: isActive ? theme.palette.common.white : "#dce4f5",
  backgroundColor: isActive ? theme.palette.surface.navHover : "transparent",
  position: "relative",
  "&::before": {
    content: '""',
    position: "absolute",
    left: 0,
    top: 8,
    bottom: 8,
    width: 3,
    borderRadius: theme.shape.borderRadiusPill,
    backgroundImage: isActive ? theme.palette.gradients.brand : "none",
  },
  "&:hover": { backgroundColor: theme.palette.surface.navHover },
}));

export const Main = styled(Box)(({ theme }) => ({
  flex: 1,
  display: "flex",
  flexDirection: "column",
  minWidth: 0,
  backgroundColor: theme.palette.background.default,
}));

export const TopBar = styled(AppBar)(({ theme }) => ({
  position: "sticky",
  backgroundColor: theme.palette.background.paper,
  color: theme.palette.text.primary,
  boxShadow: theme.palette.shadows.card,
}));

export const TopToolbar = styled(Toolbar)(({ theme }) => ({
  minHeight: theme.shape.topbarHeight,
  gap: theme.spacing(1.5),
  justifyContent: "space-between",
}));

export const Content = styled(Box)(({ theme }) => ({
  padding: theme.spacing(3),
  [theme.breakpoints.down("sm")]: { padding: theme.spacing(2) },
}));

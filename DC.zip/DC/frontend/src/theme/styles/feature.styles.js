/**
 * @file feature.styles.js
 * @description Shared layout for orders, visits, customers, and wizards.
 */
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Paper from "@mui/material/Paper";
import Drawer from "@mui/material/Drawer";

export const DrawerPaper = styled(Box)(({ theme }) => ({
  width: 440,
  maxWidth: "100vw",
  padding: theme.spacing(3),
  display: "flex",
  flexDirection: "column",
  gap: theme.spacing(2),
  [theme.breakpoints.down("sm")]: { width: "100vw" },
}));

export const SideDrawer = styled(Drawer)({
  "& .MuiDrawer-paper": { overflowY: "auto" },
});

export const SnapshotBox = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: theme.spacing(1),
}));

export const WizardCard = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(3),
  display: "flex",
  flexDirection: "column",
  gap: theme.spacing(2),
}));

export const FlagChipWrap = styled(Stack)(({ theme }) => ({
  flexDirection: "row",
  gap: theme.spacing(1),
  flexWrap: "wrap",
  alignItems: "center",
}));

export const VisitCard = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(2),
  display: "flex",
  flexDirection: "column",
  gap: theme.spacing(1.25),
}));

/**
 * @file components.js
 * @description Global MUI overrides so screens can use unstyled-prop components.
 */

/** Builds component overrides bound to the active palette and shape. */
export const getComponents = (palette, shape, typography) => ({
  MuiCssBaseline: {
    styleOverrides: {
      body: {
        backgroundColor: palette.background.default,
        color: palette.text.primary,
        fontFamily: typography.fontFamily,
        margin: 0,
      },
    },
  },
  MuiButton: {
    defaultProps: { disableElevation: true },
    styleOverrides: {
      root: {
        borderRadius: shape.borderRadiusMd,
        textTransform: "none",
        fontWeight: 600,
        transition: `all ${shape.transitionMs} ease`,
      },
    },
  },
  MuiPaper: {
    styleOverrides: {
      root: {
        borderRadius: shape.borderRadiusLg,
        backgroundImage: "none",
      },
      elevation1: { boxShadow: palette.shadows.card },
    },
  },
  MuiCard: {
    styleOverrides: {
      root: {
        borderRadius: shape.borderRadiusLg,
        boxShadow: palette.shadows.card,
        border: `1px solid ${palette.divider}`,
      },
    },
  },
  MuiTextField: {
    defaultProps: { size: "small", fullWidth: true },
  },
  MuiOutlinedInput: {
    styleOverrides: {
      root: { borderRadius: shape.borderRadiusMd },
    },
  },
  MuiChip: {
    styleOverrides: {
      root: { borderRadius: shape.borderRadiusSm, fontWeight: 600 },
    },
  },
  MuiDialog: {
    styleOverrides: {
      paper: { borderRadius: shape.borderRadiusLg },
    },
  },
  MuiDrawer: {
    styleOverrides: {
      paper: { border: "none" },
    },
  },
  MuiTabs: {
    styleOverrides: {
      indicator: { height: 3, borderRadius: shape.borderRadiusPill },
    },
  },
  MuiTableHead: {
    styleOverrides: {
      root: {
        position: "sticky",
        top: 0,
        zIndex: 1,
        backgroundColor: palette.surface.lane,
      },
    },
  },
  MuiTableRow: {
    styleOverrides: {
      root: {
        transition: `background-color ${shape.transitionMs} ease`,
        "&:hover": { backgroundColor: palette.surface.subtle },
      },
    },
  },
  MuiIconButton: {
    styleOverrides: {
      root: { borderRadius: shape.borderRadiusMd },
    },
  },
  MuiSkeleton: {
    defaultProps: { animation: "wave" },
  },
});

export default getComponents;

/**
 * @file components.js
 * @description Material UI component overrides integrating typography, shape, and palette.
 */
import { palette } from "./palette.js";
import { shape } from "./shape.js";
import { typography } from "./typography.js";

export const components = {
  MuiCssBaseline: {
    styleOverrides: {
      body: {
        backgroundColor: palette.background.default,
        color: palette.text.primary,
        fontFamily: typography.fontFamily,
        margin: 0,
        boxSizing: "border-box",
      },
      "*, *::before, *::after": {
        boxSizing: "border-box",
      },
    },
  },
  MuiButton: {
    styleOverrides: {
      root: {
        borderRadius: shape.borderRadiusMd,
        textTransform: "none",
        fontWeight: typography.button.fontWeight,
      },
    },
  },
  MuiCard: {
    styleOverrides: {
      root: {
        borderRadius: shape.borderRadiusCard,
        boxShadow: palette.shadows.card,
        border: `${shape.borderWidth} solid ${palette.divider}`,
      },
    },
  },
};

export default components;

/**
 * @file api.js
 * @description Single HTTP module. Components never call fetch or build URLs.
 */
import { APP } from "../constants/Content.js";

const BASE = import.meta.env.VITE_API_BASE_URL || "/api/v1";

let onUnauthorized = null;
let onNotify = null;

/** Registers the session-expiry handler from AuthContext. */
export const setUnauthorizedHandler = (handler) => {
  onUnauthorized = handler;
};

/** Registers the snackbar handler from NotifierContext. */
export const setNotifyHandler = (handler) => {
  onNotify = handler;
};

/** Reads the stored JWT. */
const getToken = () => localStorage.getItem(APP.TOKEN_KEY);

/** Builds a query string from defined values. */
const queryString = (params = {}) => {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value === undefined || value === null || value === "") return;
    search.set(key, String(value));
  });
  const text = search.toString();
  return text ? `?${text}` : "";
};

/** Low-level fetch wrapper that unwraps { success, data, meta }. */
export const request = async (method, path, body, params) => {
  const headers = { "Content-Type": "application/json" };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;

  const response = await fetch(`${BASE}${path}${queryString(params)}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  let json = {};
  try {
    json = await response.json();
  } catch {
    json = { message: "Unexpected server response." };
  }

  if (response.status === 401) {
    if (onUnauthorized) onUnauthorized();
    throw { status: 401, message: json.message || "Session expired.", errors: json.errors };
  }

  if (!response.ok || json.success === false) {
    const error = {
      status: response.status,
      message: json.message || "Request failed.",
      errors: json.errors,
    };
    if ((response.status === 403 || response.status >= 500) && onNotify) {
      onNotify({ severity: "error", message: error.message });
    }
    throw error;
  }

  return {
    data: json.data,
    meta: json.meta,
    message: json.message,
    raw: json,
  };
};

/* ── Auth ── */

/** Signs in and returns token plus user from the login envelope. */
export const login = async (email, password) => {
  const result = await request("POST", "/auth/login", { email, password });
  const token = result.raw.token || result.data?.token;
  const user = result.raw.user || result.data?.user;
  return { token, user };
};

/** Restores the current session. */
export const getMe = async () => {
  const result = await request("GET", "/auth/me");
  return result.data || result.raw.user;
};

/** Creates a user (write). */
export const createUser = (body) => request("POST", "/auth/users", body);

/* ── Masters (generic by endpoint key) ── */

export const listMaster = (endpoint, params) => request("GET", `/${endpoint}`, undefined, params);
export const getMaster = (endpoint, id) => request("GET", `/${endpoint}/${id}`);
export const createMaster = (endpoint, body) => request("POST", `/${endpoint}`, body);
export const updateMaster = (endpoint, id, body) => request("PUT", `/${endpoint}/${id}`, body);
export const removeMaster = (endpoint, id) => request("DELETE", `/${endpoint}/${id}`);

/* ── Users ── */

export const listUsers = (params) => request("GET", "/users", undefined, params);
export const getUser = (id) => request("GET", `/users/${id}`);
export const updateUser = (id, body) => request("PUT", `/users/${id}`, body);
export const removeUser = (id) => request("DELETE", `/users/${id}`);

/* ── Customers and addresses ── */

export const listCustomers = (params) => request("GET", "/customers", undefined, params);
export const getCustomer = (id) => request("GET", `/customers/${id}`);
export const createCustomer = (body) => request("POST", "/customers", body);
export const updateCustomer = (id, body) => request("PUT", `/customers/${id}`, body);
export const removeCustomer = (id) => request("DELETE", `/customers/${id}`);
export const listAddresses = (customerId, params) =>
  request("GET", `/customers/${customerId}/addresses`, undefined, params);
export const createAddress = (customerId, body) => request("POST", `/customers/${customerId}/addresses`, body);
export const updateAddress = (id, body) => request("PUT", `/addresses/${id}`, body);
export const removeAddress = (id) => request("DELETE", `/addresses/${id}`);
export const setDefaultAddress = (id) => request("PATCH", `/addresses/${id}/default`);

/* ── Technicians and skills ── */

export const listTechnicians = (params) => request("GET", "/technicians", undefined, params);
export const getTechnician = (id) => request("GET", `/technicians/${id}`);
export const createTechnician = (body) => request("POST", "/technicians", body);
export const updateTechnician = (id, body) => request("PUT", `/technicians/${id}`, body);
export const removeTechnician = (id) => request("DELETE", `/technicians/${id}`);
export const setTechnicianAvailability = (id, isAvailable) =>
  request("PATCH", `/technicians/${id}/availability`, { isAvailable });
export const getTechnicianSkills = (id) => request("GET", `/technicians/${id}/skills`);
export const putTechnicianSkills = (id, skills) => request("PUT", `/technicians/${id}/skills`, { skills });

/* ── Quote and slots ── */

export const getQuote = (params) => request("GET", "/pricing/quote", undefined, params);
export const getAvailableSlots = (params) => request("GET", "/time-slots/available", undefined, params);

/* ── Orders ── */

export const listOrders = (params) => request("GET", "/orders", undefined, params);
export const getOrder = (id) => request("GET", `/orders/${id}`);
export const createOrder = (body) => request("POST", "/orders", body);
export const confirmOrder = (id, body) => request("POST", `/orders/${id}/confirm`, body);
export const cancelOrder = (id, body) => request("POST", `/orders/${id}/cancel`, body);
export const patchOrderStatus = (id, body) => request("PATCH", `/orders/${id}/status`, body);

/* ── Subscriptions ── */

export const listSubscriptions = (params) => request("GET", "/subscriptions", undefined, params);
export const getSubscription = (id) => request("GET", `/subscriptions/${id}`);
export const createSubscription = (body) => request("POST", "/subscriptions", body);
export const cancelSubscription = (id, body) => request("POST", `/subscriptions/${id}/cancel`, body);

/* ── Visits ── */

export const listVisits = (params) => request("GET", "/visits", undefined, params);
export const listMyVisits = (params) => request("GET", "/visits/mine", undefined, params);
export const getVisit = (id) => request("GET", `/visits/${id}`);
export const startVisit = (id) => request("PATCH", `/visits/${id}/start`);
export const completeVisit = (id, body) => request("PATCH", `/visits/${id}/complete`, body);
export const cancelVisit = (id, body) => request("PATCH", `/visits/${id}/cancel`, body);
export const allocateVisit = (id, body) => request("POST", `/visits/${id}/allocate`, body);
export const reassignVisit = (id, body) => request("PATCH", `/visits/${id}/reassign`, body);

/* ── Audit and dashboard ── */

export const listAuditLogs = (params) => request("GET", "/audit-logs", undefined, params);
export const getDashboard = () => request("GET", "/dashboard");

export default {
  login,
  getMe,
  listMaster,
  listOrders,
  getDashboard,
};

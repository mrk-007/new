import apiClient from "./apiClient";

export const dashboardService = {
  /**
   * Fetch complete dashboard overview: KPI metrics, today's visits, lifecycle steps, catalog preview
   */
  async getOverview() {
    try {
      const response = await apiClient.get("/dashboard");
      return response.data;
    } catch {
      // Graceful fallback matching seed prototype values
      return {
        kpis: {
          ordersToday: 19,
          jobsToday: 24,
          activeSubscriptions: 74,
          availableTechnicians: 12,
          monthCollection: "₹5.48L",
        },
        todayFlow: [
          {
            id: "flow-1",
            property: "Lake View Apartments",
            work: "Shoe Rack Installation + Bathroom Cleaning",
            technician: "Arun S.",
            arrival: { label: "On Time", badgeClass: "green" },
            workStatus: { label: "In Progress", badgeClass: "blue" },
            followUp: { label: "-", badgeClass: "muted" },
          },
          {
            id: "flow-2",
            property: "Green Court",
            work: "Deep Cleaning · 3BHK",
            technician: "Cleaning Team 2",
            arrival: { label: "18 min late", badgeClass: "red" },
            workStatus: { label: "In Progress", badgeClass: "blue" },
            followUp: { label: "-", badgeClass: "muted" },
          },
          {
            id: "flow-3",
            property: "Skyline Towers",
            work: "Bathroom Cleaning · 3 Bathrooms",
            technician: "Ravi K.",
            arrival: { label: "On Time", badgeClass: "green" },
            workStatus: { label: "Completed", badgeClass: "green" },
            followUp: { label: "Pending", badgeClass: "amber" },
          },
        ],
        lifecycle: {
          title: "Urban-style Job Lifecycle",
          steps: [
            "Booking Confirmed",
            "Professional Assigned",
            "On the Way",
            "Reached",
            "Work Started",
            "Completed",
            "Customer Follow-up",
            "Closed",
          ],
          notice:
            "Installation and cleaning use the same execution controls: date and slot, assignment, reach tracking, work start/completion, customer confirmation and closure.",
        },
        catalogPreview: [
          {
            id: "cat-1",
            name: "Shoe Rack Installation",
            icon: "🛠️",
            group: "Product",
            description: "Customer order with invoice, delivery, installation and job closure.",
          },
          {
            id: "cat-2",
            name: "Bathroom Cleaning",
            icon: "🧼",
            group: "Product",
            description: "Customer order with invoice, delivery, installation and job closure.",
          },
          {
            id: "cat-3",
            name: "Deep Cleaning",
            icon: "✨",
            group: "Product",
            description: "Customer order with invoice, delivery, installation and job closure.",
          },
          {
            id: "cat-4",
            name: "Weekly Bathroom Cleaning",
            icon: "📅",
            group: "Subscription",
            description: "Recurring visit schedule with technician assignment and service tracking.",
          },
        ],
      };
    }
  },
};

export default dashboardService;

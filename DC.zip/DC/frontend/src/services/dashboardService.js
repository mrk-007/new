/**
 * @file dashboardService.js
 * @description API service methods for querying live operations dashboard dataset.
 */
import apiClient from "./apiClient.js";

export const dashboardService = {
  /**
   * Fetches end-to-end dashboard metrics, today's service flow, lifecycle, and catalog.
   */
  async getDashboard() {
    const res = await apiClient.get("/dashboard");
    return res.data;
  },
};

export default dashboardService;

/**
 * @file authService.js
 * @description API service methods for authentication login and profile session retrieval.
 */
import apiClient from "./apiClient.js";

export const authService = {
  /**
   * Sends user login credentials to receive JWT access token and user profile.
   */
  async login(email, password) {
    return apiClient.post("/auth/login", { email, password });
  },

  /**
   * Retrieves the current authenticated user session context.
   */
  async getMe() {
    return apiClient.get("/auth/me");
  },
};

export default authService;

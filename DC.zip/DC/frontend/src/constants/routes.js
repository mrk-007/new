/**
 * @file routes.js
 * @description Frontend routing constants across operations, catalog, and authentication.
 */

export const ROUTES = {
  HOME: "/",
  LOGIN: "/login",
  DASHBOARD: "/dashboard",
  CUSTOMERS: "/customers",
  ORDERS: "/orders",
  SUBSCRIPTIONS: "/subscriptions",
  JOB_ORDERS: "/jobs",
  SCHEDULE: "/schedule",
  TECHNICIANS: "/technicians",
  CATALOG: "/catalog",
  INVOICES: "/invoices",
  CONFIGURATION: "/configuration",
};

export default ROUTES;

export const ROUTES = {
  HOME: "/",
  DASHBOARD: "/dashboard",
  CUSTOMERS: "/customers",
  ORDERS: "/orders",
  SUBSCRIPTIONS: "/subscriptions",
  JOB_ORDERS: "/jobs",
  SCHEDULE: "/schedule",
  TECHNICIANS: "/technicians",
  CATALOG: "/catalog",
  INVOICES: "/invoices",
  CONFIGURATION: "/configuration",
  TECH_HOME: "/tech/home",
  TECH_CALENDAR: "/tech/calendar",
  TECH_HISTORY: "/tech/history",
  TECH_PROFILE: "/tech/profile",
  LOGIN: "/login",
};

export default ROUTES;

/**
 * @file routes.js
 * @description Path constants for the route tree and sidebar.
 */

export const ROUTES = {
  LOGIN: "/login",
  DASHBOARD: "/dashboard",
  ORDERS: "/orders",
  ORDER_NEW: "/orders/new",
  SUBSCRIPTIONS: "/subscriptions",
  SUBSCRIPTION_NEW: "/subscriptions/new",
  VISITS: "/visits",
  MY_VISITS: "/my-visits",
  CUSTOMERS: "/customers",
  TECHNICIANS: "/technicians",
  USERS: "/users",
  AUDIT: "/audit",
  MASTER: "/catalog/:resourceKey",
};

/** Builds a catalog path for a master resource key. */
export const masterPath = (resourceKey) => `/catalog/${resourceKey}`;

export default ROUTES;

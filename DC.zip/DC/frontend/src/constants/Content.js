/**
 * @file Content.js
 * @description All hard-coded copy, table columns, form fields, and master CRUD config.
 */

export const APP = {
  NAME: "DC Operations",
  TIMEZONE: "Asia/Kolkata",
  LOCALE: "en-IN",
  CURRENCY: "INR",
  TECHNICIAN_ROLE_NAME: "Technician",
  TOKEN_KEY: "token",
};

export const NAV = {
  GROUPS: {
    OPERATIONS: "Operations",
    PEOPLE: "People",
    CATALOG: "Catalog & configuration",
    CONTROL: "Control",
  },
  DASHBOARD: "Dashboard",
  ORDERS: "Orders",
  SUBSCRIPTIONS: "Subscriptions",
  VISITS: "Visits",
  MY_VISITS: "My Visits",
  CUSTOMERS: "Customers",
  TECHNICIANS: "Technicians",
  USERS: "Users",
  AUDIT: "Audit logs",
};

export const COMMON = {
  SAVE: "Save",
  CREATE: "Create",
  CANCEL: "Cancel",
  DELETE: "Deactivate",
  EDIT: "Edit",
  SEARCH: "Search",
  RETRY: "Retry",
  CLOSE: "Close",
  CONFIRM: "Confirm",
  LOADING: "Loading…",
  EMPTY: "Nothing to show yet.",
  SHOW_INACTIVE: "Show inactive",
  ACTIONS: "Actions",
  YES: "Yes",
  NO: "No",
  REQUIRED: "This field is required.",
  SUCCESS: "Saved.",
  DELETED: "Deactivated.",
  LOGOUT: "Log out",
  LIGHT: "Light mode",
  DARK: "Dark mode",
  PAGE: "Page",
  OF: "of",
};

export const LOGIN = {
  TITLE: "Sign in",
  SUBTITLE: "Deep Cleaning operations",
  EMAIL: "Email",
  PASSWORD: "Password",
  SUBMIT: "Sign in",
  ERROR: "Unable to sign in with those credentials.",
};

export const DASHBOARD = {
  TITLE: "Operations dashboard",
  KPI: {
    ordersToday: "Orders today",
    jobsToday: "Visits today",
    activeSubscriptions: "Active subscriptions",
    availableTechnicians: "Available technicians",
    monthCollection: "Month collection",
  },
  FLOW_TITLE: "Today's service flow",
  FLOW_EMPTY: "No visits scheduled for today.",
  FLOW_COLUMNS: [
    { key: "property", label: "Property" },
    { key: "work", label: "Work" },
    { key: "technician", label: "Technician" },
    { key: "arrival", label: "Arrival", chip: true },
    { key: "workStatus", label: "Work", chip: true },
    { key: "followUp", label: "Follow-up", chip: true },
  ],
  LIFECYCLE_FALLBACK: "Job lifecycle",
  CATALOG_TITLE: "Catalog preview",
  CATALOG_EMPTY: "No catalog items yet.",
};

export const ORDERS = {
  TITLE: "Orders",
  NEW: "New order",
  SEARCH: "Search order number",
  STATUS: "Status",
  ALL_STATUSES: "All statuses",
  EMPTY: "No orders match the current filters.",
  CONFIRM: "Confirm order",
  CANCEL: "Cancel order",
  CHANGE_STATUS: "Change status",
  CANCEL_REASON: "Cancel reason",
  NOTE: "Note",
    SITE_VISIT_HINT: "This product requires a site visit. Price will be quoted after measurement.",
    SERVICE_DATE: "Service date",
    SERVICE_TIME: "Service start time",
    UNIT_PRICE: "Unit price",
    CGST: "CGST",
    SGST: "SGST",
    TOTAL: "Total",
  COLUMNS: [
    { key: "orderNumber", label: "Order" },
    { key: "customer.fullName", label: "Customer" },
    { key: "product.name", label: "Product" },
    { key: "quantity", label: "Qty" },
    { key: "totalAmount", label: "Total", currency: true },
    { key: "status", label: "Status", status: true },
    { key: "createdAt", label: "Created", datetime: true },
  ],
  WIZARD: {
    TITLE: "New order",
    CUSTOMER: "Customer",
    ADDRESS: "Address",
    PRODUCT: "Product",
    QUANTITY: "Quantity",
    DATE: "Date",
    SLOT: "Time slot",
    QUOTE: "Quote",
    SUBMIT: "Create order",
    NO_SLOTS: "No slots available for this date.",
    NO_ADDRESSES: "This customer has no active addresses.",
  },
  DETAIL: {
    HISTORY: "Status history",
    VISITS: "Visits",
    PRICE: "Price snapshot",
    UNALLOCATED: "Unallocated",
  },
};

export const SUBSCRIPTIONS = {
  TITLE: "Subscriptions",
  NEW: "New subscription",
  SEARCH: "Search subscription number",
  EMPTY: "No subscriptions match the current filters.",
  CANCEL: "Cancel subscription",
  COLUMNS: [
    { key: "subscriptionNumber", label: "Subscription" },
    { key: "customer.fullName", label: "Customer" },
    { key: "subscriptionPlan.name", label: "Plan" },
    { key: "totalAmount", label: "Total", currency: true },
    { key: "status", label: "Status", status: true },
    { key: "isCompleted", label: "Completed", boolean: true },
    { key: "startDate", label: "Start", date: true },
  ],
  WIZARD: {
    TITLE: "New subscription",
    PLAN: "Plan",
    BATHROOM: "Bathroom count",
    PROPERTY: "Property size",
    TERM: "Term",
    FREQUENCY: "Frequency",
    START: "Start date",
    SLOT: "Preferred start time",
    SUBMIT: "Create subscription",
  },
};

export const VISITS = {
  TITLE: "Visits",
  MY_TITLE: "My visits",
  EMPTY: "No visits match the current filters.",
  DATE: "Date",
  STATUS: "Status",
  TYPE: "Type",
  TECHNICIAN: "Technician",
  START: "Start",
  COMPLETE: "Complete",
  CANCEL: "Cancel visit",
  ALLOCATE: "Allocate",
  REASSIGN: "Reassign",
  UNALLOCATED: "Unallocated",
  SITE_REPORT: "Site report",
  NOTES: "Notes",
  WIDTH: "Width",
  HEIGHT: "Height",
  UNIT: "Unit",
  QUOTED: "Quoted amount",
  REASON: "Reason",
  COLUMNS: [
    { key: "sequenceNo", label: "#" },
    { key: "visitType", label: "Type", status: true },
    { key: "customer.fullName", label: "Customer" },
    { key: "scheduledStart", label: "Start", datetime: true },
    { key: "scheduledEnd", label: "End", time: true },
    { key: "status", label: "Status", status: true },
    { key: "isCompleted", label: "Done", boolean: true },
  ],
};

export const CUSTOMERS = {
  TITLE: "Customers",
  NEW: "New customer",
  EMPTY: "No customers yet.",
  ADDRESSES: "Addresses",
  ADD_ADDRESS: "Add address",
  SET_DEFAULT: "Set default",
  DEFAULT: "Default",
  COLUMNS: [
    { key: "fullName", label: "Name" },
    { key: "mobile", label: "Mobile" },
    { key: "email", label: "Email" },
    { key: "isActive", label: "Active", boolean: true },
  ],
  FIELDS: [
    { name: "fullName", label: "Full name", type: "text", required: true },
    { name: "mobile", label: "Mobile", type: "text", required: true },
    { name: "alternateMobile", label: "Alternate mobile", type: "text" },
    { name: "email", label: "Email", type: "text" },
    { name: "notes", label: "Notes", type: "text" },
  ],
  ADDRESS_FIELDS: [
    { name: "label", label: "Label", type: "select", optionsKey: "labels" },
    { name: "apartment", label: "Apartment", type: "select", ref: "apartments" },
    { name: "doorNo", label: "Door no.", type: "text" },
    { name: "street", label: "Street", type: "text" },
    { name: "area", label: "Area", type: "text" },
    { name: "city", label: "City", type: "text", required: true },
    { name: "state", label: "State", type: "text", required: true },
    { name: "pincode", label: "Pincode", type: "text" },
    { name: "isDefault", label: "Default address", type: "switch" },
  ],
  ADDRESS_LABELS: ["Home", "Office", "Other"],
};

export const TECHNICIANS = {
  TITLE: "Technicians",
  NEW: "New technician",
  EMPTY: "No technicians yet.",
  SKILLS: "Skills",
  AVAILABLE: "Available",
  COLUMNS: [
    { key: "name", label: "Name" },
    { key: "mobile", label: "Mobile" },
    { key: "email", label: "Email" },
    { key: "isAvailable", label: "On duty", boolean: true },
    { key: "isActive", label: "Active", boolean: true },
  ],
  FIELDS: [
    { name: "name", label: "Name", type: "text", required: true },
    { name: "mobile", label: "Mobile", type: "text", required: true },
    { name: "email", label: "Email", type: "text" },
    { name: "isAvailable", label: "Available", type: "switch" },
  ],
};

export const USERS = {
  TITLE: "Users",
  NEW: "New user",
  EMPTY: "No users yet.",
  COLUMNS: [
    { key: "email", label: "Email" },
    { key: "role.roleName", label: "Role" },
    { key: "isActive", label: "Active", boolean: true },
    { key: "lastLoginAt", label: "Last login", datetime: true },
  ],
  FIELDS: [
    { name: "email", label: "Email", type: "text", required: true },
    { name: "password", label: "Password", type: "password", requiredOnCreate: true },
    { name: "role", label: "Role", type: "select", ref: "roles", required: true },
  ],
};

export const AUDIT = {
  TITLE: "Audit logs",
  EMPTY: "No audit rows match the filters.",
  ENTITY: "Entity",
  ACTION: "Action",
  USER: "User",
  FROM: "From",
  TO: "To",
  VIEW: "View changes",
  BEFORE: "Before",
  AFTER: "After",
  COLUMNS: [
    { key: "entity", label: "Entity" },
    { key: "action", label: "Action", status: true },
    { key: "performedBy.email", label: "User" },
    { key: "createdAt", label: "When", datetime: true },
  ],
};

export const CONFIRM = {
  DELETE_TITLE: "Deactivate this record?",
  DELETE_BODY: "It will be hidden from default lists. You can still view inactive rows.",
  CANCEL_TITLE: "Cancel this booking?",
  CANCEL_BODY: "Open visits will be cancelled and allocations released.",
};

export const ORDER_STATUSES = [
  "PENDING",
  "SITE_VISIT_PENDING",
  "QUOTED",
  "CONFIRMED",
  "IN_PROGRESS",
  "COMPLETED",
  "CANCELLED",
];

export const VISIT_STATUSES = ["PENDING", "IN_PROGRESS", "COMPLETED", "CANCELLED"];
export const VISIT_TYPES = ["SITE_VISIT", "SERVICE"];
export const AUDIT_ACTIONS = ["CREATE", "UPDATE", "DELETE"];

/** Config-driven master resources. Adding a master only needs an entry here plus a nav item. */
export const MASTER_CONFIG = {
  products: {
    endpoint: "products",
    title: "Products",
    search: true,
    columns: [
      { key: "code", label: "Code" },
      { key: "name", label: "Name" },
      { key: "serviceType.name", label: "Service type" },
      { key: "requiresSiteVisit", label: "Site visit", boolean: true },
      { key: "siteVisitMinutes", label: "Site minutes" },
    ],
    fields: [
      { name: "code", label: "Code", type: "text", required: true },
      { name: "name", label: "Name", type: "text", required: true },
      { name: "serviceType", label: "Service type", type: "select", ref: "service-types", required: true },
      { name: "requiresSiteVisit", label: "Requires site visit", type: "switch" },
      { name: "siteVisitMinutes", label: "Site visit minutes", type: "number" },
      { name: "description", label: "Description", type: "text" },
    ],
  },
  "subscription-plans": {
    endpoint: "subscription-plans",
    title: "Subscription plans",
    search: true,
    columns: [
      { key: "code", label: "Code" },
      { key: "name", label: "Name" },
      { key: "pricingBasis", label: "Pricing basis", status: true },
      { key: "requiresSiteVisit", label: "Site visit", boolean: true },
    ],
    fields: [
      { name: "code", label: "Code", type: "text", required: true },
      { name: "name", label: "Name", type: "text", required: true },
      { name: "serviceType", label: "Service type", type: "select", ref: "service-types", required: true },
      { name: "pricingBasis", label: "Pricing basis", type: "select", optionsKey: "pricingBasis", required: true },
      { name: "requiresSiteVisit", label: "Requires site visit", type: "switch" },
      { name: "siteVisitMinutes", label: "Site visit minutes", type: "number" },
    ],
  },
  pricing: {
    endpoint: "pricing",
    title: "Pricing",
    search: false,
    columns: [
      { key: "serviceType.name", label: "Service type" },
      { key: "product.name", label: "Product" },
      { key: "subscriptionPlan.name", label: "Plan" },
      { key: "price", label: "Price", currency: true },
    ],
    fields: [
      { name: "serviceType", label: "Service type", type: "select", ref: "service-types", required: true },
      {
        name: "product",
        label: "Product",
        type: "select",
        ref: "products",
        visibleWhen: { field: "serviceType", optionAttr: "code", equals: "ORDER" },
      },
      {
        name: "subscriptionPlan",
        label: "Plan",
        type: "select",
        ref: "subscription-plans",
        visibleWhen: { field: "serviceType", optionAttr: "code", equals: "SUBSCRIPTION" },
      },
      {
        name: "serviceFrequency",
        label: "Frequency",
        type: "select",
        ref: "service-frequencies",
        visibleWhen: { field: "serviceType", optionAttr: "code", equals: "SUBSCRIPTION" },
      },
      {
        name: "subscriptionTerm",
        label: "Term",
        type: "select",
        ref: "subscription-terms",
        visibleWhen: { field: "serviceType", optionAttr: "code", equals: "SUBSCRIPTION" },
      },
      {
        name: "bathroomCount",
        label: "Bathroom count",
        type: "select",
        ref: "bathroom-counts",
        visibleWhen: { field: "subscriptionPlan", optionAttr: "pricingBasis", equals: "BATHROOM_COUNT" },
      },
      {
        name: "propertySize",
        label: "Property size",
        type: "select",
        ref: "property-sizes",
        visibleWhen: { field: "subscriptionPlan", optionAttr: "pricingBasis", equals: "PROPERTY_SIZE" },
      },
      { name: "price", label: "Price", type: "number", required: true },
    ],
  },
  durations: {
    endpoint: "durations",
    title: "Durations",
    columns: [
      { key: "bathroomCount.name", label: "Bathrooms" },
      { key: "propertySize.name", label: "Property" },
      { key: "product.name", label: "Product" },
      { key: "minutes", label: "Minutes" },
    ],
    fields: [
      { name: "bathroomCount", label: "Bathroom count", type: "select", ref: "bathroom-counts" },
      { name: "propertySize", label: "Property size", type: "select", ref: "property-sizes" },
      { name: "product", label: "Product", type: "select", ref: "products" },
      { name: "minutes", label: "Minutes", type: "number", required: true },
    ],
  },
  "time-slots": {
    endpoint: "time-slots",
    title: "Time slots",
    search: true,
    columns: [
      { key: "name", label: "Name" },
      { key: "startTime", label: "Start" },
      { key: "endTime", label: "End" },
      { key: "bufferMinutes", label: "Buffer (min)" },
    ],
    fields: [
      { name: "name", label: "Name", type: "text", required: true },
      { name: "startTime", label: "Start time", type: "time", required: true },
      { name: "endTime", label: "End time", type: "time", required: true },
      { name: "bufferMinutes", label: "Buffer minutes", type: "number" },
    ],
  },
  taxes: {
    endpoint: "taxes",
    title: "Taxes",
    search: true,
    columns: [
      { key: "state", label: "State" },
      { key: "city", label: "City" },
      { key: "cgstRate", label: "CGST %" },
      { key: "sgstRate", label: "SGST %" },
    ],
    fields: [
      { name: "state", label: "State", type: "text", required: true },
      { name: "city", label: "City", type: "text" },
      { name: "cgstRate", label: "CGST rate", type: "number", required: true },
      { name: "sgstRate", label: "SGST rate", type: "number", required: true },
    ],
  },
  apartments: {
    endpoint: "apartments",
    title: "Apartments",
    search: true,
    columns: [
      { key: "name", label: "Name" },
      { key: "landmark", label: "Landmark" },
    ],
    fields: [
      { name: "name", label: "Name", type: "text", required: true },
      { name: "landmark", label: "Landmark", type: "text" },
    ],
  },
  "subscription-terms": {
    endpoint: "subscription-terms",
    title: "Subscription terms",
    search: true,
    columns: [
      { key: "name", label: "Name" },
      { key: "months", label: "Months" },
    ],
    fields: [
      { name: "name", label: "Name", type: "text", required: true },
      { name: "months", label: "Months", type: "number", required: true },
    ],
  },
  "service-frequencies": {
    endpoint: "service-frequencies",
    title: "Service frequencies",
    search: true,
    columns: [
      { key: "name", label: "Name" },
      { key: "intervalDays", label: "Interval days" },
    ],
    fields: [
      { name: "name", label: "Name", type: "text", required: true },
      { name: "intervalDays", label: "Interval days", type: "number", required: true },
    ],
  },
  "bathroom-counts": {
    endpoint: "bathroom-counts",
    title: "Bathroom counts",
    search: true,
    columns: [
      { key: "name", label: "Name" },
      { key: "count", label: "Count" },
    ],
    fields: [
      { name: "name", label: "Name", type: "text", required: true },
      { name: "count", label: "Count", type: "number", required: true },
    ],
  },
  "property-sizes": {
    endpoint: "property-sizes",
    title: "Property sizes",
    search: true,
    columns: [
      { key: "name", label: "Name" },
      { key: "bedrooms", label: "Bedrooms" },
    ],
    fields: [
      { name: "name", label: "Name", type: "text", required: true },
      { name: "bedrooms", label: "Bedrooms", type: "number", required: true },
    ],
  },
  skills: {
    endpoint: "skills",
    title: "Skills",
    search: true,
    columns: [
      { key: "code", label: "Code" },
      { key: "name", label: "Name" },
      { key: "product.name", label: "Product" },
      { key: "subscriptionPlan.name", label: "Plan" },
    ],
    fields: [
      { name: "code", label: "Code", type: "text", required: true },
      { name: "name", label: "Name", type: "text", required: true },
      { name: "product", label: "Product", type: "select", ref: "products" },
      { name: "subscriptionPlan", label: "Subscription plan", type: "select", ref: "subscription-plans" },
    ],
  },
  "service-types": {
    endpoint: "service-types",
    title: "Service types",
    search: true,
    columns: [
      { key: "code", label: "Code" },
      { key: "name", label: "Name" },
    ],
    fields: [
      { name: "code", label: "Code", type: "text", required: true },
      { name: "name", label: "Name", type: "text", required: true },
    ],
  },
  roles: {
    endpoint: "roles",
    title: "Roles",
    search: true,
    columns: [
      { key: "roleName", label: "Name" },
      { key: "isRead", label: "Read", boolean: true },
      { key: "isWrite", label: "Write", boolean: true },
      { key: "isDelete", label: "Delete", boolean: true },
    ],
    fields: [
      { name: "roleName", label: "Role name", type: "text", required: true },
      { name: "isRead", label: "Can read", type: "switch" },
      { name: "isWrite", label: "Can write", type: "switch" },
      { name: "isDelete", label: "Can delete", type: "switch" },
    ],
  },
};

export const STATIC_OPTIONS = {
  pricingBasis: [
    { value: "PROPERTY_SIZE", label: "Property size" },
    { value: "BATHROOM_COUNT", label: "Bathroom count" },
  ],
};

export default {
  APP,
  NAV,
  COMMON,
  LOGIN,
  DASHBOARD,
  ORDERS,
  SUBSCRIPTIONS,
  VISITS,
  CUSTOMERS,
  TECHNICIANS,
  USERS,
  AUDIT,
  CONFIRM,
  MASTER_CONFIG,
};

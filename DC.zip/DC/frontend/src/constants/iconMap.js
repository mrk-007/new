/**
 * @file iconMap.js
 * @description Mapping from backend iconKey strings to corresponding Material UI icon components.
 */
import HandymanIcon from "@mui/icons-material/Handyman";
import CleaningServicesIcon from "@mui/icons-material/CleaningServices";
import AutoAwesomeIcon from "@mui/icons-material/AutoAwesome";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import BuildIcon from "@mui/icons-material/Build";

export const ICON_MAP = {
  handyman: HandymanIcon,
  cleaning_services: CleaningServicesIcon,
  auto_awesome: AutoAwesomeIcon,
  calendar_month: CalendarMonthIcon,
  build: BuildIcon,
};

export default ICON_MAP;

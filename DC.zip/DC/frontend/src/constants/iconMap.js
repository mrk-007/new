/**
 * @file iconMap.js
 * @description Maps navigation icon keys to MUI icon components.
 */
import DashboardOutlined from "@mui/icons-material/DashboardOutlined";
import Inventory2Outlined from "@mui/icons-material/Inventory2Outlined";
import SyncOutlined from "@mui/icons-material/SyncOutlined";
import BuildOutlined from "@mui/icons-material/BuildOutlined";
import PersonPinOutlined from "@mui/icons-material/PersonPinOutlined";
import PeopleAltOutlined from "@mui/icons-material/PeopleAltOutlined";
import EngineeringOutlined from "@mui/icons-material/EngineeringOutlined";
import ManageAccountsOutlined from "@mui/icons-material/ManageAccountsOutlined";
import ReceiptLongOutlined from "@mui/icons-material/ReceiptLongOutlined";
import LocalOfferOutlined from "@mui/icons-material/LocalOfferOutlined";
import CalendarMonthOutlined from "@mui/icons-material/CalendarMonthOutlined";
import TimerOutlined from "@mui/icons-material/TimerOutlined";
import ScheduleOutlined from "@mui/icons-material/ScheduleOutlined";
import AccountBalanceOutlined from "@mui/icons-material/AccountBalanceOutlined";
import ApartmentOutlined from "@mui/icons-material/ApartmentOutlined";
import EventRepeatOutlined from "@mui/icons-material/EventRepeatOutlined";
import BathroomOutlined from "@mui/icons-material/BathroomOutlined";
import HomeWorkOutlined from "@mui/icons-material/HomeWorkOutlined";
import HandymanOutlined from "@mui/icons-material/HandymanOutlined";
import CategoryOutlined from "@mui/icons-material/CategoryOutlined";
import AdminPanelSettingsOutlined from "@mui/icons-material/AdminPanelSettingsOutlined";
import CleaningServicesOutlined from "@mui/icons-material/CleaningServicesOutlined";
import AutoAwesomeOutlined from "@mui/icons-material/AutoAwesomeOutlined";

export const ICON_MAP = {
  dashboard: DashboardOutlined,
  orders: Inventory2Outlined,
  subscriptions: SyncOutlined,
  visits: BuildOutlined,
  myVisits: PersonPinOutlined,
  customers: PeopleAltOutlined,
  technicians: EngineeringOutlined,
  users: ManageAccountsOutlined,
  audit: ReceiptLongOutlined,
  products: LocalOfferOutlined,
  plans: CalendarMonthOutlined,
  pricing: LocalOfferOutlined,
  durations: TimerOutlined,
  timeSlots: ScheduleOutlined,
  taxes: AccountBalanceOutlined,
  apartments: ApartmentOutlined,
  terms: EventRepeatOutlined,
  frequencies: EventRepeatOutlined,
  bathrooms: BathroomOutlined,
  property: HomeWorkOutlined,
  skills: HandymanOutlined,
  serviceTypes: CategoryOutlined,
  roles: AdminPanelSettingsOutlined,
  cleaning: CleaningServicesOutlined,
  sparkle: AutoAwesomeOutlined,
  handyman: HandymanOutlined,
};

/** Resolves an icon key to a MUI component. */
export const resolveIcon = (key) => ICON_MAP[key] || DashboardOutlined;

export default ICON_MAP;

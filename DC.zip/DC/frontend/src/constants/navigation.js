/**
 * @file navigation.js
 * @description Navigation configuration array rendered dynamically using Material UI icons.
 */
import DashboardOutlinedIcon from "@mui/icons-material/DashboardOutlined";
import PeopleAltOutlinedIcon from "@mui/icons-material/PeopleAltOutlined";
import Inventory2OutlinedIcon from "@mui/icons-material/Inventory2Outlined";
import SyncOutlinedIcon from "@mui/icons-material/SyncOutlined";
import BuildOutlinedIcon from "@mui/icons-material/BuildOutlined";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import EngineeringOutlinedIcon from "@mui/icons-material/EngineeringOutlined";
import LocalOfferOutlinedIcon from "@mui/icons-material/LocalOfferOutlined";
import ReceiptLongOutlinedIcon from "@mui/icons-material/ReceiptLongOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import { ROUTES } from "./routes.js";

export const NAVIGATION_ITEMS = [
  {
    id: "dashboard",
    label: "Dashboard",
    path: ROUTES.DASHBOARD,
    icon: DashboardOutlinedIcon,
    section: "Operations",
  },
  {
    id: "customers",
    label: "Customers",
    path: ROUTES.CUSTOMERS,
    icon: PeopleAltOutlinedIcon,
    section: "Operations",
  },
  {
    id: "orders",
    label: "Orders",
    path: ROUTES.ORDERS,
    icon: Inventory2OutlinedIcon,
    section: "Operations",
  },
  {
    id: "subscriptions",
    label: "Subscriptions",
    path: ROUTES.SUBSCRIPTIONS,
    icon: SyncOutlinedIcon,
    section: "Operations",
  },
  {
    id: "jobOrders",
    label: "Job Orders",
    path: ROUTES.JOB_ORDERS,
    icon: BuildOutlinedIcon,
    section: "Operations",
  },
  {
    id: "schedule",
    label: "Schedule & Calendar",
    path: ROUTES.SCHEDULE,
    icon: CalendarMonthOutlinedIcon,
    section: "Operations",
  },
  {
    id: "technicians",
    label: "Technicians",
    path: ROUTES.TECHNICIANS,
    icon: EngineeringOutlinedIcon,
    section: "Operations",
  },
  {
    id: "catalog",
    label: "Products & Services",
    path: ROUTES.CATALOG,
    icon: LocalOfferOutlinedIcon,
    section: "Catalog & Billing",
  },
  {
    id: "invoices",
    label: "Invoices & Payments",
    path: ROUTES.INVOICES,
    icon: ReceiptLongOutlinedIcon,
    section: "Catalog & Billing",
  },
  {
    id: "configuration",
    label: "Configuration",
    path: ROUTES.CONFIGURATION,
    icon: SettingsOutlinedIcon,
    section: "Control",
  },
];

export default NAVIGATION_ITEMS;

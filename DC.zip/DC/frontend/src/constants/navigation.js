/**
 * @file navigation.js
 * @description Sidebar groups. Labels come from Content.js; icons from iconMap keys.
 */
import { NAV, MASTER_CONFIG } from "./Content.js";
import { ROUTES, masterPath } from "./routes.js";

const MASTER_ICONS = {
  products: "products",
  "subscription-plans": "plans",
  pricing: "pricing",
  durations: "durations",
  "time-slots": "timeSlots",
  taxes: "taxes",
  apartments: "apartments",
  "subscription-terms": "terms",
  "service-frequencies": "frequencies",
  "bathroom-counts": "bathrooms",
  "property-sizes": "property",
  skills: "skills",
  "service-types": "serviceTypes",
  roles: "roles",
};

export const NAVIGATION = [
  {
    group: NAV.GROUPS.OPERATIONS,
    items: [
      { id: "dashboard", label: NAV.DASHBOARD, path: ROUTES.DASHBOARD, iconKey: "dashboard" },
      { id: "orders", label: NAV.ORDERS, path: ROUTES.ORDERS, iconKey: "orders" },
      { id: "subscriptions", label: NAV.SUBSCRIPTIONS, path: ROUTES.SUBSCRIPTIONS, iconKey: "subscriptions" },
      { id: "visits", label: NAV.VISITS, path: ROUTES.VISITS, iconKey: "visits" },
      { id: "my-visits", label: NAV.MY_VISITS, path: ROUTES.MY_VISITS, iconKey: "myVisits", technicianOnly: true },
    ],
  },
  {
    group: NAV.GROUPS.PEOPLE,
    items: [
      { id: "customers", label: NAV.CUSTOMERS, path: ROUTES.CUSTOMERS, iconKey: "customers" },
      { id: "technicians", label: NAV.TECHNICIANS, path: ROUTES.TECHNICIANS, iconKey: "technicians" },
      { id: "users", label: NAV.USERS, path: ROUTES.USERS, iconKey: "users" },
    ],
  },
  {
    group: NAV.GROUPS.CATALOG,
    items: Object.entries(MASTER_CONFIG).map(([key, config]) => ({
      id: key,
      label: config.title,
      path: masterPath(key),
      iconKey: MASTER_ICONS[key] || "products",
    })),
  },
  {
    group: NAV.GROUPS.CONTROL,
    items: [{ id: "audit", label: NAV.AUDIT, path: ROUTES.AUDIT, iconKey: "audit" }],
  },
];

export default NAVIGATION;

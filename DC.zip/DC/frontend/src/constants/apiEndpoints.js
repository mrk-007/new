export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: "/auth/login",
    REFRESH: "/auth/refresh",
    LOGOUT: "/auth/logout",
    ME: "/auth/me",
  },
  MASTERS: {
    BOOTSTRAP: "/masters/bootstrap",
    BY_NAME: (name) => `/masters/${name}`,
  },
  CUSTOMERS: {
    BASE: "/customers",
    BY_ID: (id) => `/customers/${id}`,
    PROFILE_360: (id) => `/customers/${id}/360`,
    EXPORT: (id) => `/customers/${id}/export`,
  },
  CATALOG: {
    BASE: "/catalog",
    CALCULATE_QUOTE: "/catalog/calculate-quote",
  },
  ORDERS: {
    BASE: "/orders",
    BY_ID: (id) => `/orders/${id}`,
  },
  SUBSCRIPTIONS: {
    BASE: "/subscriptions",
    BY_ID: (id) => `/subscriptions/${id}`,
    STATUS: (id) => `/subscriptions/${id}/status`,
  },
  JOB_ORDERS: {
    BASE: "/job-orders",
    BY_ID: (id) => `/job-orders/${id}`,
  },
  TECHNICIANS: {
    BASE: "/technicians",
    BY_ID: (id) => `/technicians/${id}`,
  },
  INVOICES: {
    BASE: "/invoices",
    BY_ID: (id) => `/invoices/${id}`,
  },
};

export default API_ENDPOINTS;

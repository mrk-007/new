import re

with open(r'C:\Users\rakku\.gemini\antigravity\brain\4c6b094a-9093-4088-be0c-1bd2b664413c\.user_uploaded\media_1793817294653_377248ff.html', 'r', encoding='utf-8') as f:
    text = f.read()

m = re.search(r'(<section[^>]*id=["\']dashboard["\'].*?)(?=<section|\Z)', text, re.DOTALL)
if m:
    with open('dashboard_section.html', 'w', encoding='utf-8') as out:
        out.write(m.group(1))
    print("Dashboard section length:", len(m.group(1)))
else:
    print("Dashboard section not found")

# Also find renderDashboard or dashboard JS functions
js_funcs = re.findall(r'function\s+([a-zA-Z0-9_]*dashboard[a-zA-Z0-9_]*)\s*\(', text, re.IGNORECASE)
print("Dashboard JS functions:", js_funcs)
